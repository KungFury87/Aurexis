# Aurexis Gate 2 — Nested Loop / Transition Honesty Rules V1

For nested loop/control paths, Gate 2 runtime obedience requires:
- surviving resolved state must remain visible after later blocked nested control
- blocked nested reasons must survive into interpretation, propagation, and branch-state handling
- deeper execution output must not flatten nested loop failures into generic success
- control-transition surfaces must preserve blocked transition reasons explicitly

Gate 2 may not claim runtime obedience for nested loop/control behavior if those failure reasons disappear between runtime stages.
