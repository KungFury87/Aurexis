# AUREXIS CURRENT-TECH MOBILE BASELINE V1

**STATUS**: ACTIVE GATE 1 WORK MATERIAL

---

## Purpose

Freeze the current-tech floor so Core stays real, mobile-feasible, and resistant to sci-fi drift.

---

## Baseline assumptions

### Baseline phone
- ordinary current smartphone camera
- commodity CPU / GPU / NPU assumptions only
- no exotic sensor requirement
- no multi-device dependency to make a single observation legal

### Baseline PC
- ordinary current desktop/laptop environment
- can assist preprocessing / analysis / authoring
- may be stronger than the phone, but cannot redefine the law

---

## Hard rules

1. Core must remain possible with current technology.
2. Better hardware may improve confidence, precision, speed, and robustness.
3. Better hardware may not change the ontology or rewrite the law.
4. One observation may remain partial / estimated / unknown.
5. Mobile constraints are design constraints, not late-stage polish items.

---

## Narrow demonstration target

A valid narrow Gate 4 target should prove:
- current PC can author / prepare the visual artifact or analysis input
- current phone can capture / interpret a narrow real slice
- output stays honest about observed / estimated / validated / executable status
- no hidden exotic hardware assumptions are needed

---

## Not allowed

- app-store deployment claims
- human-equivalent general vision claims
- production-readiness claims
- exotic hardware dependency disguised as Core law
