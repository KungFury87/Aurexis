# Aurexis Gate 2 — Deeper Runtime Surface Rules V1

Gate 2 runtime-facing surfaces extend beyond resolution/interpretation/propagation/branch state.

Additional active runtime-facing surfaces covered by this ruleset:
- `runtime_deeper_execution`
- `runtime_control_transitions`

Required metadata on these surfaces:
- `gate_2_status`: `IN_PROGRESS`
- `reporting_rules_version`: `AUREXIS_RUNTIME_OBEDIENCE_REPORTING_RULES_V1`
- `stage_metadata_version`: `AUREXIS_GATE_2_RUNTIME_STAGE_METADATA_RULES_V1`
- `report_surface_alignment_target`: `AUREXIS_GATE_2_REPORT_SURFACE_ALIGNMENT_RULES_V1`
- `evidence_scope`: `authored/runtime`
- `gate_clearance_authority`: `false`
- `world_authority_primary`: `true`
- `image_access_primary`: `true`

These surfaces are authored/runtime evidence only. They are not gate-clearing proof by themselves.
