# AUREXIS ILLEGAL INFERENCE BLOCKED-CLAIM MATRIX V1

**STATUS**: ACTIVE GATE 1 FREEZE MATERIAL  
**ROLE**: Freeze the exact blocked-claim matrix for illegal inference

---

## Core rule

Core may only claim what the evidence earns.
If a claim crosses the blocked-claim matrix below, it must be downgraded, rejected, or explicitly marked as hypothesis.

---

## Frozen blocked claims

### 1. `full_world_truth_from_single_observation`
Blocked when:
- one image / one observation is treated as complete world truth

### 2. `exact_world_placement_from_weak_evidence`
Blocked when:
- exact world placement is claimed without strong grounding

### 3. `hidden_geometry_or_contents_claim`
Blocked when:
- hidden geometry, unseen surfaces, or unseen contents are stated as fact

### 4. `executability_from_pattern_alone`
Blocked when:
- a seen pattern is treated as executable language/code without validation gates

### 5. `identity_from_resemblance_alone`
Blocked when:
- resemblance is promoted to identity

### 6. `causality_or_function_from_appearance_alone`
Blocked when:
- cause, intent, or function is claimed from appearance alone

### 7. `permanence_from_single_frame`
Blocked when:
- one frame is treated as persistence / permanence

### 8. `earned_physical_proof_without_earned_tier`
Blocked when:
- lab/authored/real-capture evidence is presented as earned physical proof
- only `earned` tier may carry earned physical proof claims

### 9. `world_claim_without_image_grounding`
Blocked when:
- world claims are asserted without image-grounded evidence

---

## Required handling

When a blocked claim is triggered, Core must do one of:
- reject the claim
- downgrade the claim to `estimated` or `unknown`
- require stronger evidence before promotion

What Core may not do:
- silently flatten the blocked claim into a confident result
- hide the reason for the downgrade / rejection
- use lab-only evidence as earned physical proof
