# AUREXIS GATE 1 FREEZE CHECKLIST V1

**STATUS**: GATE 1 COMPLETE (LOCKED IN V20)  
**SCOPE**: Core only  
**ROLE**: Freeze the governing law before broader runtime/evidence expansion

---

## Gate 1 objective

Freeze the law tightly enough that later runtime, evidence, and mobile work stop re-defining Core on the fly.

Gate 1 is complete only when these are frozen together:
- Core definition
- phoxel record
- world/image authority
- native relations
- execution promotion
- illegal inference
- evidence tiers
- current-tech mobile baseline
- future-tech ceiling

---

## Required freeze items

### 1. Core definition
- [x] Core is a programming language
- [x] Core is a physical-world interface layer
- [x] Core is not an app / ecosystem / app-store program

### 2. Phoxel record
- [x] canonical term is `phoxel`
- [x] exact minimum legal record fields frozen in one final schema (`AUREXIS_PHOXEL_RECORD_SCHEMA_V1.md`)
- [x] parser/runtime surfaces all obey the same canonical record contract

### 3. World / image authority
- [x] world first in authority
- [x] image first in access
- [x] both alive at once in processing
- [x] every active enforcement/report surface checked against this wording

### 4. Native relations
- [x] primary relation stack named
- [x] relation legality / minimum measurable requirements frozen (`AUREXIS_RELATION_LEGALITY_MEASURABLE_REQUIREMENTS_V1.md`)

### 5. Execution promotion
- [x] descriptive / estimated / validated / executable distinction exists
- [x] final gate conditions frozen in one checklist (`AUREXIS_EXECUTABLE_PROMOTION_CHECKLIST_V1.md`)

### 6. Illegal inference
- [x] overclaiming is blocked in principle
- [x] final blocked-claim matrix frozen (`AUREXIS_ILLEGAL_INFERENCE_BLOCKED_CLAIM_MATRIX_V1.md`)

### 7. Evidence tiers
- [x] lab / authored / real-capture / earned defined
- [x] evidence-tier rules referenced by every benchmark/report path

### 8. Current-tech mobile baseline
- [x] baseline phone + PC assumptions frozen (`AUREXIS_MOBILE_BASELINE_V1.md`)
- [x] narrow current-tech demonstration target frozen (`AUREXIS_NARROW_MOBILE_DEMONSTRATION_TARGET_V1.md`)

### 9. Future-tech ceiling
- [x] law says better hardware may improve capability without rewriting Core
- [x] compatibility criteria frozen in one short rule set (`AUREXIS_FUTURE_TECH_CEILING_COMPATIBILITY_CRITERIA_V1.md`)

---

## Gate 1 exit criteria

Gate 1 clears when:
1. the law sheet and supporting gate docs no longer contradict each other
2. active parser/runtime code uses canonical phoxel terminology in live fields
3. evidence tiers are explicit across active evidence/report paths
4. the mobile baseline and narrow demonstration target are frozen and testable
5. future-tech scaling criteria are frozen without rewriting Core law
6. no active authority doc claims later gates are already complete

---

## Immediate next focus after Gate 1

- Gate 2: Runtime obeys law
- Gate 3: Evidence loop earned

## Supporting freeze docs
- `AUREXIS_PHOXEL_RECORD_SCHEMA_V1.md`
- `AUREXIS_ILLEGAL_INFERENCE_BLOCKED_CLAIM_MATRIX_V1.md`
- `AUREXIS_RELATION_LEGALITY_MEASURABLE_REQUIREMENTS_V1.md`
- `AUREXIS_EXECUTABLE_PROMOTION_CHECKLIST_V1.md`

- `AUREXIS_FUTURE_TECH_CEILING_COMPATIBILITY_CRITERIA_V1.md`
- `AUREXIS_NARROW_MOBILE_DEMONSTRATION_TARGET_V1.md`
