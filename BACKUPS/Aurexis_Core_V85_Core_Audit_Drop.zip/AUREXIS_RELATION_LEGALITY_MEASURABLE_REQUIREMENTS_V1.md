# AUREXIS RELATION LEGALITY / MEASURABLE REQUIREMENTS V1

**STATUS**: ACTIVE GATE 1 FREEZE LAW

---

## Purpose

Freeze the minimum measurable requirements for a relation to count as a legal Core relation instead of a vague semantic guess.

---

## Allowed relation kinds

Primary native relation kinds:
- `position`
- `adjacency`
- `direction`
- `distance`
- `containment`
- `boundary`
- `region_membership`
- `sequence`

Higher-order but still legal relation kinds:
- `scale`
- `hierarchy`
- `overlap`
- `continuity`
- `transition`

---

## Minimum measurable requirements

A legal relation must include all of:
1. `relation_kind`
2. `source_id`
3. `target_id`
4. `physical_measurement`
5. `pixel_space_verification`

### physical_measurement (required)
Must include:
- `measurement_type`
- at least one observed/measured value

Examples of legal measured values:
- `observed_value`
- `distance_px`
- `distance_world`
- `direction_vector`
- `boundary_strength`
- `overlap_ratio`
- `sequence_index`

### pixel_space_verification (required)
Must include:
- `image_grounded: true`
- one support field such as:
  - `verification_method`
  - `pixel_path`
  - `observed_pixels`

---

## World-side claims

If a relation makes a world-side claim, it must also include `world_anchor_support`.

`world_anchor_support.status` may be only:
- `estimated`
- `resolved`

---

## Forbidden relation states

A relation is illegal if:
- `abstract_semantic: true`
- the relation kind is not in the allowed set
- it lacks physical measurement
- it lacks pixel-space verification
- it makes a world claim without world-anchor support

---

## Gate 1 rule

No relation counts as legal Core structure unless it is both:
- physically measurable
- image-grounded
