# Root docs authority scope (v7 cleanup)

These root `docs/` files are active implementation notes, scaffolds, and law-adjacent planning material for Aurexis Core.

Authority rules:
- They do **not** override `AUREXIS_CORE_LAW_V1.md`.
- They do **not** clear gates by themselves.
- Synthetic/lab-oriented docs remain lab-oriented unless real-capture / earned evidence is explicitly cited elsewhere.
- They should be treated as active engineering notes, not final project-completion proof.

If a docs file conflicts with the root law sheet or cleanup notices, the law sheet / cleanup notices win.
