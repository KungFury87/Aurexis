from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "aurexis_lang" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.illegal_inference_matrix import evaluate_blocked_claims
from aurexis_lang.core_law_enforcer import enforce_core_law, CoreLawSection


def _text(path: str) -> str:
    return Path(path).read_text(encoding="utf-8")


def test_blocked_claim_matrix_doc_names_core_forbidden_claims():
    text = _text("AUREXIS_ILLEGAL_INFERENCE_BLOCKED_CLAIM_MATRIX_V1.md")
    for needle in [
        "full_world_truth_from_single_observation",
        "executability_from_pattern_alone",
        "earned_physical_proof_without_earned_tier",
        "world_claim_without_image_grounding",
    ]:
        assert needle in text


def test_evaluate_blocked_claims_flags_lab_as_earned_and_hidden_geometry():
    hits = evaluate_blocked_claims({
        "claims_earned_physical_proof": True,
        "evidence": {"evidence_tier": "lab"},
        "hidden_geometry_claim": True,
    })
    ids = {rule.claim_id for rule in hits}
    assert "earned_physical_proof_without_earned_tier" in ids
    assert "hidden_geometry_or_contents_claim" in ids


def test_enforcer_uses_blocked_claim_matrix():
    passed, violations = enforce_core_law({
        "type": "inference",
        "evidence_bounded": True,
        "uncertainty": 0.3,
        "evidence_chain": ["frame:1"],
        "claims_earned_physical_proof": True,
        "evidence": {"evidence_tier": "authored"},
    })
    assert passed is False
    assert any(v.section == CoreLawSection.ILLEGAL_INFERENCE for v in violations)
    joined = " ".join(v.description for v in violations)
    assert "earned_physical_proof_without_earned_tier" in joined
