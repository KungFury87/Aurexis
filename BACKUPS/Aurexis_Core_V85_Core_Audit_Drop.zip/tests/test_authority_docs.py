from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_core_law_world_image_authority_is_correct():
    law = (ROOT / "AUREXIS_CORE_LAW_V1.md").read_text(encoding="utf-8")
    assert "world is primary in authority" in law.lower()
    assert "image is primary in access" in law.lower()


def test_roadmap_no_longer_claims_all_gates_complete():
    roadmap = (ROOT / "AUREXIS_DEVELOPMENT_ROADMAP.md").read_text(encoding="utf-8")
    lowered = roadmap.lower()
    assert "all 5 gates completed" not in lowered
    assert "foundation complete" not in lowered
    assert "app-store deployment" in lowered  # explicit non-goal check
