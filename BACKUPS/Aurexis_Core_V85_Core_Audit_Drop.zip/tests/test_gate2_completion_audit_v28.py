import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
AUREXIS_SRC = ROOT / 'aurexis_lang' / 'src'
if str(AUREXIS_SRC) not in sys.path:
    sys.path.insert(0, str(AUREXIS_SRC))

from gate_2_runtime_enforcement import RuntimeLawEnforcement
from aurexis_lang import audit_gate2_completion


def test_gate2_completion_docs_exist():
    assert (ROOT / 'AUREXIS_GATE_2_COMPLETION_AUDIT_V28.md').exists()
    assert (ROOT / 'AUREXIS_GATE_2_COMPLETION_REPORT_V28.md').exists()


def test_gate2_completion_audit_clears_updated_scaffold():
    enforcer = RuntimeLawEnforcement()
    summary = enforcer.run_comprehensive_runtime_enforcement()
    audit = summary.get('gate_2_completion_audit')
    assert audit is not None
    assert audit['gate_2_complete'] is True
    assert audit['all_audit_checks_pass'] is True
    assert audit['blocking_components'] == []
    assert summary['gate_2_status'] == 'IN_PROGRESS'
    assert summary['gate_clearance_authority'] is False


def test_gate2_completion_audit_blocks_bad_summary():
    bad = {
        'overall_compliance_rate': 0.9,
        'total_violations': 1,
        'component_results': {},
        'gate_clearance_authority': False,
        'world_authority_primary': True,
        'image_access_primary': True,
        'report_scope': 'gate_2_runtime_obedience_scaffold',
        'reporting_rules_version': 'AUREXIS_RUNTIME_OBEDIENCE_REPORTING_RULES_V1',
        'report_surface_alignment': False,
        'runtime_stage_metadata_complete': False,
    }
    audit = audit_gate2_completion(bad)
    assert audit['gate_2_complete'] is False
