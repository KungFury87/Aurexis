from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(ROOT / 'aurexis_lang' / 'src') not in sys.path:
    sys.path.insert(0, str(ROOT / 'aurexis_lang' / 'src'))

from aurexis_lang.execution_resolution import run_execution_resolution
from aurexis_lang.execution_interpretation import interpret_execution_result
from aurexis_lang.execution_state_propagation import propagate_execution_state
from aurexis_lang.branch_state_execution import run_branch_state_execution
from aurexis_lang.runtime_obedience import evaluate_runtime_obedience
from aurexis_lang.control_resolution import summarize_control_resolution
from aurexis_lang.control_flow_state_machine import control_steps_to_transitions, step_state_machine
from gate_2_runtime_enforcement import RuntimeLawEnforcement


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


def test_gate2_v25_docs_exist_and_name_nested_loop_and_mutation_rules():
    nested = read('AUREXIS_GATE_2_NESTED_LOOP_CONTROL_FAILURE_RULES_V1.md')
    mutation = read('AUREXIS_GATE_2_RUNTIME_MUTATION_EDGE_CASE_RULES_V1.md')
    assert 'loop-body mutations that successfully resolve before a later blocked nested control step must survive' in nested
    assert 'successful earlier assignments must survive later failed loop/control steps' in mutation


def test_nested_loop_control_failure_keeps_surviving_state_and_aligned_control_surfaces():
    plan = {
        'execution_steps': [
            {'step_type': 'assignment', 'target': 'x', 'value': 0},
            {'step_type': 'control', 'keyword': 'while', 'condition_value': ['x', '<', 2], 'body_steps': [
                {'step_type': 'assignment', 'target': 'x', 'value_expr': ['x', '+', 1]},
                {'step_type': 'control', 'keyword': 'if', 'condition_value': None, 'then_steps': [
                    {'step_type': 'assignment', 'target': 'never', 'value': 1}
                ]},
            ]},
            {'step_type': 'assignment', 'target': 'after', 'value_expr': ['x', '+', 2]},
        ]
    }
    resolution = run_execution_resolution(plan)
    interpreted = interpret_execution_result(resolution)
    propagated = propagate_execution_state(resolution)
    branch = run_branch_state_execution(resolution)
    control_summary = summarize_control_resolution([
        {'keyword': 'while', 'condition_value': True},
        {'keyword': 'if', 'condition_value': None},
    ])
    control_machine = step_state_machine(control_steps_to_transitions(control_summary))
    obedience = evaluate_runtime_obedience(resolution, interpreted, propagated, branch, control_summary, control_machine)

    assert obedience['checks']['control_surface_alignment'] is True
    assert obedience['checks']['nested_loop_control_honest'] is True
    assert obedience['checks']['mutation_edge_case_honest'] is True
    assert propagated['final_environment']['x'] == 1
    assert propagated['final_environment']['after'] == 3
    assert 'blocked_control_branch' in obedience['propagated_reasons']
    assert control_summary['report_scope'] == 'runtime_control_resolution'
    assert control_machine['report_scope'] == 'runtime_control_state_machine'


def test_gate2_v25_scaffold_summary_exposes_control_surface_alignment():
    summary = RuntimeLawEnforcement().run_comprehensive_runtime_enforcement()
    assert summary['gate_2_status'] == 'IN_PROGRESS'
    assert summary['control_surface_alignment'] is True
