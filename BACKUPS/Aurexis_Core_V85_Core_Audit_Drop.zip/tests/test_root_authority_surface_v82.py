from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_root_quickstart_defers_to_law_sheet():
    text = (ROOT / 'README_START_HERE.md').read_text(encoding='utf-8').lower()
    assert 'aurexis_core_law_v1.md' in text
    assert 'if any quickstart/readme/generated surface disagrees with the law sheet, the law sheet wins.' in text


def test_root_quickstart_does_not_overstate_gate_completion():
    text = (ROOT / 'README_START_HERE.md').read_text(encoding='utf-8').lower()
    forbidden = [
        'gate 1: complete',
        'gate 2: complete',
        'gate 3: releasable through the default/release pipeline when regenerated',
    ]
    for phrase in forbidden:
        assert phrase not in text
    assert 'gate 1: law freeze in progress' in text
    assert 'gate 2: runtime obedience partially real / still being aligned' in text
    assert 'gate 3: evidence-loop scaffold exists / not yet earned' in text


def test_root_quickstart_marks_commands_as_workflow_not_gate_authority():
    text = (ROOT / 'README_START_HERE.md').read_text(encoding='utf-8').lower()
    assert 'does **not** by itself clear gates or prove earned real-world capability' in text
    assert 'package-facing workflow surfaces' in text
    assert 'not as automatic gate-clearance authority' in text
