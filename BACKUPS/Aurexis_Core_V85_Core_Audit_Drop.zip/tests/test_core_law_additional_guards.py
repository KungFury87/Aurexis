from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "aurexis_lang" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.core_law_enforcer import CoreLawEnforcer, enforce_core_law, get_core_law_compliance_report, _core_law_enforcer, CoreLawSection


def setup_function():
    _core_law_enforcer.clear_violations()


def test_illegal_inference_rejects_missing_uncertainty_and_traceability():
    passed, violations = enforce_core_law({
        "type": "inference",
        "evidence_bounded": True,
        "logical_leap": False,
    })
    assert passed is False
    sections = [v.section for v in violations]
    assert CoreLawSection.ILLEGAL_INFERENCE in sections
    descriptions = " ".join(v.description.lower() for v in violations)
    assert "uncertainty" in descriptions
    assert "evidence chain" in descriptions


def test_illegal_inference_passes_when_evidence_bounded_uncertain_and_traceable():
    passed, violations = enforce_core_law({
        "type": "inference",
        "evidence_bounded": True,
        "logical_leap": False,
        "uncertainty": 0.18,
        "evidence_chain": ["camera:frame_001", "relation:boundary"],
    })
    assert passed is True
    assert violations == []


def test_current_tech_floor_rejects_exotic_or_over_budget_claims():
    passed, violations = enforce_core_law({
        "type": "performance",
        "processing_time_seconds": 45,
        "memory_usage_mb": 900,
        "exotic_hardware_required": True,
    })
    assert passed is False
    assert any(v.section == CoreLawSection.CURRENT_TECH_FLOOR for v in violations)
    joined = " ".join(v.description.lower() for v in violations)
    assert "processing time" in joined
    assert "memory usage" in joined
    assert "exotic hardware" in joined


def test_future_tech_ceiling_rejects_behavior_change_by_hardware():
    passed, violations = enforce_core_law({
        "type": "scalability",
        "hardware_dependent_feature": True,
        "behavior_changes_with_hardware": True,
    })
    assert passed is False
    assert any(v.section == CoreLawSection.FUTURE_TECH_CEILING for v in violations)


def test_compliance_report_accumulates_and_summarizes_sections():
    _core_law_enforcer.clear_violations()
    _core_law_enforcer.enforce_core_law({
        "type": "interpretation",
        "image_as_final_world_truth": True,
    })
    _core_law_enforcer.enforce_core_law({
        "type": "performance",
        "exotic_hardware_required": True,
    })
    report = get_core_law_compliance_report()
    assert report["status"] == "NON_COMPLIANT"
    assert report["critical_violations"] >= 1
    assert CoreLawSection.WORLD_IMAGE_AUTHORITY.value in report["sections_violated"]
    assert CoreLawSection.CURRENT_TECH_FLOOR.value in report["sections_violated"]
