from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_evidence_validation_loop_prefers_phoxel_language_and_non_authoritative_wording():
    source = (ROOT / 'evidence_validation_loop.py').read_text()
    assert 'phoxel_record' in source
    assert 'the only truth source' not in source.lower()
    assert 'does not replace earned real-camera validation' in source


def test_phase1_interpreter_prefers_canonical_phoxel_access_in_active_code():
    source = (ROOT / 'phase1_interpreter_implementation.py').read_text()
    assert '.phoxel_record.' in source
