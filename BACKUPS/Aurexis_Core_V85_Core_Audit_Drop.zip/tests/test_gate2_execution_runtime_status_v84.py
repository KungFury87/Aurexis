from datetime import datetime
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
SRC = ROOT / 'aurexis_lang' / 'src'
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import numpy as np

from aurexis_lang.execution_trace import ast_to_trace
from aurexis_lang.runtime_obedience import build_runtime_obedience_report
from aurexis_lang.runtime_reporting import stamp_runtime_surface
from aurexis_lang.phoxel_runtime_status import summarize_phoxel_runtime_status
from phase1_parser_implementation import AurexisParser as RichParser
from phase1_parser_simple import ASTNode, ASTNodeType, PhoxelRecord
from phase1_interpreter_implementation import AurexisInterpreter, ExecutionContext


def _record(x=5, y=7):
    return PhoxelRecord(
        pixel_coordinates=(x, y),
        image_timestamp=datetime.now(),
        camera_metadata={'scene_name': 'gate2-v84'},
        evidence_chain=['frame_0', 'frame_1'],
        pixel_data_available=True,
        synthetic=False,
    )


def test_execution_trace_surface_carries_root_and_step_phoxel_runtime_status():
    parser = RichParser()
    program, errors = parser.parse_visual_input({
        'frame_id': 11,
        'camera_metadata': {'scene_name': 'gate2-v84-trace'},
        'primitive_observations': [
            {
                'primitive_type': 'color_region',
                'confidence': 0.81,
                'attributes': {'centroid': (6, 8), 'value': 'region_a'},
            }
        ],
    })
    assert errors == []

    trace_surface = ast_to_trace(program)
    assert trace_surface['phoxel_runtime_status_explicit'] is True
    assert trace_surface['root_phoxel_runtime_status']['observation_status'] == 'validated'
    assert trace_surface['steps'][0]['phoxel_runtime_status']['image_anchor']['present'] is True
    assert trace_surface['phoxel_runtime_status_rollup']['explicit_count'] >= 2


def test_interpreter_execution_traces_and_report_keep_phoxel_runtime_status_alive():
    primitive = ASTNode(
        node_type=ASTNodeType.PRIMITIVE_DECLARATION,
        node_id='primitive_1',
        phoxel_record=_record(),
        attributes={'primitive_type': 'color_region'},
        confidence=0.74,
        evidence_validated=True,
        synthetic=False,
    )
    primitive.phoxel_runtime_status = summarize_phoxel_runtime_status(
        primitive.phoxel_record,
        evidence_validated=True,
        execution_status='validated',
    )
    program = ASTNode(
        node_type=ASTNodeType.PROGRAM,
        node_id='program_1',
        phoxel_record=_record(0, 0),
        attributes={},
        confidence=1.0,
        evidence_validated=True,
        synthetic=False,
        children=[primitive],
    )
    program.phoxel_runtime_status = summarize_phoxel_runtime_status(
        program.phoxel_record,
        evidence_validated=True,
        execution_status='validated',
    )
    program.attributes['phoxel_runtime_status'] = program.phoxel_runtime_status

    interpreter = AurexisInterpreter()
    context = ExecutionContext(
        scene_image=np.zeros((16, 16, 3), dtype=np.uint8),
        camera_metadata={'scene_name': 'gate2-v84-exec'},
        execution_timestamp=datetime.now(),
        evidence_chain=['frame_0', 'frame_1'],
    )
    traces = interpreter.execute_ast(program, context)
    assert any(getattr(t, 'phoxel_runtime_status', {}).get('image_anchor', {}).get('present') for t in traces)

    report = interpreter.get_execution_report()
    assert report['phoxel_runtime_status_summary']['explicit_trace_count'] >= 2
    assert report['phoxel_runtime_status_summary']['observation_status_counts']['validated'] >= 1


def test_runtime_obedience_report_inherits_trace_surface_phoxel_status_summary():
    resolution = {
        'final_environment': {'x': 1},
        'output_steps': [{'op': 'assign', 'target': 'x', 'value': 1, 'resolved': True}],
        'fully_resolved': True,
        'report_scope': 'runtime_resolution',
        'gate_clearance_authority': False,
        'world_authority_primary': True,
        'image_access_primary': True,
    }
    interpreted = {
        'final_environment': {'x': 1},
        'blocked_reasons': [],
        'outcome': 'complete',
        'report_scope': 'runtime_interpretation',
        'gate_clearance_authority': False,
        'world_authority_primary': True,
        'image_access_primary': True,
    }
    propagated = {
        'final_environment': {'x': 1},
        'timeline': [{'op': 'assign', 'resolved': True, 'environment_snapshot': {'x': 1}}],
        'statefully_resolved': True,
        'report_scope': 'runtime_state_propagation',
        'gate_clearance_authority': False,
        'world_authority_primary': True,
        'image_access_primary': True,
    }
    branch = {
        'base_environment': {'x': 1},
        'branch_states': [],
        'blocked_branch_count': 0,
        'report_scope': 'runtime_branch_state',
        'gate_clearance_authority': False,
        'world_authority_primary': True,
        'image_access_primary': True,
    }
    trace_surface = stamp_runtime_surface({
        'phoxel_runtime_status_explicit': True,
        'phoxel_runtime_status_rollup': {'explicit_count': 2, 'observation_status_counts': {'validated': 2}},
    }, 'runtime_execution_trace')
    plan_surface = stamp_runtime_surface({}, 'runtime_execution_plan')

    report = build_runtime_obedience_report(
        resolution,
        interpreted,
        propagated,
        branch,
        execution_plan_surface=plan_surface,
        execution_trace_surface=trace_surface,
    )
    assert report['checks']['planning_trace_surface_alignment'] is True
    assert report['report_surface_consistency']['execution_trace_phoxel_runtime_status_explicit'] is True
    assert report['report_surface_consistency']['execution_trace_phoxel_runtime_rollup']['explicit_count'] == 2
