from pathlib import Path
import sys
from enum import Enum
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "aurexis_lang" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.execution_semantics import ast_to_execution_plan
from aurexis_lang.execution_semantics_deeper import run_execution_plan
from aurexis_lang.execution_resolution import run_execution_resolution
from aurexis_lang.execution_interpretation import interpret_execution_result
from aurexis_lang.execution_state_propagation import propagate_execution_state
from aurexis_lang.branch_state_execution import run_branch_state_execution


class NodeType(Enum):
    ASSIGNMENT = "Assignment"
    BINARY = "BinaryExpression"
    CONTROL = "Control"


def _value_node(**value):
    return SimpleNamespace(value=value, children=[])


def test_runtime_failure_modes_keep_missing_target_and_unsupported_operator_explicit():
    ast = SimpleNamespace(children=[
        SimpleNamespace(
            node_type=NodeType.ASSIGNMENT,
            children=[_value_node(name='x'), _value_node(value='2')],
        ),
        SimpleNamespace(
            node_type=NodeType.ASSIGNMENT,
            children=[_value_node(value='3'), _value_node(value='4')],
        ),
        SimpleNamespace(
            node_type=NodeType.BINARY,
            children=[_value_node(value='x'), _value_node(value='^'), _value_node(value='5')],
        ),
        SimpleNamespace(
            node_type=NodeType.CONTROL,
            value={'keyword': 'if'},
            children=[],
        ),
    ])

    plan = ast_to_execution_plan(ast)
    assert plan['execution_steps'][1]['target'] is None

    result = run_execution_plan(plan)
    assert result['final_environment'] == {'x': 2}
    assert result['fully_resolved'] is False

    steps = result['output_steps']
    assert steps[1]['resolved'] is False
    assert steps[1]['reason'] == 'missing_target'
    assert steps[2]['resolved'] is False
    assert steps[2]['reason'] == 'unsupported_operator:^'
    assert steps[3]['reason'] == 'blocked_control_branch'

    interpreted = interpret_execution_result(result)
    assert interpreted['outcome'] == 'partial'
    assert interpreted['produced_values'] == [2]
    assert 'missing_target' in interpreted['blocked_reasons']
    assert 'unsupported_operator:^' in interpreted['blocked_reasons']
    assert 'blocked_control_branch' in interpreted['blocked_reasons']

    propagated = propagate_execution_state(result)
    assert propagated['blocked_step_count'] == 3
    assert propagated['timeline'][1]['reason'] == 'missing_target'
    assert propagated['timeline'][2]['reason'] == 'unsupported_operator:^'
    assert propagated['timeline'][3]['reason'] == 'blocked_control_branch'

    branch = run_branch_state_execution(result)
    assert branch['blocked_branch_count'] == 3
    assert {item['reason'] for item in branch['branch_states']} == {'missing_target', 'unsupported_operator:^', 'blocked_control_branch'}


def test_execution_resolution_keeps_missing_target_and_unknown_steps_honest():
    plan = {
        'execution_steps': [
            {'step_type': 'assignment', 'target': 'a', 'value': '1'},
            {'step_type': 'assignment', 'target': None, 'value': '2'},
            {'step_type': 'binary_expression', 'parts': ['a', '^', '1']},
            {'step_type': 'control', 'keyword': 'if'},
            {'step_type': 'mystery'},
        ]
    }

    result = run_execution_resolution(plan)
    assert result['resolved_count'] == 1
    assert result['unresolved_count'] == 4
    assert result['fully_resolved'] is False

    steps = result['output_steps']
    assert steps[1]['reason'] == 'missing_target'
    assert steps[2]['reason'] == 'unsupported_operator:^'
    assert steps[3]['reason'] == 'blocked_control_branch'
    assert steps[4]['reason'] == 'unsupported_step'

    interpreted = interpret_execution_result(result)
    assert interpreted['outcome'] == 'partial'
    assert interpreted['blocked_reasons'] == [
        'blocked_control_branch',
        'missing_target',
        'unsupported_operator:^',
        'unsupported_step',
    ]
