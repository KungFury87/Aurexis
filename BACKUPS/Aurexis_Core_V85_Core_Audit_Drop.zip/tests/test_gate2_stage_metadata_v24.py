from pathlib import Path
import sys
import json

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(ROOT / "aurexis_lang" / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "aurexis_lang" / "src"))

from aurexis_lang.execution_resolution import run_execution_resolution
from aurexis_lang.execution_interpretation import interpret_execution_result
from aurexis_lang.execution_state_propagation import propagate_execution_state
from aurexis_lang.branch_state_execution import run_branch_state_execution
from aurexis_lang.runtime_obedience import build_runtime_obedience_report
from gate_2_runtime_enforcement import RuntimeLawEnforcement


def test_runtime_stage_outputs_carry_v24_metadata_fields():
    plan = {
        'execution_steps': [
            {'step_type': 'assignment', 'target': 'x', 'value': 1},
            {'step_type': 'assignment', 'target': 'y', 'value_expr': ['x', '+', 4]},
        ]
    }
    surfaces = [
        run_execution_resolution(plan),
        interpret_execution_result(run_execution_resolution(plan)),
        propagate_execution_state(run_execution_resolution(plan)),
        run_branch_state_execution(run_execution_resolution(plan)),
    ]
    for surface in surfaces:
        assert surface['stage_metadata_version'] == 'AUREXIS_GATE_2_RUNTIME_STAGE_METADATA_RULES_V1'
        assert surface['report_surface_alignment_target'] == 'AUREXIS_GATE_2_REPORT_SURFACE_ALIGNMENT_RULES_V1'
        assert surface['partial_reporting_explicit'] is True
        assert surface['stage_metadata_complete'] is True


def test_gate2_scaffold_and_historical_artifact_carry_v24_stage_metadata():
    enforcer = RuntimeLawEnforcement()
    summary = enforcer.run_comprehensive_runtime_enforcement()
    assert summary['runtime_stage_metadata_complete'] is True
    assert summary['stage_metadata_version'] == 'AUREXIS_GATE_2_RUNTIME_STAGE_METADATA_RULES_V1'
    assert summary['report_surface_alignment_target'] == 'AUREXIS_GATE_2_REPORT_SURFACE_ALIGNMENT_RULES_V1'

    artifact = json.loads((ROOT / 'gate_2_results' / 'gate_2_enforcement_20260406_154157.json').read_text(encoding='utf-8'))
    assert artifact['authority_status'] == 'non_authoritative_historical_artifact'
    assert artifact['stage_metadata_version'] == 'AUREXIS_GATE_2_RUNTIME_STAGE_METADATA_RULES_V1'
    assert artifact['report_surface_consistency']['stage_metadata_complete'] is True
