from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "aurexis_lang" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.control_resolution import summarize_control_resolution
from aurexis_lang.control_flow_state_machine import control_steps_to_transitions, step_state_machine
from aurexis_lang.execution_resolution import run_execution_resolution
from aurexis_lang.execution_semantics_deeper import run_execution_plan
from aurexis_lang.execution_interpretation import interpret_execution_result
from aurexis_lang.execution_state_propagation import propagate_execution_state
from aurexis_lang.branch_state_execution import run_branch_state_execution


def test_nested_control_flow_preserves_path_labels_when_context_is_provided():
    summary = summarize_control_resolution([
        {"keyword": "if", "condition_value": {"condition": True, "depth": 1, "parent_path": "root"}},
        {"keyword": "while", "condition_value": {"condition": False, "depth": 2, "parent_path": "root/if::then"}},
        {"keyword": "for", "condition_value": {"iterable": [1, 2], "depth": 3, "parent_path": "root/if::then/while::exit"}},
        {"keyword": "for", "condition_value": {"iterable": None, "depth": 3, "parent_path": "root/if::then/while::exit"}},
    ])

    outputs = summary["outputs"]
    assert outputs[0]["path_label"] == "root/if::then"
    assert outputs[1]["path_label"] == "root/if::then/while::exit"
    assert outputs[2]["path_label"] == "root/if::then/while::exit/for::iterate"
    assert outputs[3]["resolved"] is False
    assert outputs[3]["reason"] == "unknown_iterable"
    assert outputs[3]["path_label"] == "root/if::then/while::exit/for::blocked"

    transitions = control_steps_to_transitions(summary)
    machine = step_state_machine(transitions)
    assert machine["timeline"][0]["current_state_after_step"] == "root/if::then"
    assert machine["timeline"][1]["current_state_after_step"] == "root/if::then/while::exit"
    assert machine["timeline"][2]["current_state_after_step"] == "root/if::then/while::exit/for::iterate"
    assert machine["timeline"][3]["resolved"] is False
    assert machine["blocked_transition_count"] == 1


def test_mixed_type_numeric_and_comparison_failures_stay_explicit_across_runtime_chain():
    plan = {
        "execution_steps": [
            {"step_type": "assignment", "target": "x", "value": [1, 2]},
            {"step_type": "binary_expression", "parts": ["x", "+", 2]},
            {"step_type": "binary_expression", "parts": ["x", ">", 1]},
            {"step_type": "control", "keyword": "while"},
        ]
    }

    result = run_execution_plan(plan)
    steps = result["output_steps"]
    assert steps[1]["reason"] == "non_numeric_operands"
    assert steps[2]["reason"] == "comparison_not_supported"
    assert steps[3]["reason"] == "blocked_control_branch"

    interpreted = interpret_execution_result(result)
    assert interpreted["outcome"] == "partial"
    assert "non_numeric_operands" in interpreted["blocked_reasons"]
    assert "comparison_not_supported" in interpreted["blocked_reasons"]
    assert "blocked_control_branch" in interpreted["blocked_reasons"]

    propagated = propagate_execution_state(result)
    assert propagated["blocked_step_count"] == 3
    assert propagated["timeline"][1]["reason"] == "non_numeric_operands"
    assert propagated["timeline"][2]["reason"] == "comparison_not_supported"

    branch = run_branch_state_execution(result)
    assert branch["blocked_branch_count"] == 3
    assert {item["reason"] for item in branch["branch_states"]} == {
        "non_numeric_operands",
        "comparison_not_supported",
        "blocked_control_branch",
    }


def test_execution_resolution_mixed_resolution_keeps_successful_outputs_without_hiding_failures():
    plan = {
        "execution_steps": [
            {"step_type": "assignment", "target": "a", "value": "5"},
            {"step_type": "binary_expression", "parts": ["a", "*", "3"]},
            {"step_type": "binary_expression", "parts": ["a", "/", "0"]},
            {"step_type": "binary_expression", "parts": ["a", "@", "3"]},
        ]
    }

    result = run_execution_resolution(plan)
    assert result["resolved_count"] == 2
    assert result["unresolved_count"] == 2
    assert result["output_steps"][1]["result"] == 15
    assert result["output_steps"][2]["reason"] == "division_by_zero"
    assert result["output_steps"][3]["reason"] == "unsupported_operator:@"

    interpreted = interpret_execution_result(result)
    assert interpreted["produced_values"] == [5, 15]
    assert interpreted["blocked_reasons"] == ["division_by_zero", "unsupported_operator:@"]
