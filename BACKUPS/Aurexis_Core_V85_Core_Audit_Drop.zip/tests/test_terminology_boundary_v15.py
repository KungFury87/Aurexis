from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_remaining_active_phixel_mentions_are_reduced_to_shim_only_boundary():
    active_files = [
        ROOT / "phase1_language_implementation.py",
        ROOT / "phase1_parser_implementation.py",
        ROOT / "phase1_parser_simple.py",
        ROOT / "aurexis_lang" / "src" / "aurexis_lang" / "terminology.py",
    ]
    total = 0
    for path in active_files:
        total += path.read_text().count("phixel")
    assert total <= 8


def test_live_active_src_has_no_phixel_mentions_outside_shim_boundary():
    src_root = ROOT / "aurexis_lang" / "src" / "aurexis_lang"
    offenders = []
    for path in src_root.glob("*.py"):
        if path.name != "terminology.py":
            text = path.read_text()
            if "phixel" in text:
                offenders.append(path.name)
    assert offenders == []
