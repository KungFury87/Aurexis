from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_remaining_active_phixel_mentions_are_intentional_shims_only():
    active_files = [
        ROOT / 'phase1_language_implementation.py',
        ROOT / 'phase1_parser_implementation.py',
        ROOT / 'phase1_parser_simple.py',
        ROOT / 'aurexis_lang' / 'src' / 'aurexis_lang' / 'terminology.py',
    ]
    total = 0
    for path in active_files:
        text = path.read_text()
        total += text.count('phixel')
        assert 'legacy compatibility' in text.lower()
    assert total > 0


def test_active_live_src_has_no_uncontrolled_phixel_mentions_outside_terminology():
    src_root = ROOT / 'aurexis_lang' / 'src' / 'aurexis_lang'
    offenders = []
    for path in src_root.glob('*.py'):
        if path.name == 'terminology.py':
            continue
        text = path.read_text()
        if 'phixel' in text:
            offenders.append(path.name)
    assert offenders == []
