from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(ROOT / "aurexis_lang" / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "aurexis_lang" / "src"))

from aurexis_lang.execution_semantics import ast_to_execution_plan
from aurexis_lang.execution_trace import ast_to_trace
from aurexis_lang.execution_resolution import run_execution_resolution
from aurexis_lang.execution_interpretation import interpret_execution_result
from aurexis_lang.execution_state_propagation import propagate_execution_state
from aurexis_lang.branch_state_execution import run_branch_state_execution
from aurexis_lang.control_resolution import summarize_control_resolution
from aurexis_lang.control_flow_state_machine import control_steps_to_transitions, step_state_machine, summarize_control_transitions
from aurexis_lang.execution_semantics_deeper import run_execution_plan
from aurexis_lang.runtime_obedience import evaluate_runtime_obedience
from gate_2_runtime_enforcement import RuntimeLawEnforcement


class StubNode:
    def __init__(self, node_type, value=None, children=None):
        self.node_type = node_type
        self.value = value or {}
        self.children = children or []


def make_ast():
    assign_a = StubNode('Assignment', {}, [StubNode('Identifier', {'name': 'a'}), StubNode('Literal', {'value': 1})])
    assign_b = StubNode('Assignment', {}, [StubNode('Identifier', {'name': 'b'}), StubNode('BinaryExpression', {}, [StubNode('Identifier', {'name': 'a'}), StubNode('Operator', {'value': '+'}), StubNode('Literal', {'value': 2})])])
    control = StubNode('Control', {'keyword': 'if', 'condition_value': ['b', '>', 2]}, [])
    return StubNode('Program', {'confidence': {'mean': 0.9}}, [assign_a, assign_b, control])


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


def test_gate2_v27_docs_exist_and_name_plan_trace_rules():
    trace_rules = read('AUREXIS_GATE_2_RUNTIME_TRACE_SURFACE_RULES_V1.md')
    nested_rules = read('AUREXIS_GATE_2_NESTED_CONTROL_PATTERN_RULES_V1.md')
    assert '`runtime_execution_plan`' in trace_rules
    assert '`runtime_execution_trace`' in trace_rules
    assert 'successful mutations that occur before a nested blocked control step must survive' in nested_rules


def test_plan_and_trace_surfaces_are_stamped_and_aligned():
    ast = make_ast()
    plan_surface = ast_to_execution_plan(ast)
    trace_surface = ast_to_trace(ast)
    assert plan_surface['report_scope'] == 'runtime_execution_plan'
    assert trace_surface['report_scope'] == 'runtime_execution_trace'
    assert plan_surface['gate_2_status'] == 'IN_PROGRESS'
    assert trace_surface['gate_2_status'] == 'IN_PROGRESS'
    assert plan_surface['stage_metadata_complete'] is True
    assert trace_surface['stage_metadata_complete'] is True


def test_nested_control_pattern_honesty_includes_plan_trace_surfaces():
    ast = make_ast()
    plan_surface = ast_to_execution_plan(ast)
    trace_surface = ast_to_trace(ast)
    plan = {
        'execution_steps': [
            {'step_type': 'assignment', 'target': 'seed', 'value': 1},
            {'step_type': 'control', 'keyword': 'for', 'iterable': [1, 2], 'loop_variable': 'i', 'body_steps': [
                {'step_type': 'assignment', 'target': 'seed', 'value_expr': ['seed', '+', 1]},
                {'step_type': 'control', 'keyword': 'if', 'condition_value': None, 'then_steps': [{'step_type': 'assignment', 'target': 'x', 'value': 9}], 'else_steps': []},
            ]},
        ]
    }
    resolution = run_execution_resolution(plan)
    interpreted = interpret_execution_result(resolution)
    propagated = propagate_execution_state(resolution)
    branch = run_branch_state_execution(resolution)
    deeper_execution = run_execution_plan(plan)
    control_summary = summarize_control_resolution([{'keyword': 'for', 'condition_value': [1, 2]}, {'keyword': 'if', 'condition_value': None}])
    control_transitions = summarize_control_transitions(control_summary)
    control_machine = step_state_machine(control_steps_to_transitions(control_summary))
    obedience = evaluate_runtime_obedience(
        resolution, interpreted, propagated, branch, control_summary, control_machine, deeper_execution, control_transitions, plan_surface, trace_surface
    )
    assert obedience['checks']['planning_trace_surface_alignment'] is True
    assert obedience['checks']['nested_control_pattern_honest'] is True
    assert propagated['final_environment']['seed'] == 2
    assert 'blocked_control_branch' in obedience['propagated_reasons']


def test_gate2_scaffold_summary_exposes_plan_trace_alignment():
    enforcer = RuntimeLawEnforcement()
    summary = enforcer.run_comprehensive_runtime_enforcement()
    assert summary['gate_2_status'] == 'IN_PROGRESS'
    assert summary['planning_trace_surface_alignment'] is True
