from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "aurexis_lang" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.terminology import get_phoxel_record, canonicalize_record_keys, with_legacy_alias


def test_get_phoxel_record_accepts_legacy_and_canonical_keys():
    legacy = {"phixel_record": {"pixel_coordinates": [1, 2]}}
    canonical = {"phoxel_record": {"pixel_coordinates": [3, 4]}}
    assert get_phoxel_record(legacy)["pixel_coordinates"] == [1, 2]
    assert get_phoxel_record(canonical)["pixel_coordinates"] == [3, 4]


def test_canonicalize_record_keys_promotes_legacy_key():
    data = canonicalize_record_keys({"phixel_record": {"pixel_coordinates": [5, 6]}})
    assert data["phoxel_record"]["pixel_coordinates"] == [5, 6]


def test_with_legacy_alias_keeps_both_keys():
    data = with_legacy_alias({"phoxel_record": {"pixel_coordinates": [7, 8]}})
    assert data["phoxel_record"]["pixel_coordinates"] == [7, 8]
    assert data["phixel_record"]["pixel_coordinates"] == [7, 8]
