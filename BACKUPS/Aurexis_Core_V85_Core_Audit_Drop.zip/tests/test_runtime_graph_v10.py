from pathlib import Path
import sys
from enum import Enum
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "aurexis_lang" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.runtime_control import evaluate_program_graph
from aurexis_lang.execution_interpretation import interpret_execution_result
from aurexis_lang.execution_state_propagation import propagate_execution_state


class EdgeType(Enum):
    DATA = "data"
    CONTROL = "control"


def test_runtime_control_graph_normalizes_enum_edge_types():
    graph = SimpleNamespace(
        nodes=[object(), object(), object()],
        edges=[
            SimpleNamespace(edge_type=EdgeType.DATA),
            SimpleNamespace(edge_type=EdgeType.CONTROL),
            SimpleNamespace(edge_type=EdgeType.DATA),
        ],
    )

    result = evaluate_program_graph(graph)
    assert result["status"] == "control_scope_stub"
    assert result["node_count"] == 3
    assert result["edge_count"] == 3
    assert result["edge_types"] == ["control", "data"]


def test_interpretation_and_state_propagation_keep_unresolved_paths_honest():
    result = {
        "final_environment": {"x": 2},
        "output_steps": [
            {"op": "assign", "target": "x", "value": 2, "resolved": True},
            {"op": "binary_expr", "parts": ["x", "+", "missing"], "result": None, "resolved": False},
            {"op": "control", "resolved": False},
        ],
        "fully_resolved": False,
    }

    interpreted = interpret_execution_result(result)
    assert interpreted["outcome"] == "partial"
    assert interpreted["produced_values"] == [2]
    assert interpreted["blocked_reasons"] == ["binary_expr_unresolved", "control_unresolved"]

    propagated = propagate_execution_state(result)
    assert propagated["final_environment"] == {"x": 2}
    assert propagated["blocked_step_count"] == 2
    assert propagated["statefully_resolved"] is False
    assert all(isinstance(item["resolved"], bool) for item in propagated["timeline"])
