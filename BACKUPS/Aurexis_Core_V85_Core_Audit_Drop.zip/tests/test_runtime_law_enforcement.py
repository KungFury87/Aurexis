from pathlib import Path
import sys
import importlib.util
from datetime import datetime

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'aurexis_lang' / 'src'
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.core_law_enforcer import CoreLawEnforcer, enforce_core_law, CoreLawSection


def load_module(name: str, relative: str):
    path = ROOT / relative
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def test_world_image_authority_accepts_dual_register_case():
    enforcer = CoreLawEnforcer(strict_mode=True)
    violations = enforcer.validate_world_image_authority(
        {
            'type': 'interpretation',
            'world_authority': True,
            'image_access': True,
            'dual_register_processing': True,
        }
    )
    assert violations == []


def test_world_image_authority_rejects_image_as_final_world_truth():
    enforcer = CoreLawEnforcer(strict_mode=True)
    violations = enforcer.validate_world_image_authority(
        {
            'type': 'interpretation',
            'image_as_final_world_truth': True,
        }
    )
    assert any(v.section == CoreLawSection.WORLD_IMAGE_AUTHORITY for v in violations)
    assert any('final world authority' in v.description.lower() for v in violations)


def test_executable_promotion_requires_validation_and_multiframe_support():
    passed, violations = enforce_core_law(
        {
            'type': 'executable',
            'evidence_validated': True,
            'multi_frame_consistent': True,
            'geometric_coherence': True,
            'cross_register_consistency': True,
            'language_legal': True,
            'bounded_inference': True,
            'confidence': 0.82,
            'promotion_by_assumption': False,
            'unresolved_reasons': [],
        }
    )
    assert passed is True
    assert violations == []

    failed, violations = enforce_core_law(
        {
            'type': 'executable',
            'evidence_validated': True,
            'multi_frame_consistent': False,
            'geometric_coherence': True,
            'cross_register_consistency': True,
            'language_legal': True,
            'bounded_inference': True,
            'confidence': 0.82,
            'promotion_by_assumption': False,
            'unresolved_reasons': [],
        }
    )
    assert failed is False
    assert any(v.section == CoreLawSection.EXECUTABLE_PROMOTION for v in violations)


def test_active_phase1_surfaces_expose_phoxel_and_legacy_aliases():
    lang = load_module('phase1_language_implementation', 'phase1_language_implementation.py')
    parser = load_module('phase1_parser_implementation', 'phase1_parser_implementation.py')

    record = lang.PhoxelRecord(
        pixel_coordinates=(1, 2),
        image_timestamp=datetime.now(),
        camera_metadata={'scene_name': 'test'},
        evidence_chain=['camera:test'],
        pixel_data_available=True,
        synthetic=False,
    )

    primitive = lang.VisualPrimitive(
        primitive_id='p1',
        primitive_type=lang.PrimitiveType.COLOR_REGION,
        phixel_record=record,
        attributes={},
        confidence=0.7,
        execution_status=lang.ExecutionStatus.DESCRIPTIVE,
        evidence_chain=['camera:test'],
        synthetic=False,
    )
    token = lang.AurexisToken(
        token_id='t1',
        token_type='primitive',
        phixel_record=record,
        primitive_data=primitive,
        relation_data=None,
        confidence=0.7,
        evidence_validated=True,
    )
    node = parser.ASTNode(
        node_type=parser.ASTNodeType.PRIMITIVE_DECLARATION,
        node_id='n1',
        phoxel_record=record,
        attributes={},
        confidence=0.7,
        evidence_validated=True,
        synthetic=False,
    )

    assert primitive.phoxel_record is primitive.phixel_record
    assert token.phoxel_record is token.phixel_record
    assert node.phixel_record is node.phoxel_record
