from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(ROOT / 'aurexis_lang' / 'src') not in sys.path:
    sys.path.insert(0, str(ROOT / 'aurexis_lang' / 'src'))

from aurexis_lang.execution_resolution import run_execution_resolution
from aurexis_lang.execution_semantics_deeper import run_execution_plan
from aurexis_lang.execution_interpretation import interpret_execution_result
from aurexis_lang.execution_state_propagation import propagate_execution_state
from aurexis_lang.branch_state_execution import run_branch_state_execution
from aurexis_lang.control_resolution import summarize_control_resolution
from aurexis_lang.control_flow_state_machine import control_steps_to_transitions, step_state_machine, summarize_control_transitions
from aurexis_lang.runtime_obedience import evaluate_runtime_obedience
from gate_2_runtime_enforcement import RuntimeLawEnforcement


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


def test_gate2_v26_docs_exist_and_name_deeper_surfaces_and_nested_loop_rules():
    deeper = read('AUREXIS_GATE_2_DEEPER_RUNTIME_SURFACE_RULES_V1.md')
    nested = read('AUREXIS_GATE_2_NESTED_LOOP_TRANSITION_RULES_V1.md')
    assert '`runtime_deeper_execution`' in deeper
    assert '`runtime_control_transitions`' in deeper
    assert 'surviving resolved state must remain visible after later blocked nested control' in nested


def test_deeper_execution_and_control_transition_surfaces_are_stamped_and_checked():
    plan = {
        'execution_steps': [
            {'step_type': 'assignment', 'target': 'x', 'value': 0},
            {'step_type': 'control', 'keyword': 'while', 'condition_value': {'parts': ['x', '<', 2]}, 'body_steps': [
                {'step_type': 'assignment', 'target': 'x', 'value': {'parts': ['x', '+', 1]}},
                {'step_type': 'control', 'keyword': 'if', 'condition_value': None, 'body_steps': [
                    {'step_type': 'assignment', 'target': 'y', 'value': 2},
                ]},
            ], 'max_iterations': 4},
        ]
    }
    resolution = run_execution_resolution(plan)
    deeper_execution = run_execution_plan(plan)
    interpreted = interpret_execution_result(resolution)
    propagated = propagate_execution_state(resolution)
    branch = run_branch_state_execution(resolution)
    control_summary = summarize_control_resolution([
        {'keyword': 'while', 'condition_value': {'condition': True, 'depth': 1, 'parent_path': 'root'}},
        {'keyword': 'if', 'condition_value': {'condition': None, 'depth': 2, 'parent_path': 'root/while::loop'}},
    ])
    control_transitions = summarize_control_transitions(control_summary)
    control_machine = step_state_machine(control_steps_to_transitions(control_summary))
    obedience = evaluate_runtime_obedience(
        resolution, interpreted, propagated, branch,
        control_summary, control_machine, deeper_execution, control_transitions
    )
    assert deeper_execution['report_scope'] == 'runtime_deeper_execution'
    assert control_transitions['report_scope'] == 'runtime_control_transitions'
    assert obedience['checks']['deeper_runtime_surface_alignment'] is True
    assert obedience['checks']['control_transition_surface_alignment'] is True
    assert obedience['checks']['nested_loop_failure_honest'] is True
    assert 'blocked_control_branch' in obedience['propagated_reasons']


def test_gate2_scaffold_summary_exposes_deeper_surface_alignment():
    enforcer = RuntimeLawEnforcement()
    summary = enforcer.run_comprehensive_runtime_enforcement()
    assert summary['gate_2_status'] == 'IN_PROGRESS'
    assert summary['deeper_runtime_surface_alignment'] is True
    assert summary['control_transition_surface_alignment'] is True
