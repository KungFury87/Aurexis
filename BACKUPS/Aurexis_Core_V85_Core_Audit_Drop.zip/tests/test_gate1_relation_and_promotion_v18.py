from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "aurexis_lang" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.relation_legality import validate_relation_legality
from aurexis_lang.executable_promotion import validate_executable_promotion_checklist
from aurexis_lang.core_law_enforcer import enforce_core_law, CoreLawSection


def _text(path: str) -> str:
    return Path(path).read_text(encoding="utf-8")


def test_relation_legality_doc_freezes_required_fields():
    text = _text("AUREXIS_RELATION_LEGALITY_MEASURABLE_REQUIREMENTS_V1.md")
    for needle in [
        "`relation_kind`",
        "`source_id`",
        "`target_id`",
        "`physical_measurement`",
        "`pixel_space_verification`",
    ]:
        assert needle in text


def test_executable_promotion_checklist_doc_freezes_required_gates():
    text = _text("AUREXIS_EXECUTABLE_PROMOTION_CHECKLIST_V1.md")
    for needle in [
        "`evidence_validated`",
        "`multi_frame_consistent`",
        "`geometric_coherence`",
        "`cross_register_consistency`",
        "`language_legal`",
        "`bounded_inference`",
        "confidence >= 0.7",
    ]:
        assert needle in text


def test_relation_legality_accepts_measured_image_grounded_relation():
    errors = validate_relation_legality({
        "relation_kind": "adjacency",
        "source_id": "a",
        "target_id": "b",
        "physical_measurement": {"measurement_type": "distance_px", "distance_px": 1},
        "pixel_space_verification": {"image_grounded": True, "verification_method": "boundary-check"},
    })
    assert errors == []


def test_relation_legality_rejects_missing_measurement_and_abstract_semantic():
    errors = validate_relation_legality({
        "relation_kind": "adjacency",
        "source_id": "a",
        "target_id": "b",
        "pixel_space_verification": {"image_grounded": True, "verification_method": "boundary-check"},
        "abstract_semantic": True,
    })
    assert "missing_physical_measurement" in errors
    assert "forbidden_abstract_semantic" in errors


def test_executable_promotion_checklist_accepts_fully_gated_candidate():
    errors = validate_executable_promotion_checklist({
        "evidence_validated": True,
        "multi_frame_consistent": True,
        "geometric_coherence": True,
        "cross_register_consistency": True,
        "language_legal": True,
        "bounded_inference": True,
        "confidence": 0.81,
        "unresolved_reasons": [],
        "promotion_by_assumption": False,
    })
    assert errors == []


def test_executable_promotion_checklist_rejects_unresolved_and_assumed_candidate():
    errors = validate_executable_promotion_checklist({
        "evidence_validated": True,
        "multi_frame_consistent": True,
        "geometric_coherence": True,
        "cross_register_consistency": True,
        "language_legal": True,
        "bounded_inference": True,
        "confidence": 0.81,
        "unresolved_reasons": ["blocked_control_branch"],
        "promotion_by_assumption": True,
    })
    assert "has_unresolved_reasons" in errors
    assert "promotion_by_assumption" in errors


def test_enforcer_uses_relation_legality_freeze():
    passed, violations = enforce_core_law({
        "type": "relation",
        "relation_kind": "adjacency",
        "source_id": "a",
        "target_id": "b",
        "pixel_space_verification": {"image_grounded": True, "verification_method": "boundary-check"},
    })
    assert passed is False
    assert any(v.section == CoreLawSection.NATIVE_RELATIONS for v in violations)
    assert any("missing_physical_measurement" in v.description for v in violations)


def test_enforcer_uses_executable_promotion_freeze():
    passed, violations = enforce_core_law({
        "type": "executable",
        "evidence_validated": True,
        "multi_frame_consistent": True,
        "confidence": 0.9,
        "promotion_by_assumption": False,
        "unresolved_reasons": [],
    })
    assert passed is False
    assert any(v.section == CoreLawSection.EXECUTABLE_PROMOTION for v in violations)
    joined = " ".join(v.description for v in violations)
    assert "missing_geometric_coherence" in joined
    assert "missing_cross_register_consistency" in joined
