from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "aurexis_lang" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.execution_resolution import run_execution_resolution
from aurexis_lang.execution_semantics_deeper import run_execution_plan
from aurexis_lang.execution_interpretation import interpret_execution_result
from aurexis_lang.execution_state_propagation import propagate_execution_state
from aurexis_lang.branch_state_execution import run_branch_state_execution


def test_loop_body_execution_mutates_environment_end_to_end():
    plan = {
        "execution_steps": [
            {"step_type": "assignment", "target": "x", "value": "0"},
            {"step_type": "assignment", "target": "total", "value": "0"},
            {
                "step_type": "control",
                "keyword": "while",
                "condition_value": {"parts": ["x", "<", "2"]},
                "body_steps": [
                    {"step_type": "assignment", "target": "x", "value": {"parts": ["x", "+", "1"]}},
                    {"step_type": "assignment", "target": "total", "value": {"parts": ["total", "+", "x"]}},
                ],
                "max_iterations": 4,
            },
            {
                "step_type": "control",
                "keyword": "for",
                "iterable": [4, 5],
                "loop_variable": "item",
                "body_steps": [
                    {"step_type": "assignment", "target": "total", "value": {"parts": ["total", "+", "item"]}},
                ],
            },
        ]
    }

    result = run_execution_resolution(plan)
    assert result["fully_resolved"] is True
    assert result["final_environment"]["x"] == 2
    assert result["final_environment"]["total"] == 12
    assert result["output_steps"][2]["keyword"] == "while"
    assert result["output_steps"][2]["iterations"] == 2
    assert result["output_steps"][3]["keyword"] == "for"
    assert result["output_steps"][3]["iterations"] == 2

    interpreted = interpret_execution_result(result)
    assert interpreted["outcome"] == "complete"
    assert interpreted["blocked_reasons"] == []
    assert 12 in interpreted["produced_values"]

    propagated = propagate_execution_state(result)
    assert propagated["statefully_resolved"] is True
    assert propagated["final_environment"]["total"] == 12

    branch = run_branch_state_execution(result)
    assert branch["blocked_branch_count"] == 0


def test_nested_blocked_control_inside_block_stays_explicit_end_to_end():
    plan = {
        "execution_steps": [
            {"step_type": "assignment", "target": "x", "value": "1"},
            {
                "step_type": "block",
                "nested_steps": [
                    {
                        "step_type": "control",
                        "keyword": "if",
                        "condition_value": "maybe",
                        "body_steps": [
                            {"step_type": "assignment", "target": "y", "value": "2"},
                        ],
                    }
                ],
            },
        ]
    }

    result = run_execution_plan(plan)
    assert result["fully_resolved"] is False
    block = result["output_steps"][1]
    assert block["resolved"] is False
    assert block["reason"] == "blocked_nested_block"
    nested_control = block["nested_output_steps"][0]
    assert nested_control["op"] == "control"
    assert nested_control["resolved"] is False
    assert nested_control["reason"] == "unknown_condition"

    interpreted = interpret_execution_result(result)
    assert interpreted["outcome"] == "partial"
    assert "blocked_nested_block" in interpreted["blocked_reasons"]
    assert "unknown_condition" in interpreted["blocked_reasons"]

    propagated = propagate_execution_state(result)
    assert propagated["blocked_step_count"] == 2
    assert propagated["timeline"][1]["reason"] == "blocked_nested_block"
    assert propagated["timeline"][2]["reason"] == "unknown_condition"

    branch = run_branch_state_execution(result)
    assert branch["blocked_branch_count"] == 2
    assert {item["reason"] for item in branch["branch_states"]} == {"blocked_nested_block", "unknown_condition"}
