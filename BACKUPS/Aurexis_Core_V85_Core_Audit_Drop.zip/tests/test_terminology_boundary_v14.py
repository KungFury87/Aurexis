from pathlib import Path


def test_parser_surfaces_prefer_canonical_phoxel_type_hints_and_keep_legacy_compatibility_boundary():
    files = [
        Path('phase1_parser_implementation.py'),
        Path('phase1_parser_simple.py'),
    ]
    for path in files:
        text = path.read_text()
        assert 'phoxel_record: PhoxelRecord' in text
        assert 'LEGACY_RECORD_KEY' in text
        assert '__getattr__' in text or 'def phixel_record(self) -> PhoxelRecord:' in text
