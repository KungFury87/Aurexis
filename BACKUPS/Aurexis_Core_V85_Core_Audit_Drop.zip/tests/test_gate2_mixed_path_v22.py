from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(ROOT / "aurexis_lang" / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "aurexis_lang" / "src"))

from aurexis_lang.execution_resolution import run_execution_resolution
from aurexis_lang.execution_interpretation import interpret_execution_result
from aurexis_lang.execution_state_propagation import propagate_execution_state
from aurexis_lang.branch_state_execution import run_branch_state_execution
from aurexis_lang.runtime_obedience import evaluate_runtime_obedience, build_runtime_obedience_report
from gate_2_runtime_enforcement import RuntimeLawEnforcement


def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def test_gate2_v22_docs_exist_and_name_mixed_path_rules():
    rules = read('AUREXIS_GATE_2_MIXED_PATH_STATE_MUTATION_RULES_V1.md')
    fails = read('AUREXIS_GATE_2_FAILURE_PROPAGATION_RULES_V1.md')
    assert 'successful assignments must survive even when later steps fail' in rules
    assert 'unresolved reasons from resolution must survive into interpretation' in fails
    assert 'Gate 2 report surfaces must remain `IN_PROGRESS`' in fails


def test_runtime_obedience_keeps_mixed_path_state_and_reasons_consistent():
    plan = {
        'execution_steps': [
            {'step_type': 'assignment', 'target': 'x', 'value': 2},
            {'step_type': 'assignment', 'target': 'y', 'value_expr': ['x', '+', 1]},
            {'step_type': 'assignment', 'target': 'z', 'value_expr': ['x', '/', 'a']},
            {'step_type': 'assignment', 'target': 'flag', 'value_expr': ['y', '>', 2]},
        ]
    }
    resolution = run_execution_resolution(plan)
    interpreted = interpret_execution_result(resolution)
    propagated = propagate_execution_state(resolution)
    branch = run_branch_state_execution(resolution)
    obedience = evaluate_runtime_obedience(resolution, interpreted, propagated, branch)
    assert obedience['checks']['state_mutation_consistent'] is True
    assert obedience['checks']['failure_reasons_propagated'] is True
    assert obedience['checks']['mixed_path_state_consistent'] is True
    assert ('x', 2) in obedience['resolution_assignment_trace']
    assert ('y', 3) in obedience['resolution_assignment_trace']
    assert ('flag', True) in obedience['propagated_assignment_trace']
    assert 'non_numeric_operands' in obedience['propagated_reasons']


def test_runtime_obedience_report_exposes_reporting_rule_surface():
    plan = {
        'execution_steps': [
            {'step_type': 'assignment', 'target': 'x', 'value': 1},
            {'step_type': 'assignment', 'target': 'y', 'value_expr': ['x', '+', 2]},
        ]
    }
    resolution = run_execution_resolution(plan)
    interpreted = interpret_execution_result(resolution)
    propagated = propagate_execution_state(resolution)
    branch = run_branch_state_execution(resolution)
    report = build_runtime_obedience_report(resolution, interpreted, propagated, branch)
    assert report['reporting_rules_version'] == 'AUREXIS_RUNTIME_OBEDIENCE_REPORTING_RULES_V1'
    assert report['report_surface_consistency']['gate_status'] == 'IN_PROGRESS'
    assert report['evidence']['evidence_tier'] == 'authored'


def test_gate2_scaffold_summary_stays_in_progress_and_explicit():
    enforcer = RuntimeLawEnforcement()
    summary = enforcer.run_comprehensive_runtime_enforcement()
    assert summary['gate_2_status'] == 'IN_PROGRESS'
    assert summary['mixed_path_reporting_explicit'] is True
    assert summary['reporting_rules_version'] == 'AUREXIS_RUNTIME_OBEDIENCE_REPORTING_RULES_V1'
