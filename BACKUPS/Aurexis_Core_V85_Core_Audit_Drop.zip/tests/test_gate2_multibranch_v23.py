from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(ROOT / "aurexis_lang" / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "aurexis_lang" / "src"))

from aurexis_lang.execution_resolution import run_execution_resolution
from aurexis_lang.execution_interpretation import interpret_execution_result
from aurexis_lang.execution_state_propagation import propagate_execution_state
from aurexis_lang.branch_state_execution import run_branch_state_execution
from aurexis_lang.runtime_obedience import evaluate_runtime_obedience
from gate_2_runtime_enforcement import RuntimeLawEnforcement


def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def test_gate2_v23_docs_exist_and_name_multibranch_and_alignment_rules():
    mult = read('AUREXIS_GATE_2_MULTI_BRANCH_RUNTIME_RULES_V1.md')
    align = read('AUREXIS_GATE_2_REPORT_SURFACE_ALIGNMENT_RULES_V1.md')
    assert 'successful assignments must survive later failures in other branches' in mult
    assert '`gate_2_status`: `IN_PROGRESS`' in align
    assert '`report_scope`: runtime-stage-specific value beginning with `runtime_`' in align


def test_runtime_stage_outputs_carry_aligned_gate2_reporting_metadata():
    plan = {
        'execution_steps': [
            {'step_type': 'assignment', 'target': 'x', 'value': 1},
            {'step_type': 'assignment', 'target': 'a', 'value_expr': ['x', '+', 4]},
            {'step_type': 'control', 'keyword': 'if', 'condition_value': ['a', '>', 3],
             'then_steps': [{'step_type': 'assignment', 'target': 'b', 'value': 9}],
             'else_steps': [{'step_type': 'assignment', 'target': 'b', 'value': 0}]},
            {'step_type': 'assignment', 'target': 'bad', 'value_expr': ['b', '/', 0]},
            {'step_type': 'assignment', 'target': 'c', 'value_expr': ['b', '+', 1]},
        ]
    }
    resolution = run_execution_resolution(plan)
    interpreted = interpret_execution_result(resolution)
    propagated = propagate_execution_state(resolution)
    branch = run_branch_state_execution(resolution)
    obedience = evaluate_runtime_obedience(resolution, interpreted, propagated, branch)
    assert obedience['checks']['report_surface_alignment'] is True
    assert obedience['checks']['mixed_path_state_consistent'] is True
    assert obedience['checks']['multi_branch_reason_consistent'] is True
    assert resolution['gate_2_status'] == 'IN_PROGRESS'
    assert interpreted['report_scope'] == 'runtime_interpretation'
    assert propagated['report_scope'] == 'runtime_state_propagation'
    assert branch['report_scope'] == 'runtime_branch_state'
    assert ('a', 5) in obedience['resolution_assignment_trace']
    assert ('b', 9) in obedience['propagated_assignment_trace']
    assert ('c', 10) in obedience['propagated_assignment_trace']
    assert 'division_by_zero' in obedience['propagated_reasons']


def test_gate2_scaffold_summary_now_exposes_report_surface_alignment():
    enforcer = RuntimeLawEnforcement()
    summary = enforcer.run_comprehensive_runtime_enforcement()
    assert summary['gate_2_status'] == 'IN_PROGRESS'
    assert summary['report_surface_alignment'] is True
    assert summary['mixed_path_reporting_explicit'] is True
