import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import phase1_language_implementation as p1
from aurexis_lang.terminology import LEGACY_RECORD_KEY


def _make_record():
    from datetime import datetime
    return p1.PhoxelRecord(
        pixel_coordinates=(1, 2),
        image_timestamp=datetime.now(),
        camera_metadata={},
        evidence_chain=["frame_0"],
        pixel_data_available=True,
        synthetic=False,
    )


def test_visualprimitive_legacy_record_shim_works_without_live_literal_field():
    record = _make_record()
    obj = p1.VisualPrimitive(
        primitive_id="p1",
        primitive_type=p1.PrimitiveType.COLOR_REGION,
        phoxel_record=record,
    )
    assert obj.phoxel_record is record
    assert getattr(obj, LEGACY_RECORD_KEY) is record


def test_aurexis_token_legacy_record_shim_works_without_live_literal_field():
    record = _make_record()
    obj = p1.AurexisToken(token_id="t1", token_type="primitive", phoxel_record=record)
    assert obj.phoxel_record is record
    assert getattr(obj, LEGACY_RECORD_KEY) is record
