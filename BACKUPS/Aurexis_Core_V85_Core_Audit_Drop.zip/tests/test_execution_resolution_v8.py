from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "aurexis_lang" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.execution_resolution import run_execution_resolution


def test_execution_resolution_resolves_simple_plan():
    result = run_execution_resolution({
        "execution_steps": [
            {"step_type": "assignment", "target": "x", "value": "2"},
            {"step_type": "assignment", "target": "y", "value": 3},
            {"step_type": "binary_expression", "parts": ["x", "+", "y"]},
        ]
    })
    assert result["final_environment"] == {"x": 2, "y": 3}
    assert result["resolved_count"] == 3
    assert result["unresolved_count"] == 0
    assert result["fully_resolved"] is True
    assert result["output_steps"][-1]["result"] == 5


def test_execution_resolution_blocks_unknown_steps_cleanly():
    result = run_execution_resolution({
        "execution_steps": [
            {"step_type": "assignment", "target": "x", "value": 2},
            {"step_type": "binary_expression", "parts": ["x", "+", "missing"]},
            {"step_type": "unsupported"},
        ]
    })
    assert result["resolved_count"] == 1
    assert result["unresolved_count"] == 2
    assert result["fully_resolved"] is False
    assert all(isinstance(step["resolved"], bool) for step in result["output_steps"])
