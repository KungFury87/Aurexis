from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "aurexis_lang" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.terminology import CANONICAL_RECORD_KEY, LEGACY_RECORD_KEY, with_legacy_alias, canonicalize_record_keys


def test_terminology_helpers_keep_canonical_key_primary_and_legacy_key_as_shim():
    data = canonicalize_record_keys({LEGACY_RECORD_KEY: {'pixel_coordinates': [1, 2]}})
    assert CANONICAL_RECORD_KEY in data
    assert LEGACY_RECORD_KEY in with_legacy_alias(data)


def test_remaining_legacy_term_usage_is_shim_only_in_active_live_code():
    active_files = [
        ROOT / 'phase1_language_implementation.py',
        ROOT / 'phase1_parser_implementation.py',
        ROOT / 'phase1_parser_simple.py',
        ROOT / 'aurexis_lang' / 'src' / 'aurexis_lang' / 'terminology.py',
    ]
    text = "\n".join(path.read_text() for path in active_files)
    assert 'legacy compatibility alias' in text.lower() or 'legacy compatibility' in text.lower()
