from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "aurexis_lang" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.future_tech_ceiling import validate_future_tech_ceiling_criteria
from aurexis_lang.mobile_demo_target import validate_narrow_mobile_demonstration_target
from aurexis_lang.core_law_enforcer import enforce_core_law, CoreLawSection


def _text(path: str) -> str:
    return Path(path).read_text(encoding="utf-8")


def test_future_tech_doc_freezes_blocked_drift_keys():
    text = _text("AUREXIS_FUTURE_TECH_CEILING_COMPATIBILITY_CRITERIA_V1.md")
    for needle in [
        "`ontology_rewrite_required`",
        "`hardware_required_for_legality`",
        "`behavior_changes_with_hardware`",
        "`sensor_specific_semantics`",
        "`current_floor_invalidated`",
    ]:
        assert needle in text


def test_mobile_demo_doc_freezes_required_conditions():
    text = _text("AUREXIS_NARROW_MOBILE_DEMONSTRATION_TARGET_V1.md")
    for needle in [
        "`pc_preparation_supported`",
        "`phone_capture_supported`",
        "`scope_is_narrow`",
        "`output_honesty_explicit`",
        "`no_hidden_exotic_hardware`",
        "`real_capture_or_earned_evidence`",
    ]:
        assert needle in text


def test_future_tech_helper_accepts_capability_only_scaling():
    errors = validate_future_tech_ceiling_criteria({
        "improves_only": ["confidence", "precision", "robustness"],
    })
    assert errors == []


def test_future_tech_helper_rejects_law_rewrite_and_floor_invalidation():
    errors = validate_future_tech_ceiling_criteria({
        "ontology_rewrite_required": True,
        "current_floor_invalidated": True,
    })
    assert "ontology_rewrite_required" in errors
    assert "current_floor_invalidated" in errors


def test_mobile_demo_helper_accepts_narrow_real_capture_demo():
    errors = validate_narrow_mobile_demonstration_target({
        "pc_preparation_supported": True,
        "phone_capture_supported": True,
        "scope_is_narrow": True,
        "output_honesty_explicit": True,
        "no_hidden_exotic_hardware": True,
        "evidence_tier": "real-capture",
    })
    assert errors == []


def test_mobile_demo_helper_rejects_lab_only_overclaim():
    errors = validate_narrow_mobile_demonstration_target({
        "pc_preparation_supported": True,
        "phone_capture_supported": True,
        "scope_is_narrow": True,
        "output_honesty_explicit": True,
        "no_hidden_exotic_hardware": True,
        "evidence_tier": "lab",
        "production_ready_claim": True,
    })
    assert "insufficient_mobile_demo_evidence" in errors
    assert "production_ready_claim" in errors


def test_enforcer_uses_mobile_demo_freeze():
    passed, violations = enforce_core_law({
        "type": "mobile_demo",
        "pc_preparation_supported": True,
        "phone_capture_supported": True,
        "scope_is_narrow": True,
        "output_honesty_explicit": True,
        "no_hidden_exotic_hardware": True,
        "evidence_tier": "lab",
    })
    assert passed is False
    assert any(v.section == CoreLawSection.CURRENT_TECH_FLOOR for v in violations)
    assert any("insufficient_mobile_demo_evidence" in v.description for v in violations)


def test_enforcer_uses_future_tech_freeze():
    passed, violations = enforce_core_law({
        "type": "scalability",
        "ontology_rewrite_required": True,
        "improves_only": ["confidence"],
    })
    assert passed is False
    assert any(v.section == CoreLawSection.FUTURE_TECH_CEILING for v in violations)
    assert any("ontology_rewrite_required" in v.description for v in violations)
