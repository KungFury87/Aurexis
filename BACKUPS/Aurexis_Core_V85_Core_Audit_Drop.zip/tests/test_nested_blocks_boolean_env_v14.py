from pathlib import Path
import sys
from types import SimpleNamespace
from enum import Enum

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "aurexis_lang" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.execution_semantics import ast_to_execution_plan
from aurexis_lang.execution_resolution import run_execution_resolution
from aurexis_lang.execution_semantics_deeper import run_execution_plan
from aurexis_lang.execution_interpretation import interpret_execution_result
from aurexis_lang.execution_state_propagation import propagate_execution_state
from aurexis_lang.branch_state_execution import run_branch_state_execution


class NodeType(Enum):
    ASSIGNMENT = "Assignment"
    BINARY = "BinaryExpression"
    BLOCK = "Block"


def _value_node(**value):
    return SimpleNamespace(value=value, children=[])


def test_ast_planning_supports_nested_blocks_and_assignment_expression_values():
    binary_rhs = SimpleNamespace(
        node_type=NodeType.BINARY,
        children=[_value_node(value='x'), _value_node(value='+'), _value_node(value='y')],
    )
    nested_block = SimpleNamespace(
        node_type=NodeType.BLOCK,
        children=[
            SimpleNamespace(node_type=NodeType.ASSIGNMENT, children=[_value_node(name='z'), binary_rhs]),
            SimpleNamespace(node_type=NodeType.ASSIGNMENT, children=[_value_node(name='flag'), SimpleNamespace(node_type=NodeType.BINARY, children=[_value_node(value=True), _value_node(value='and'), _value_node(value=False)])]),
        ],
    )
    ast = SimpleNamespace(children=[
        SimpleNamespace(node_type=NodeType.ASSIGNMENT, children=[_value_node(name='x'), _value_node(value='2')]),
        SimpleNamespace(node_type=NodeType.ASSIGNMENT, children=[_value_node(name='y'), _value_node(value='3')]),
        nested_block,
    ])

    plan = ast_to_execution_plan(ast)
    assert plan['step_count'] == 3
    block = plan['execution_steps'][2]
    assert block['step_type'] == 'block'
    assert block['child_count'] == 2
    assert block['nested_steps'][0]['value'] == {'parts': ['x', '+', 'y']}
    assert block['nested_steps'][1]['value'] == {'parts': [True, 'and', False]}


def test_nested_blocks_boolean_logic_and_multi_step_environment_mutation_work_end_to_end():
    plan = {
        'execution_steps': [
            {'step_type': 'assignment', 'target': 'x', 'value': '2'},
            {'step_type': 'assignment', 'target': 'y', 'value': '3'},
            {'step_type': 'block', 'nested_steps': [
                {'step_type': 'assignment', 'target': 'sum', 'value': {'parts': ['x', '+', 'y']}},
                {'step_type': 'assignment', 'target': 'gt', 'value': {'parts': ['sum', '>', '4']}},
                {'step_type': 'assignment', 'target': 'ok', 'value': {'parts': ['gt', 'and', True]}},
            ]},
        ]
    }

    result = run_execution_resolution(plan)
    assert result['fully_resolved'] is True
    assert result['final_environment'] == {'x': 2, 'y': 3, 'sum': 5, 'gt': True, 'ok': True}
    block = result['output_steps'][2]
    assert block['resolved'] is True
    assert block['nested_output_steps'][0]['value'] == 5
    assert block['nested_output_steps'][1]['value'] is True
    assert block['nested_output_steps'][2]['value'] is True

    interpreted = interpret_execution_result(result)
    assert interpreted['outcome'] == 'complete'
    assert interpreted['produced_values'] == [2, 3, 5, True, True]

    propagated = propagate_execution_state(result)
    assert propagated['final_environment'] == {'x': 2, 'y': 3, 'sum': 5, 'gt': True, 'ok': True}
    assert propagated['statefully_resolved'] is True

    branch = run_branch_state_execution(result)
    assert branch['blocked_branch_count'] == 0


def test_boolean_failures_inside_nested_blocks_stay_explicit():
    plan = {
        'execution_steps': [
            {'step_type': 'assignment', 'target': 'x', 'value': '2'},
            {'step_type': 'block', 'nested_steps': [
                {'step_type': 'assignment', 'target': 'bad_bool', 'value': {'parts': ['x', 'and', True]}},
            ]},
        ]
    }

    result = run_execution_plan(plan)
    assert result['fully_resolved'] is False
    block = result['output_steps'][1]
    assert block['resolved'] is False
    assert block['reason'] == 'blocked_nested_block'
    assert block['nested_output_steps'][0]['reason'] == 'non_boolean_operands'

    interpreted = interpret_execution_result(result)
    assert interpreted['outcome'] == 'partial'
    assert 'blocked_nested_block' in interpreted['blocked_reasons']
    assert 'non_boolean_operands' in interpreted['blocked_reasons']

    propagated = propagate_execution_state(result)
    assert propagated['blocked_step_count'] == 2

    branch = run_branch_state_execution(result)
    assert branch['blocked_branch_count'] == 2
