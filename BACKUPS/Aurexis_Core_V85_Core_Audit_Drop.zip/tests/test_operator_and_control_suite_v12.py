from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "aurexis_lang" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.execution_resolution import run_execution_resolution
from aurexis_lang.execution_semantics_deeper import run_execution_plan
from aurexis_lang.execution_interpretation import interpret_execution_result
from aurexis_lang.execution_state_propagation import propagate_execution_state
from aurexis_lang.control_resolution import resolve_control_step, summarize_control_resolution
from aurexis_lang.control_flow_state_machine import control_steps_to_transitions, step_state_machine


def test_execution_resolution_supports_more_numeric_and_comparison_operators():
    plan = {
        "execution_steps": [
            {"step_type": "assignment", "target": "x", "value": "8"},
            {"step_type": "assignment", "target": "y", "value": "2"},
            {"step_type": "binary_expression", "parts": ["x", "-", "y"]},
            {"step_type": "binary_expression", "parts": ["x", "*", "y"]},
            {"step_type": "binary_expression", "parts": ["x", "/", "y"]},
            {"step_type": "binary_expression", "parts": ["x", ">", "y"]},
            {"step_type": "binary_expression", "parts": ["x", "==", "8"]},
        ]
    }

    result = run_execution_resolution(plan)
    assert result["fully_resolved"] is True
    assert result["resolved_count"] == 7
    outputs = result["output_steps"]
    assert outputs[2]["result"] == 6
    assert outputs[3]["result"] == 16
    assert outputs[4]["result"] == 4.0
    assert outputs[5]["result"] is True
    assert outputs[6]["result"] is True

    interpreted = interpret_execution_result(result)
    assert interpreted["outcome"] == "complete"
    assert interpreted["produced_values"] == [8, 2, 6, 16, 4.0, True, True]


def test_deeper_execution_plan_keeps_division_by_zero_honest():
    plan = {
        "execution_steps": [
            {"step_type": "assignment", "target": "x", "value": "8"},
            {"step_type": "assignment", "target": "y", "value": "0"},
            {"step_type": "binary_expression", "parts": ["x", "/", "y"]},
        ]
    }

    result = run_execution_plan(plan)
    assert result["fully_resolved"] is False
    assert result["output_steps"][2]["reason"] == "division_by_zero"

    interpreted = interpret_execution_result(result)
    assert interpreted["outcome"] == "partial"
    assert "division_by_zero" in interpreted["blocked_reasons"]

    propagated = propagate_execution_state(result)
    assert propagated["blocked_step_count"] == 1
    assert propagated["timeline"][2]["reason"] == "division_by_zero"


def test_control_resolution_supports_if_while_and_for():
    assert resolve_control_step("if", True) == {"keyword": "if", "resolved": True, "branch": "then"}
    assert resolve_control_step("while", False) == {"keyword": "while", "resolved": True, "branch": "exit"}
    assert resolve_control_step("for", [1, 2]) == {"keyword": "for", "resolved": True, "branch": "iterate"}
    assert resolve_control_step("for", []) == {"keyword": "for", "resolved": True, "branch": "skip"}
    assert resolve_control_step("for", None)["reason"] == "unknown_iterable"

    summary = summarize_control_resolution([
        {"keyword": "if", "condition_value": True},
        {"keyword": "while", "condition_value": False},
        {"keyword": "for", "condition_value": []},
        {"keyword": "for", "condition_value": None},
    ])
    assert summary["resolved_count"] == 3
    assert summary["unresolved_count"] == 1

    transitions = control_steps_to_transitions(summary)
    machine = step_state_machine(transitions)
    assert machine["timeline"][0]["current_state_after_step"] == "if::then"
    assert machine["timeline"][1]["current_state_after_step"] == "while::exit"
    assert machine["timeline"][2]["current_state_after_step"] == "for::skip"
    assert machine["timeline"][3]["resolved"] is False
    assert machine["blocked_transition_count"] == 1
