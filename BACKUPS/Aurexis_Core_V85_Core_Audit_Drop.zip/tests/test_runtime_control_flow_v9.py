from pathlib import Path
import sys
from enum import Enum
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'aurexis_lang' / 'src'
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.execution_semantics import ast_to_execution_plan
from aurexis_lang.execution_semantics_deeper import run_execution_plan
from aurexis_lang.execution_interpretation import interpret_execution_result
from aurexis_lang.execution_state_propagation import propagate_execution_state
from aurexis_lang.control_resolution import summarize_control_resolution
from aurexis_lang.control_flow_state_machine import control_steps_to_transitions, step_state_machine
from aurexis_lang.branch_state_execution import run_branch_state_execution


class NodeType(Enum):
    ASSIGNMENT = 'Assignment'
    BINARY = 'BinaryExpression'
    CONTROL = 'Control'
    BLOCK = 'Block'


def _value_node(**value):
    return SimpleNamespace(value=value, children=[])


def test_runtime_chain_handles_enum_node_types_and_computes_binary_results():
    ast = SimpleNamespace(children=[
        SimpleNamespace(
            node_type=NodeType.ASSIGNMENT,
            children=[_value_node(name='x'), _value_node(value='2')],
        ),
        SimpleNamespace(
            node_type=NodeType.ASSIGNMENT,
            children=[_value_node(name='y'), _value_node(value=3)],
        ),
        SimpleNamespace(
            node_type=NodeType.BINARY,
            children=[_value_node(value='x'), _value_node(value='+'), _value_node(value='y')],
        ),
        SimpleNamespace(
            node_type=NodeType.CONTROL,
            value={'keyword': 'if'},
            children=[],
        ),
        SimpleNamespace(
            node_type=NodeType.BLOCK,
            children=[],
        ),
    ])

    plan = ast_to_execution_plan(ast)
    assert plan['step_count'] == 5
    assert plan['unresolved_count'] == 2
    assert plan['execution_steps'][0]['target'] == 'x'
    assert plan['execution_steps'][2]['parts'] == ['x', '+', 'y']

    result = run_execution_plan(plan)
    assert result['final_environment'] == {'x': 2, 'y': 3}
    assert result['output_steps'][2]['result'] == 5
    assert result['fully_resolved'] is False

    interpreted = interpret_execution_result(result)
    assert interpreted['outcome'] == 'partial'
    assert interpreted['produced_values'] == [2, 3, 5]
    assert 'blocked_control_branch' in interpreted['blocked_reasons']

    propagated = propagate_execution_state(result)
    assert propagated['final_environment'] == {'x': 2, 'y': 3}
    assert propagated['blocked_step_count'] == 2
    assert propagated['statefully_resolved'] is False

    branch = run_branch_state_execution(result)
    assert branch['base_environment'] == {'x': 2, 'y': 3}
    assert branch['blocked_branch_count'] == 2
    assert branch['branch_candidate_count'] == 2
    assert isinstance(branch['branch_resolution_confidence'], float)


def test_control_resolution_pipeline_builds_state_machine_cleanly():
    summary = summarize_control_resolution([
        {'keyword': 'if', 'condition_value': True},
        {'keyword': 'if', 'condition_value': False},
        {'keyword': 'if', 'condition_value': None},
        {'keyword': 'loop', 'condition_value': True},
    ])
    assert summary['resolved_count'] == 2
    assert summary['unresolved_count'] == 2

    transitions = control_steps_to_transitions(summary)
    machine = step_state_machine(transitions)
    assert machine['final_state'] == 'if::else'
    assert machine['blocked_transition_count'] == 2
    assert machine['fully_transitioned'] is False
    assert all(isinstance(item['resolved'], bool) for item in machine['timeline'])
