from datetime import datetime
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
SRC = ROOT / "aurexis_lang" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import phase1_language_implementation as p1
import phase1_parser_implementation as pparser


def _record():
    return p1.PhoxelRecord(
        pixel_coordinates=(4, 9),
        image_timestamp=datetime.now(),
        camera_metadata={"scene_name": "gate2-status"},
        evidence_chain=["frame_0", "frame_1"],
        pixel_data_available=True,
        synthetic=False,
    )


def test_token_and_primitive_expose_explicit_phoxel_runtime_status_fields():
    record = _record()
    primitive = p1.VisualPrimitive(
        primitive_id="p1",
        primitive_type=p1.PrimitiveType.COLOR_REGION,
        phoxel_record=record,
        confidence=0.77,
        execution_status=p1.ExecutionStatus.VALIDATED,
        evidence_chain=["frame_0", "frame_1"],
        synthetic=False,
    )
    token = p1.AurexisToken(
        token_id="t1",
        token_type="primitive",
        phoxel_record=record,
        primitive_data=primitive,
        confidence=0.77,
        evidence_validated=True,
    )

    status = token.phoxel_runtime_status
    assert status["observation_status"] == "validated"
    assert status["image_anchor"]["present"] is True
    assert status["world_anchor_state"]["status"] == "unknown"
    assert status["photonic_signature"]["pixel_data_available"] is True
    assert status["time_slice"]["present"] is True
    assert status["relation_links"]["count"] == 0
    assert status["integrity"]["traceable"] is True
    assert status["integrity"]["schema_errors"] == []
    assert primitive.phoxel_runtime_status["observation_status"] == "validated"


def test_parser_ast_nodes_carry_runtime_status_summary_in_attributes():
    record = _record()
    node = pparser.ASTNode(
        node_type=pparser.ASTNodeType.PRIMITIVE_DECLARATION,
        node_id="n1",
        phoxel_record=record,
        attributes={},
        confidence=0.66,
        evidence_validated=True,
        synthetic=False,
    )

    assert node.phoxel_runtime_status["observation_status"] == "validated"
    assert node.phoxel_runtime_status["image_anchor"]["pixel_coordinates"] == (4, 9)
    assert node.phoxel_runtime_status["integrity"]["schema_errors"] == []


def test_parse_visual_input_surfaces_runtime_status_on_program_and_children():
    parser = pparser.AurexisParser()
    visual_data = {
        "frame_id": 7,
        "camera_metadata": {"scene_name": "gate2-parse"},
        "primitive_observations": [
            {
                "primitive_type": "color_region",
                "confidence": 0.82,
                "attributes": {"centroid": (11, 12), "value": "region_a"},
            }
        ],
    }

    program, errors = parser.parse_visual_input(visual_data)
    assert errors == []
    assert program.attributes["phoxel_runtime_status"]["observation_status"] == "validated"
    child = program.children[0]
    assert child.attributes["phoxel_runtime_status"]["image_anchor"]["present"] is True
    assert child.attributes["phoxel_runtime_status"]["integrity"]["traceable"] is True
