from pathlib import Path


def _text(path: str) -> str:
    return Path(path).read_text(encoding="utf-8")


def test_gate1_checklist_exists_and_names_required_freeze_items():
    text = _text("AUREXIS_GATE_1_FREEZE_CHECKLIST_V1.md")
    for needle in [
        "Core definition",
        "Phoxel record",
        "World / image authority",
        "Execution promotion",
        "Illegal inference",
        "Evidence tiers",
        "Current-tech mobile baseline",
    ]:
        assert needle in text


def test_mobile_baseline_forbids_exotic_hardware_dependency():
    text = _text("AUREXIS_MOBILE_BASELINE_V1.md")
    assert "no exotic sensor requirement" in text
    assert "may not change the ontology or rewrite the law" in text


def test_promotion_matrix_blocks_lab_as_earned_proof():
    text = _text("AUREXIS_EXECUTION_PROMOTION_MATRIX_V1.md")
    assert "evidence tier is only `lab`" in text
    assert "being presented as earned physical proof" in text
