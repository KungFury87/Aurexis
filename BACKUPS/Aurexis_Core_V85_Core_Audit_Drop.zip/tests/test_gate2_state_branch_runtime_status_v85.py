from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
SRC = ROOT / 'aurexis_lang' / 'src'
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.execution_semantics import ast_to_execution_plan
from aurexis_lang.execution_resolution import run_execution_resolution
from aurexis_lang.execution_interpretation import interpret_execution_result
from aurexis_lang.execution_state_propagation import propagate_execution_state
from aurexis_lang.branch_state_execution import run_branch_state_execution
from aurexis_lang.execution_semantics_deeper import run_execution_plan
from aurexis_lang.runtime_obedience import build_runtime_obedience_report


STATUS = {
    'observation_status': 'validated',
    'image_anchor': {'present': True, 'pixel_coordinates': (3, 4)},
    'world_anchor_state': {'status': 'unknown', 'evidence_status': 'image-grounded-only', 'world_coordinates_present': False},
    'photonic_signature': {'pixel_data_available': True, 'measurement_origin': 'camera-observation'},
    'time_slice': {'present': True, 'image_timestamp': '2026-04-07T00:00:00'},
    'relation_links': {'count': 1},
    'integrity': {'traceable': True, 'synthetic': False, 'evidence_chain_length': 1, 'schema_errors': []},
}


class StubNode:
    def __init__(self, node_type, value=None, children=None, phoxel_runtime_status=None):
        self.node_type = node_type
        self.value = value or {}
        self.children = children or []
        self.phoxel_runtime_status = phoxel_runtime_status or {}
        self.attributes = {'phoxel_runtime_status': self.phoxel_runtime_status} if self.phoxel_runtime_status else {}


def make_ast():
    assign = StubNode(
        'Assignment', {},
        [StubNode('Identifier', {'name': 'seed'}), StubNode('Literal', {'value': 1})],
        phoxel_runtime_status=STATUS,
    )
    control = StubNode(
        'Control', {'keyword': 'if', 'condition_value': None}, [],
        phoxel_runtime_status=STATUS,
    )
    return StubNode('Program', {'confidence': {'mean': 0.9}}, [assign, control], phoxel_runtime_status=STATUS)


def test_execution_plan_surface_carries_phoxel_runtime_status_summary():
    plan = ast_to_execution_plan(make_ast())
    assert plan['phoxel_runtime_status_explicit'] is True
    assert plan['phoxel_runtime_status_rollup']['explicit_count'] == 2
    assert plan['execution_steps'][0]['phoxel_runtime_status']['image_anchor']['present'] is True


def test_resolution_propagation_and_branch_surfaces_keep_phoxel_runtime_status_alive():
    plan = ast_to_execution_plan(make_ast())
    resolution = run_execution_resolution(plan)
    propagated = propagate_execution_state(resolution)
    branch = run_branch_state_execution(resolution)
    deeper = run_execution_plan(plan)

    assert resolution['phoxel_runtime_status_explicit'] is True
    assert resolution['output_steps'][0]['phoxel_runtime_status']['observation_status'] == 'validated'
    assert propagated['phoxel_runtime_status_explicit'] is True
    assert propagated['timeline'][0]['phoxel_runtime_status']['image_anchor']['present'] is True
    assert branch['phoxel_runtime_status_explicit'] is True
    assert branch['branch_states'][0]['phoxel_runtime_status']['integrity']['traceable'] is True
    assert deeper['phoxel_runtime_status_explicit'] is True
    assert deeper['phoxel_runtime_status_rollup']['explicit_count'] >= 2


def test_runtime_obedience_report_exposes_plan_propagation_and_branch_status_rollups():
    plan = ast_to_execution_plan(make_ast())
    resolution = run_execution_resolution(plan)
    interpreted = interpret_execution_result(resolution)
    propagated = propagate_execution_state(resolution)
    branch = run_branch_state_execution(resolution)
    deeper = run_execution_plan(plan)

    report = build_runtime_obedience_report(
        resolution,
        interpreted,
        propagated,
        branch,
        deeper_execution=deeper,
        execution_plan_surface=plan,
    )

    consistency = report['report_surface_consistency']
    assert consistency['execution_plan_phoxel_runtime_status_explicit'] is True
    assert consistency['propagation_phoxel_runtime_status_explicit'] is True
    assert consistency['branch_phoxel_runtime_status_explicit'] is True
    assert consistency['execution_plan_phoxel_runtime_rollup']['explicit_count'] == 2
    assert consistency['propagation_phoxel_runtime_rollup']['explicit_count'] >= 2
    assert consistency['branch_phoxel_runtime_rollup']['explicit_count'] >= 1
