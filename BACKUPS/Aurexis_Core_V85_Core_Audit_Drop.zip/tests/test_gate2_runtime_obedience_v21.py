from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(ROOT / "aurexis_lang" / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "aurexis_lang" / "src"))

from aurexis_lang.execution_resolution import run_execution_resolution
from aurexis_lang.execution_interpretation import interpret_execution_result
from aurexis_lang.execution_state_propagation import propagate_execution_state
from aurexis_lang.branch_state_execution import run_branch_state_execution
from aurexis_lang.runtime_obedience import evaluate_runtime_obedience, build_runtime_obedience_report
from gate_2_runtime_enforcement import RuntimeLawEnforcement


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


def test_gate2_docs_exist_and_name_required_rules():
    checklist = read('AUREXIS_GATE_2_RUNTIME_OBEDIENCE_CHECKLIST_V1.md')
    rules = read('AUREXIS_RUNTIME_OBEDIENCE_REPORTING_RULES_V1.md')
    assert 'blocked and unresolved reasons must survive all reporting layers' in checklist
    assert 'state whether they are authored/runtime evidence, not earned physical proof' in rules
    assert 'world remains primary in authority' in checklist
    assert 'image remains primary in access' in checklist


def test_runtime_obedience_report_passes_for_consistent_chain():
    plan = {
        'execution_steps': [
            {'step_type': 'assignment', 'target': 'x', 'value': 2},
            {'step_type': 'assignment', 'target': 'y', 'value_expr': ['x', '+', 5]},
            {
                'step_type': 'control',
                'keyword': 'if',
                'condition_value': ['y', '>', 3],
                'then_steps': [{'step_type': 'assignment', 'target': 'z', 'value_expr': ['y', '*', 2]}],
                'else_steps': [{'step_type': 'assignment', 'target': 'z', 'value': 0}],
            },
        ]
    }
    resolution = run_execution_resolution(plan)
    interpreted = interpret_execution_result(resolution)
    propagated = propagate_execution_state(resolution)
    branch = run_branch_state_execution(resolution)
    obedience = evaluate_runtime_obedience(resolution, interpreted, propagated, branch)
    assert obedience['all_checks_pass'] is True
    report = build_runtime_obedience_report(resolution, interpreted, propagated, branch)
    assert report['evidence']['evidence_tier'] == 'authored'
    assert report['gate_clearance_authority'] is False
    assert report['world_authority_primary'] is True
    assert report['image_access_primary'] is True


def test_runtime_obedience_report_keeps_partiality_honest():
    plan = {
        'execution_steps': [
            {'step_type': 'assignment', 'target': 'x', 'value': 2},
            {'step_type': 'assignment', 'target': 'y', 'value_expr': ['x', '/', 0]},
        ]
    }
    resolution = run_execution_resolution(plan)
    interpreted = interpret_execution_result(resolution)
    propagated = propagate_execution_state(resolution)
    branch = run_branch_state_execution(resolution)
    obedience = evaluate_runtime_obedience(resolution, interpreted, propagated, branch)
    assert obedience['checks']['honest_partiality'] is True
    assert 'division_by_zero' in obedience['resolution_reasons']
    assert 'division_by_zero' in obedience['interpreted_reasons']


def test_gate2_runtime_enforcement_is_authored_scaffold_not_gate3_ready():
    text = read('gate_2_runtime_enforcement.py')
    assert 'authored/runtime evidence' in text
    assert 'not gate-clearing proof' in text
    assert 'READY FOR GATE 3' not in text
    assert "'gate_2_status': 'IN_PROGRESS'" in text


def test_runtime_enforcement_runtime_consistency_component_exists():
    enforcer = RuntimeLawEnforcement()
    result = enforcer.enforce_runtime_consistency_chain()
    assert result['component'] == 'runtime_consistency'
    assert 'obedience_report' in result
    assert result['obedience_report']['evidence']['evidence_tier'] == 'authored'
