from pathlib import Path
import sys
from datetime import datetime

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "aurexis_lang" / "src"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import phase1_language_implementation as lang


def _record():
    return lang.PhoxelRecord(
        pixel_coordinates=(1, 2),
        image_timestamp=datetime.now(),
        camera_metadata={"scene": "test"},
        evidence_chain=["frame_1"],
        pixel_data_available=True,
        synthetic=False,
    )


def test_visual_primitive_accepts_canonical_and_legacy_record_names():
    record = _record()
    canonical = lang.VisualPrimitive(
        primitive_id="p1",
        primitive_type=lang.PrimitiveType.COLOR_REGION,
        phoxel_record=record,
        attributes={},
        confidence=0.8,
        execution_status=lang.ExecutionStatus.EXECUTABLE,
        evidence_chain=["frame_1"],
    )
    legacy = lang.VisualPrimitive(
        primitive_id="p2",
        primitive_type=lang.PrimitiveType.COLOR_REGION,
        phixel_record=record,
        attributes={},
        confidence=0.8,
        execution_status=lang.ExecutionStatus.EXECUTABLE,
        evidence_chain=["frame_1"],
    )

    assert canonical.phoxel_record is record
    assert canonical.phixel_record is record
    assert legacy.phoxel_record is record
    assert legacy.phixel_record is record


def test_active_phase1_shims_are_reduced_and_explicitly_legacy_only():
    active_files = [
        ROOT / "phase1_language_implementation.py",
        ROOT / "phase1_parser_implementation.py",
        ROOT / "phase1_parser_simple.py",
        ROOT / "aurexis_lang" / "src" / "aurexis_lang" / "terminology.py",
    ]
    total = sum(path.read_text().count("phixel") for path in active_files)
    assert total <= 13
    text = "\n".join(path.read_text().lower() for path in active_files)
    assert "legacy compatibility shim" in text or "legacy compatibility alias" in text
