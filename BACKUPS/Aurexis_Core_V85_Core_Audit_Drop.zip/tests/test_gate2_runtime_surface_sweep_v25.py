from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(ROOT / 'aurexis_lang' / 'src') not in sys.path:
    sys.path.insert(0, str(ROOT / 'aurexis_lang' / 'src'))

from aurexis_lang.control_resolution import summarize_control_resolution
from aurexis_lang.control_flow_state_machine import control_steps_to_transitions, step_state_machine


def test_runtime_facing_control_surfaces_now_carry_gate2_stage_metadata():
    summary = summarize_control_resolution([
        {'keyword': 'if', 'condition_value': True},
        {'keyword': 'for', 'condition_value': [1, 2]},
        {'keyword': 'if', 'condition_value': None},
    ])
    machine = step_state_machine(control_steps_to_transitions(summary))

    for surface in (summary, machine):
        assert surface['gate_2_status'] == 'IN_PROGRESS'
        assert surface['reporting_rules_version'] == 'AUREXIS_RUNTIME_OBEDIENCE_REPORTING_RULES_V1'
        assert surface['stage_metadata_version'] == 'AUREXIS_GATE_2_RUNTIME_STAGE_METADATA_RULES_V1'
        assert surface['report_surface_alignment_target'] == 'AUREXIS_GATE_2_REPORT_SURFACE_ALIGNMENT_RULES_V1'
        assert surface['evidence_scope'] == 'authored/runtime'
        assert surface['partial_reporting_explicit'] is True
        assert surface['stage_metadata_complete'] is True
        assert surface['world_authority_primary'] is True
        assert surface['image_access_primary'] is True

    assert summary['report_scope'] == 'runtime_control_resolution'
    assert machine['report_scope'] == 'runtime_control_state_machine'
    assert machine['blocked_transition_count'] == summary['unresolved_count']
