from pathlib import Path
import sys
from datetime import datetime, UTC

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "aurexis_lang" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.phoxel_schema import TOP_LEVEL_FIELDS, coerce_phoxel_schema, validate_phoxel_schema


def _text(path: str) -> str:
    return Path(path).read_text(encoding="utf-8")


def test_phoxel_schema_doc_names_frozen_top_level_fields():
    text = _text("AUREXIS_PHOXEL_RECORD_SCHEMA_V1.md")
    for needle in TOP_LEVEL_FIELDS:
        assert f"`{needle}`" in text


def test_coerce_phoxel_schema_accepts_legacy_flat_shape_and_validates():
    schema = coerce_phoxel_schema({
        "pixel_coordinates": (10, 12),
        "image_timestamp": datetime.now(UTC),
        "camera_metadata": {"device": "phone"},
        "evidence_chain": ["camera:frame_001"],
        "pixel_data_available": True,
        "synthetic": False,
    })
    assert set(schema.keys()) == set(TOP_LEVEL_FIELDS)
    assert schema["image_anchor"]["pixel_coordinates"] == (10, 12)
    assert schema["world_anchor_state"]["status"] == "unknown"
    assert validate_phoxel_schema(schema) == []


def test_validate_phoxel_schema_rejects_missing_anchor_and_synthetic_truth():
    errors = validate_phoxel_schema({
        "image_anchor": {},
        "world_anchor_state": {"status": "unknown"},
        "photonic_signature": {"pixel_data_available": True, "camera_metadata": {}},
        "time_slice": {"image_timestamp": datetime.now(UTC)},
        "relation_set": [],
        "integrity_state": {"evidence_chain": ["x"], "synthetic": True},
    })
    assert "missing_image_anchor.pixel_coordinates" in errors
    assert "forbidden_integrity_state.synthetic_true" in errors
