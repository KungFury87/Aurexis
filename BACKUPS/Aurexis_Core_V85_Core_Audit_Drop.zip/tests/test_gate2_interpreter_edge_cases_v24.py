from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(ROOT / "aurexis_lang" / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "aurexis_lang" / "src"))

from aurexis_lang.execution_resolution import run_execution_resolution
from aurexis_lang.execution_interpretation import interpret_execution_result
from aurexis_lang.execution_state_propagation import propagate_execution_state
from aurexis_lang.branch_state_execution import run_branch_state_execution
from aurexis_lang.runtime_obedience import evaluate_runtime_obedience


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


def test_gate2_v24_docs_exist_and_name_edge_case_and_stage_metadata_rules():
    edge = read('AUREXIS_GATE_2_INTERPRETER_EDGE_CASE_RULES_V1.md')
    meta = read('AUREXIS_GATE_2_RUNTIME_STAGE_METADATA_RULES_V1.md')
    assert 'unsupported steps must stay explicitly unresolved' in edge
    assert 'missing-target assignments must stay explicitly unresolved' in edge
    assert '`stage_metadata_version`: `AUREXIS_GATE_2_RUNTIME_STAGE_METADATA_RULES_V1`' in meta
    assert '`stage_metadata_complete`: `true`' in meta


def test_gate2_v24_interpreter_edge_cases_stay_honest_and_preserve_surviving_state():
    plan = {
        'execution_steps': [
            {'step_type': 'assignment', 'target': 'x', 'value': 2},
            {'step_type': 'assignment', 'target': None, 'value': 9},
            {'step_type': 'assignment', 'target': 'ok', 'value_expr': ['x', '+', 3]},
            {'step_type': 'control', 'keyword': 'for', 'iterable': {'parts': ['ok', '@@', 1]}, 'body_steps': [
                {'step_type': 'assignment', 'target': 'looped', 'value': 1}
            ]},
            {'step_type': 'mystery_operation'},
        ]
    }
    resolution = run_execution_resolution(plan)
    interpreted = interpret_execution_result(resolution)
    propagated = propagate_execution_state(resolution)
    branch = run_branch_state_execution(resolution)
    obedience = evaluate_runtime_obedience(resolution, interpreted, propagated, branch)

    assert obedience['checks']['interpreter_edge_case_honest'] is True
    assert obedience['checks']['mixed_path_state_consistent'] is True
    assert obedience['checks']['honest_partiality'] is True
    assert 'missing_target' in obedience['resolution_reasons']
    assert 'unsupported_operator:@@' in obedience['resolution_reasons']
    assert 'unsupported_step' in obedience['resolution_reasons']
    assert ('x', 2) in obedience['resolution_assignment_trace']
    assert ('ok', 5) in obedience['propagated_assignment_trace']
    assert obedience['final_environment']['ok'] == 5

