from pathlib import Path
import sys
from enum import Enum
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "aurexis_lang" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aurexis_lang.runtime_semantics_stub import ast_to_semantic_summary
from aurexis_lang.runtime_semantics_expanded import ast_to_semantic_summary_expanded


class NodeType(Enum):
    ASSIGNMENT = "Assignment"
    BINARY = "BinaryExpression"
    CONTROL = "Control"
    BLOCK = "Block"
    UNKNOWN = "UnknownNode"


def test_runtime_semantics_accept_enum_node_types_and_mark_ambiguity():
    ast = SimpleNamespace(children=[
        SimpleNamespace(node_type=NodeType.ASSIGNMENT),
        SimpleNamespace(node_type=NodeType.BINARY),
        SimpleNamespace(node_type=NodeType.CONTROL),
        SimpleNamespace(node_type=NodeType.UNKNOWN),
    ])

    basic = ast_to_semantic_summary(ast)
    assert basic["semantic_classes"] == [
        "assignment_semantic",
        "binary_expression_semantic",
        "control_or_block_semantic",
        "unresolved_semantic",
    ]
    assert basic["ambiguous"] is True
    assert basic["resolvable"] is False

    expanded = ast_to_semantic_summary_expanded(ast)
    assert expanded["semantic_count"] == 4
    assert expanded["resolvable_count"] == 2
    assert expanded["partially_resolvable"] is True
    assert expanded["ambiguous"] is True
    assert expanded["semantic_items"][2]["semantic"] == "control"
    assert expanded["semantic_items"][3]["semantic"] == "unresolved"


def test_runtime_semantics_handles_plain_string_block_nodes():
    ast = SimpleNamespace(children=[
        SimpleNamespace(node_type="Block"),
        SimpleNamespace(node_type="NonControlStub"),
    ])

    basic = ast_to_semantic_summary(ast)
    assert basic["ambiguous"] is True
    assert basic["resolvable"] is False

    expanded = ast_to_semantic_summary_expanded(ast)
    assert expanded["semantic_items"][0]["semantic"] == "block"
    assert expanded["semantic_items"][1]["semantic"] == "unresolved"
