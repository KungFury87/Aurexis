# Aurexis Gate 2 Multi-Branch Runtime Rules V1

Gate 2 runtime-obedience must preserve honest state and reason handling across multi-branch paths.

Required rules:
- successful assignments must survive later failures in other branches
- branch-selected state must remain visible in final environment snapshots
- unresolved reasons from one branch may not erase surviving state from another branch
- mixed branch/runtime output must remain explicitly partial when any branch stays unresolved
- report surfaces must not flatten multi-branch outcomes into fake complete status
