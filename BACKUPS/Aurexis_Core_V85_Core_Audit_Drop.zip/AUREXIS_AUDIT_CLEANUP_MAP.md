# AUREXIS AUDIT CLEANUP MAP

## GREEN — KEEP AS SUBSTRATE
- `aurexis_lang/`
- extraction/runtime/carryover/evidence modules
- gate scripts as lab scaffolds
- benchmark concepts
- mobile-baseline idea

## YELLOW — REWRITE / RELABEL
- `AUREXIS_CORE_LAW_V1.md`
- `AUREXIS_DEVELOPMENT_ROADMAP.md`
- `CORE_LAW_FROZEN.md`
- `phase4_real_world_testing.py`
- gate/demo scripts that currently mix simulation with proof language

## RED — DEMOTE FROM AUTHORITY
- `final_completion_status.py`
- `final_project_completion.py`
- `mobile_app_store_deployment.py`
- `global_scaling_infrastructure.py`
- `business_development.py`
- `user_ecosystem_development.py`
- any file claiming project completion, production readiness, app-store deployment, global scale, or finished ecosystem status

## CLEANUP PRINCIPLES
- keep useful substrate
- stop fake completion theater
- separate simulated lab evidence from earned real-camera proof
- keep Core-first scope
- no deletion required for first cleanup pass; demotion and relabeling are enough


## V2 CLEANUP ACTIONS
- normalize canonical term toward **phoxel** while preserving legacy `phixel` compatibility where needed
- relabel simulation-heavy gate/demo files so they default to honest lab language
- add a real `tests/` starter base to check authority-doc consistency, simulation transparency, and terminology compatibility
- keep destructive deletion out of scope; prefer relabeling, demotion, and compatibility shims first


## Cleanup v3 actions

- normalize active phase-1 parser/token/interpreter surfaces toward canonical **phoxel** terminology while keeping legacy compatibility aliases where needed
- align `core_law_enforcer.py` to the locked world-authority / image-access law
- add stronger starter tests for world/image authority enforcement and executable promotion gates


## Cleanup v4 actions

- Added a formal evidence-tier helper module (`lab`, `authored`, `real-capture`, `earned`).
- Patched the remaining simulation-heavy gate/evidence scripts to stamp their outputs as lab-tier by default.
- Replaced the worst remaining earned-proof / production-ready / full-version overclaims in those scripts.
- Added tests that block lab-tier scripts from claiming earned proof by default.


## Cleanup v5 actions

### Red -> relabeled historical artifacts
- complete_evidence_loop/*
- evidence_validation/*
- gate_2_results/*
- gate_3_benchmark_results/*
- gate_3_robust_results/*
- gate_4_mobile_demo/*
- gate_5_expansion_demo/*
- evidence_batches/*

### Yellow -> still needs deeper cleanup
- old generated JSON/MD files outside the audited artifact folders
- any lingering historical outputs that still imply earned proof indirectly

### Green -> now safer to interpret
- authority docs layer
- active evidence-tier helpers
- active simulation-heavy scripts
- audited generated output folders after v5 relabeling


## Cleanup v6 actions

### Red -> archived out of active root
- `advanced_ai_integration.py`
- `business_development.py`
- `global_scaling_infrastructure.py`
- `mobile_app_store_deployment.py`
- `phase3_ui_applications.py`
- `phase3_ui_simple.py`
- `phase5_deployment_scaling.py`
- `security_compliance.py`
- `user_ecosystem_development.py`

### Green -> stronger active verification base
- deeper tests for illegal inference law
- deeper tests for current-tech floor / future-tech ceiling law
- archive checks proving drift files are no longer in the active root


## Cleanup v7
- GREEN: keep root docs as active scaffold/implementation notes, but not gate authority by themselves.
- YELLOW: treat `aurexis_vision_track_v39/docs/` as historical lineage only.
- GREEN: strengthen active evidence/benchmark verification around multi-frame promotion and evidence-batch save/analyze flows.


## Cleanup v8
- GREEN: strengthen active runtime/benchmark verification around execution resolution, evidence-batch processing, and perception benchmark profile selection.
- GREEN: fix broken active evidence-batch processing paths so training/evaluation/report generation behave coherently.
- YELLOW: continue canonical **phoxel** wording across active phase-1 files while preserving legacy `phixel` compatibility aliases.


## Cleanup v9 actions
- GREEN: active runtime/control-flow chain now has end-to-end tests from AST planning through execution, interpretation, propagation, control transitions, and branch-state handling.
- GREEN: binary-expression execution in the deeper runtime path now produces real numeric results instead of placeholder resolved flags only.
- GREEN: active execution planning now tolerates enum-style node types and extracts values/names more robustly from simple AST stubs.
- YELLOW: terminology drift was reduced again in active files by preferring canonical `phoxel_record` in the evidence-validation scaffold and interpreter-facing active code.
- YELLOW: `evidence_validation_loop.py` is now less likely to read as sole authority; it is explicitly described as one lab/authored validation surface, not the final truth source.
- RED: package-wide `phixel` normalization is still incomplete, especially across historical artifacts and legacy compatibility surfaces.
- RED: deeper interpreter/control-flow coverage still needs expansion into more runtime semantics and control keywords beyond the current exercised chain.


## v10 actions
- GREEN: runtime-semantics paths now normalize enum-style node/edge labels instead of tripping on non-string active types.
- GREEN: unresolved-state interpretation/propagation is covered more directly in the active test base.
- YELLOW: another slice of active phase-1 phoxel terminology was normalized while preserving legacy compatibility aliases.
- RED: package-wide phixel cleanup is still incomplete outside the active paths and historical artifacts.


## Cleanup V11
- Strengthened unresolved-path honesty in execution resolution / deeper execution / interpretation / state propagation / branch-state handling.
- Added explicit failure-mode reasons for missing targets, unsupported operators, blocked control branches, and unsupported steps.
- Added tests covering mixed-resolution execution paths and shim-only remaining active legacy terminology.


## v12 cleanup actions
- Expanded active execution operator coverage beyond `+` to include subtraction, multiplication, division, and basic comparisons in the active resolution/deeper-execution paths.
- Expanded control resolution coverage to include `while` and `for` branches with explicit unresolved reasons for unknown/unsupported iterable states.
- Added tests to verify operator/control behavior and to fence remaining active legacy `phixel` usage into intentional shim-only files.


## V13 actions
- Expanded active verification into nested control-flow path labeling and mixed-type runtime failure cases.
- Tightened active phoxel/phixel shim handling in phase-1 classes while preserving backward-compatible constructor paths.


## Cleanup V14
- Added nested block + boolean logic + environment mutation verification.
- Tightened parser-surface canonical phoxel type-hint usage while keeping legacy phixel property shims.


## Cleanup V15
- Added loop-body execution coverage for `while` and `for` inside the active runtime chain.
- Added explicit nested blocked-control coverage inside execution blocks so unresolved control reasons survive through interpretation, propagation, and branch-state handling.
- Reduced the remaining active `phixel` mentions further so the live boundary is more clearly limited to shim-only surfaces.


## Cleanup v16
- collapsed more live `phixel` usage into compatibility-only access paths
- added Gate 1 freeze materials:
  - `AUREXIS_GATE_1_FREEZE_CHECKLIST_V1.md`
  - `AUREXIS_MOBILE_BASELINE_V1.md`
  - `AUREXIS_EXECUTION_PROMOTION_MATRIX_V1.md`
- added tests for Gate 1 doc presence and active phoxel boundary behavior


## V17
- froze the exact minimum legal phoxel record schema
- froze the illegal-inference blocked-claim matrix
- wired the live core law enforcer into those new Gate 1 helpers


## V18 actions
- froze relation legality / measurable requirements into `AUREXIS_RELATION_LEGALITY_MEASURABLE_REQUIREMENTS_V1.md`
- froze executable-promotion final checklist into `AUREXIS_EXECUTABLE_PROMOTION_CHECKLIST_V1.md`
- added live helpers `relation_legality.py` and `executable_promotion.py`
- wired native-relations and executable-promotion validation through the new Gate 1 freeze helpers


## V19
- froze future-tech ceiling compatibility criteria into a short law sheet
- froze the narrow mobile demonstration target into a testable law sheet
- wired both into the live core law enforcer
- added Gate 1 tests for future-tech and mobile-demo enforcement


## Cleanup v20
- completed the Gate 1 audit of active enforcement/report surfaces against frozen world/image wording and evidence-tier wording
- replaced active `image_supremacy` live-field language with canonical `image_access_primary` plus compatibility shim in the phase-1 interpreter context
- relabeled the phase-2 pipeline as a mobile-realistic scaffold instead of production-ready proof
- marked Gate 1 complete after the live test base remained green


## V21 actions
- Added Gate 2 runtime-obedience checklist and reporting rules.
- Added live runtime obedience helper with authored/runtime evidence stamping.
- Relabeled Gate 2 scaffold outputs so they no longer imply Gate 2 or Gate 3 clearance.
- Added runtime-chain consistency tests for environment alignment, blocked-reason preservation, and honest partiality.


## V22
- expanded Gate 2 mixed-path state mutation and failure propagation rules
- strengthened runtime obedience checks for mutation traces and propagated reasons


## V23
- Added Gate 2 multi-branch runtime rules and report-surface alignment rules.
- Aligned runtime stage outputs under shared Gate 2 reporting metadata.
- Relabeled lingering gate_2_results artifact status drift from COMPLETE to IN_PROGRESS.


## V24
- froze Gate 2 interpreter edge-case rules
- froze Gate 2 runtime stage metadata rules
- aligned runtime-stage outputs under explicit stage metadata keys
- expanded runtime-obedience checks for edge-case honesty and stage metadata completeness


## V25
- Added frozen Gate 2 rules for nested loop/control failure honesty and runtime mutation edge cases.
- Stamped control-resolution and control state-machine surfaces with shared Gate 2 metadata.
- Expanded runtime-obedience to validate control-surface alignment and nested loop/control honesty.


## V26 additions
- Gate 2 expanded into deeper runtime-facing surfaces (`runtime_deeper_execution`, `runtime_control_transitions`).
- Runtime obedience now checks deeper-surface alignment and nested loop/transition failure honesty.


## V27
- aligned runtime execution plan + execution trace surfaces under Gate 2 metadata
- added nested control-pattern honesty checks across plan/trace/runtime surfaces


## v28
- added formal Gate 2 completion audit layer
- wired completion audit into the runtime enforcement scaffold
- added Gate 2 completion audit/report docs


## v28
- added formal Gate 2 completion audit layer
- wired completion audit into runtime enforcement scaffold
- confirmed Gate 2 is still blocked by older component-enforcement surfaces


## V29
- patched the four formal Gate 2 blocker buckets inside `gate_2_runtime_enforcement.py`
- updated Gate 2 completion audit expectations to reflect the cleared scaffold summary
- added V29 Gate 2 progress/completion docs


## V30 Actions
- Started Gate 3 with formal earned-evidence loop rules and evidence-separation rules.
- Added live Gate 3 evidence-loop helper and wired it into real-capture and lab/authored validation surfaces.
- Patched real-capture batch summaries so they carry explicit Gate 3 metadata instead of implicit proof language.


## V31
- Added Gate 3 authored-vs-real-capture comparison rules
- Added Gate 3 earned-evidence audit scaffold
- Wired authored reference surfaces into lab/authored validation loops
- Wired real-capture reference surfaces into saved batch summaries


## v33
- Added Gate 3 batch report surface rules
- Added Gate 3 batch report helper and evidence-batch processor wiring
- Fixed the Gate 3 batch evidence-loop call to use source tiers correctly
- Stabilized constant-count batch primitive correlation so markdown reports do not leak NaN values
- Added tests for saved batch report outputs and markdown report integration


## V34
- Added Gate 3 completion-audit scaffold
- Wired Gate 3 completion audit into saved batch reports
- Explicitly blocked fake Gate 3 completion without earned-tier evidence


## V35
- Added the first earned-tier promotion path on top of Gate 3 batch comparison/report surfaces.
- Batch reports can now carry explicit earned candidates without granting gate-clearing authority automatically.


## v36
- Added formal Gate 3 gate-level completion audit.
- Wired gate-level audit into saved Gate 3 batch-report outputs.
- Explicitly blocked global Gate 3 completion when only one evidence route exists.

- v37: added second-route Gate 3 reporting surfaces and global audit scanning for validation/cycle outputs.

- v38: Added Gate 3 saved-run path rules and automatic multi-route gate-level audit rebuild from validation/complete-cycle saves.


## V39
- Added the first normal saved-run multi-route Gate 3 completion pass.
- Added route-package builders for validation and complete-cycle saved outputs.
- Added `EvidenceBatchProcessor.run_gate3_multi_route_completion_pass(...)`.
- Fixed the saved batch real-capture surface lookup in the multi-route completion path.


## v40
- added Gate 3 global completion report
- added Gate 3 default-state audit
- distinguished capability from current saved-state completion


## v42
- Added packaged Gate 3 default-state regeneration step
- Added Gate 3 final completion report
- Wired processor path to rebuild a fresh default-clearing saved state from one canonical run


## V43
- Added Gate 3 default pipeline entry and package state stamp.


## V44
- Added Gate 3 release/build-style pipeline entry and root package completion stamp.


## V45
- Added package-facing quickstart surfaces (`README_START_HERE.md`, release workflow quickstart)
- Started Gate 4 through an honest narrow mobile demonstration kickoff path
- Added root runner for Gate 4 narrow mobile demo

## V82 actions
- GREEN: aligned `README_START_HERE.md` with the active Core law sheet so the root quickstart no longer overstates gate completion.
- GREEN: made authority order explicit at the package root: law sheet first, roadmap second, cleanup map third, generated outputs after that.
- GREEN: added tests to keep the root quickstart from drifting back into fake gate-clearance language.


## V83 actions
- GREEN: active Gate 2 phase-1 runtime surfaces now expose explicit phoxel field-status summaries for image anchor, world-anchor state, photonic signature, time slice, relation links, and integrity instead of leaving those fields implied only by the raw record shape.
- GREEN: parser/token/program surfaces now carry the same runtime-facing phoxel status summary so Gate 2 reporting can inspect field presence and status directly.
- YELLOW: this is still one active runtime path, not a claim that the whole runtime stack is fully field-law obedient yet.


## V84 actions
- GREEN: execution trace surfaces now keep explicit phoxel runtime status alive at the root and step levels instead of dropping it after parse.
- GREEN: phase-1 interpreter execution traces and execution reports now expose phoxel runtime status rollups so Gate 2 runtime reporting can inspect the law fields after execution.
- GREEN: fixed the runtime-obedience report builder so execution plan/trace surfaces are actually forwarded into evaluation rather than silently ignored.
- YELLOW: this is still deeper runtime-surface obedience work, not a claim that the full runtime stack is field-law complete yet.
