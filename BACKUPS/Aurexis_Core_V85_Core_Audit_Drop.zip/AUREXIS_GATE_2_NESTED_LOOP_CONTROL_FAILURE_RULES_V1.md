# AUREXIS Gate 2 Nested Loop / Control Failure Rules V1

These rules freeze the Gate 2 expectation that nested loop/control failures must remain honest across active runtime surfaces.

Required rules:
- loop-body mutations that successfully resolve before a later blocked nested control step must survive in the reported environment
- blocked nested control inside `while` or `for` execution must remain explicitly reported as `blocked_control_branch`
- nested loop/control failure must not flatten into fake full resolution
- `while` / `for` runtime-facing report surfaces must carry Gate 2 stage metadata when summarized
- control summaries and control state-machine outputs must remain aligned under the shared Gate 2 reporting metadata
