# AUREXIS PHOXEL RECORD SCHEMA V1

**STATUS**: ACTIVE GATE 1 FREEZE MATERIAL  
**ROLE**: Freeze the exact minimum legal phoxel record schema

---

## Canonical minimum legal phoxel record

Every legal phoxel record must resolve into these top-level fields:
- `image_anchor`
- `world_anchor_state`
- `photonic_signature`
- `time_slice`
- `relation_set`
- `integrity_state`

This is the **minimum legal schema**.
Older flat record shapes may still be accepted as compatibility input, but the law-level interpretation must resolve into this structure.

---

## Field definitions

### 1. `image_anchor` (required)
Required minimum:
- `pixel_coordinates`

Purpose:
- the image-side access anchor
- where the phoxel was actually observed on the observation surface

### 2. `world_anchor_state` (required)
Required minimum:
- `status`

Allowed `status` values:
- `unknown`
- `estimated`
- `resolved`

Purpose:
- the world-side anchor state
- keeps world authority explicit without pretending resolution always exists

### 3. `photonic_signature` (required)
Required minimum:
- `pixel_data_available`
- `camera_metadata`

Purpose:
- the capture-side measurable photonic / camera evidence
- keeps the phoxel grounded in actual observation rather than free-floating semantics

### 4. `time_slice` (required)
Required minimum:
- `image_timestamp`

Purpose:
- the temporal observation slice
- blocks the system from pretending a phoxel exists outside time

### 5. `relation_set` (required)
Required minimum:
- a list (may be empty)

Purpose:
- legal relation links / measured relation candidates
- keeps spatial logic attached to the record instead of inventing it later without traceability

### 6. `integrity_state` (required)
Required minimum:
- `evidence_chain`
- `synthetic`

Rules:
- `synthetic` must be `false` for a legal real phoxel claim
- `evidence_chain` must remain traceable as a list

Purpose:
- traceability / integrity / anti-hallucination layer

---

## Compatibility rule

The existing flat prototype record may still arrive with fields like:
- `pixel_coordinates`
- `image_timestamp`
- `camera_metadata`
- `evidence_chain`
- `pixel_data_available`
- `synthetic`

That flat shape is acceptable only as **input compatibility**.
The frozen law says it must resolve into the canonical six-field structure above.

---

## Not allowed

Not legal as substitutes for the minimum schema:
- object labels as proof of observation
- semantic meaning without image anchor
- world truth without `world_anchor_state`
- timeless observation claims without `time_slice`
- untraceable claims without `integrity_state.evidence_chain`
- synthetic records presented as real phoxel authority
