# Aurexis Gate 2 — Failure Propagation Rules V1

Runtime obedience requires explicit failure propagation across all active reporting layers.

Required rules:
- unresolved reasons from resolution must survive into interpretation
- blocked reasons must survive into state propagation and branch-state surfaces
- report surfaces must stay stamped as authored/runtime evidence
- Gate 2 report surfaces must remain `IN_PROGRESS` until the broader suite clears
- mixed-path reports must explicitly show both surviving state and unresolved reasons
