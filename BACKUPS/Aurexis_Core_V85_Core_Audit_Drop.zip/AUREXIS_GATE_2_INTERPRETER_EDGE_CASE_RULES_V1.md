# Aurexis Gate 2 Interpreter Edge-Case Rules V1

Frozen Gate 2 rule sheet for interpreter/runtime edge-case honesty.

Required behaviors:
- unsupported steps must stay explicitly unresolved
- missing-target assignments must stay explicitly unresolved
- unsupported iterable / unknown iterable control surfaces must stay explicitly blocked
- mixed success/failure chains must preserve surviving resolved state
- interpreter partial outcomes must remain explicit instead of flattening into complete status
- edge-case reasons must survive resolution, interpretation, propagation, and branch-state handling
- no stage may relabel authored/runtime edge-case evidence as gate-clearing proof
