# AUREXIS EXECUTABLE PROMOTION CHECKLIST V1

**STATUS**: ACTIVE GATE 1 FREEZE LAW

---

## Purpose

Freeze the exact checklist required for structure to promote from validated structure into executable structure.

---

## Required executable-promotion gates

An executable candidate must satisfy all of:
- `evidence_validated`
- `multi_frame_consistent`
- `geometric_coherence`
- `cross_register_consistency`
- `language_legal`
- `bounded_inference`
- `confidence >= 0.7`
- no unresolved or blocked reasons remaining
- no promotion by assumption

---

## Earned-proof rule

If the candidate is being presented as earned physical proof, the evidence tier must be `earned`.

Lab-only or authored-only evidence may not be passed off as earned proof.

---

## Automatic block conditions

Do not promote when any of these remain true:
- `promotion_by_assumption`
- unresolved or blocked reasons remain active
- parser/runtime law disagrees with the claimed promotion level
- evidence tier is below `earned` while claiming earned physical proof

---

## Gate 1 rule

Executable structure is not merely “looks stable.”
It is validated structure that passed the full checklist.
