# Core Audit Manifest v85

## Included roots
- `AUREXIS_CORE_LAW_V1.md`
- `AUREXIS_DEVELOPMENT_ROADMAP.md`
- `AUREXIS_AUDIT_CLEANUP_MAP.md`
- `CORE_LAW_FROZEN.md`
- `README_START_HERE.md`
- `CORE_AUDIT_SCOPE_V85.md`
- `CORE_AUDIT_MANIFEST_V85.md`
- `requirements.txt`
- `pytest.ini`
- `phase1_language_implementation.py`
- `phase1_parser_implementation.py`
- `phase1_parser_simple.py`
- `phase1_interpreter_implementation.py`
- `evidence_validation_loop.py`
- `gate_2_runtime_enforcement.py`
- all active `AUREXIS_GATE_1*.md` and `AUREXIS_GATE_2*.md`
- active root Core law companion docs
- selected `docs/` realization/deeper-runtime authority notes
- `aurexis_lang/`
- curated `tests/`

## Verification inside this audit scope
- curated Core-only audit subset: 115 passed
- full working repo before curation: 188 passed
