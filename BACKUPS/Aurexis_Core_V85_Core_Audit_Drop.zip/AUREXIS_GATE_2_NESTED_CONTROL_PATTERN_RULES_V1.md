# AUREXIS Gate 2 Nested Control Pattern Rules V1

Gate 2 requires richer nested control patterns to stay honest across planning, trace, execution, interpretation, propagation, and branch-state reporting.

Frozen requirements for this pass:
- successful mutations that occur before a nested blocked control step must survive
- blocked nested control reasons must remain explicit
- nested loop/control failure must not be flattened into a fake complete outcome
- planning and trace surfaces must remain aligned with runtime metadata
- authored/runtime evidence must not be presented as gate-clearing proof

A nested control pattern is honest only if:
- surviving resolved state remains visible
- blocked reasons remain explicit end to end
- partial outcome remains explicit
- the plan/trace/runtime surfaces remain metadata-aligned
