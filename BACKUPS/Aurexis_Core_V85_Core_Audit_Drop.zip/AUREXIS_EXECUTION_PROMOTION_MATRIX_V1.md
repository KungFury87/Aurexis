# AUREXIS EXECUTION PROMOTION MATRIX V1

**STATUS**: ACTIVE GATE 1 WORK MATERIAL

---

## Status ladder

### observed / descriptive
- direct visual structure exists
- no strong execution authority

### estimated
- some interpretation is present
- uncertainty remains explicit

### validated
- evidence is strong enough to trust the structure for constrained use
- still not automatically executable in every case

### executable
- promotion gates are satisfied
- structure may participate in true execution paths

---

## Promotion gates

A structure should not become executable unless it satisfies all of:
- geometric coherence
- evidence traceability
- cross-register consistency
- bounded inference
- language legality
- sufficient support across time / context / repeated validation

---

## Block conditions

Do not promote when:
- evidence tier is only `lab` and the claim is being presented as earned physical proof
- world truth is inferred from a single weak image observation
- unresolved / blocked / unsupported reasons remain active
- parser/runtime law disagrees with the claimed promotion level
