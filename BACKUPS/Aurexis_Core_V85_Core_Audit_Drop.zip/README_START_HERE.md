# Aurexis — Start Here

## Authority order
1. `AUREXIS_CORE_LAW_V1.md`
2. `AUREXIS_DEVELOPMENT_ROADMAP.md`
3. `AUREXIS_AUDIT_CLEANUP_MAP.md`
4. package-facing generated outputs

If any quickstart/readme/generated surface disagrees with the law sheet, the law sheet wins.

## Current top-level state
- Gate 1: law freeze in progress
- Gate 2: runtime obedience partially real / still being aligned
- Gate 3: evidence-loop scaffold exists / not yet earned
- Gate 4: narrow mobile-realistic demonstration not yet earned
- Gate 5: expansion without rewrite not yet earned

## What these commands are for
These are active lab/package workflow entry points.
Running them does **not** by itself clear gates or prove earned real-world capability.

## Normal package-facing commands
- `python run_gate3_release_pipeline.py [batch_name]`
- `python run_gate4_narrow_mobile_demo.py [batch_name]`

## Main outputs
- `AUREXIS_GATE_3_PACKAGE_COMPLETION_STAMP.json`
- `AUREXIS_GATE_4_NARROW_MOBILE_DEMO_REPORT.json`

## Rule
Treat these root-level outputs as package-facing workflow surfaces, not as automatic gate-clearance authority.
