# AUREXIS CORE LAW - FROZEN IMMUTABLE SPECIFICATION (CLEANUP NOTICE)

This file remains as a historical law snapshot, but it is **not** the strongest current authority surface in this package.

Use `AUREXIS_CORE_LAW_V1.md` as the active law sheet.

Why this file was demoted:
- it collapses world/image authority too far toward image supremacy
- it does not cleanly separate simulated lab evidence from earned real-camera proof
- it can be misread as more final than the current project truth supports

Historical frozen-law content should be treated as background substrate only.
