# AUREXIS Gate 2 Runtime Trace / Plan Surface Rules V1

Gate 2 requires the remaining runtime-facing planning and trace surfaces to obey the same runtime reporting law as the active execution stages.

Required aligned metadata for runtime-facing plan/trace surfaces:
- `gate_2_status`: `IN_PROGRESS`
- `reporting_rules_version`: `AUREXIS_RUNTIME_OBEDIENCE_REPORTING_RULES_V1`
- `stage_metadata_version`: `AUREXIS_GATE_2_RUNTIME_STAGE_METADATA_RULES_V1`
- `report_surface_alignment_target`: `AUREXIS_GATE_2_REPORT_SURFACE_ALIGNMENT_RULES_V1`
- `evidence_scope`: `authored/runtime`
- `gate_clearance_authority`: `false`
- `world_authority_primary`: `true`
- `image_access_primary`: `true`
- `partial_reporting_explicit`: `true`
- `stage_metadata_complete`: `true`

Allowed report scopes for this pass:
- `runtime_execution_plan`
- `runtime_execution_trace`

These are runtime-facing scaffold surfaces only.
They are not gate-clearing proof by themselves.
