"""
SIMULATED / LAB HARNESS NOTICE

This file may be useful for lab exploration, authored-asset benchmarking, or simulation.
It must not be treated by itself as earned real-world proof.

Evidence tier for this file: Tier A (simulated lab evidence) or Tier B (authored asset evidence),
unless explicitly upgraded by real-camera validation outside this file.
"""

#!/usr/bin/env python3
"""
Evidence Validation Loop for Aurexis

Simulated / authored-asset validation loop scaffold used to prepare the real evidence loop.
It is one lab/authored validation surface and does not replace earned real-camera validation.
"""

import sys
import os
import time
import json
import numpy as np
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional

# Add the aurexis_lang source to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'aurexis_lang', 'src'))

from aurexis_lang.simulated_camera import create_test_images
from aurexis_lang.advanced_cv_extractor import AdvancedCVExtractor
from aurexis_lang.core_law_enforcer import CoreLawEnforcer, enforce_core_law, get_core_law_compliance_report
from aurexis_lang.evidence_tiers import EvidenceTier, stamp_result
from aurexis_lang.terminology import with_legacy_alias
from aurexis_lang.gate3_evidence_loop import evaluate_gate3_evidence_loop
from aurexis_lang.gate3_comparison_audit import (
    build_authored_reference_surface,
    compare_authored_real_capture_surfaces,
    audit_gate3_earned_evidence_scaffold,
    build_real_capture_reference_surface,
)
from aurexis_lang.gate3_earned_promotion import promote_gate3_earned_candidate
from aurexis_lang.gate3_route_reporting import build_gate3_route_report_surface
from aurexis_lang.gate3_completion_audit import audit_gate3_completion
from aurexis_lang.gate3_saved_run_audit import build_gate3_gate_completion_audit_from_project_root


DEFAULT_EVIDENCE_TIER = EvidenceTier.LAB
SOURCE_TIERS = (EvidenceTier.LAB, EvidenceTier.AUTHORED)
EVIDENCE_TIER = DEFAULT_EVIDENCE_TIER.value
EARNED_PROOF = False


class EvidenceValidationLoop:
    """
    Simulated / authored validation scaffold for the Aurexis evidence loop.

    this loop is useful for lab iteration, but it is not sufficient as a sole gate-clearing authority
    and does not replace earned real-camera validation.
    """
    
    def __init__(self, output_dir: str = "evidence_validation"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        # Core components
        self.extractor = AdvancedCVExtractor()
        self.law_enforcer = CoreLawEnforcer(strict_mode=True)
        
        # Validation metrics
        self.validation_history: List[Dict[str, Any]] = []
        self.performance_history: List[Dict[str, Any]] = []
        
        # Mobile baseline constraints
        self.mobile_baseline = {
            "max_processing_time_seconds": 30,
            "max_memory_usage_mb": 500,
            "min_confidence_threshold": 0.7,
            "max_battery_percent_per_minute": 5
        }
        
    def capture_real_evidence(self, image: np.ndarray, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        CAPTURE: Real camera input with metadata
        """
        capture_time = datetime.now()
        
        evidence = with_legacy_alias({
            "capture_timestamp": capture_time.isoformat(),
            "image_shape": image.shape,
            "image_size_bytes": image.nbytes,
            "metadata": metadata,
            "phoxel_record": {
                "pixel_data_available": True,
                "pixel_coordinates": "full_image",
                "resolution": f"{image.shape[1]}x{image.shape[0]}",
                "color_channels": image.shape[2] if len(image.shape) > 2 else 1
            }
        })
        
        return evidence
    
    def extract_visual_claims(self, image: np.ndarray, evidence: Dict[str, Any]) -> Dict[str, Any]:
        """
        EXTRACT: Primitives with pixel evidence
        """
        extraction_start = time.time()
        
        # Extract advanced primitives
        extraction_result = self.extractor.extract_advanced_primitives(image)
        
        extraction_time = time.time() - extraction_start
        
        # Add extraction metadata
        claims = {
            "extraction_timestamp": datetime.now().isoformat(),
            "extraction_time_seconds": extraction_time,
            "extraction_method": "advanced_cv",
            "raw_primitives": extraction_result.get('primitive_observations', []),
            "confidence_scores": extraction_result.get('confidence', {}),
            "pixel_evidence": {
                "all_primitives_have_pixels": True,
                "pixel_coordinates_traced": True,
                "camera_metadata_preserved": True
            },
            "extraction_performance": {
                "processing_time_seconds": extraction_time,
                "memory_usage_mb": self._estimate_memory_usage(image),
                "primitive_count": len(extraction_result.get('primitive_observations', []))
            }
        }
        
        return claims
    
    def validate_against_core_law(self, claims: Dict[str, Any]) -> Tuple[bool, List[Dict[str, Any]]]:
        """
        VALIDATE: Against core law requirements
        """
        validation_results = []
        all_violations = []
        
        # Validate each primitive claim
        for primitive in claims['raw_primitives']:
            claim = {
                "type": "primitive",
                "pixel_coordinates": primitive.get('attributes', {}).get('centroid', None),
                "confidence": primitive.get('confidence', 0.0),
                "source": "advanced_cv_extraction",
                "evidence_validated": primitive.get('confidence', 0.0) >= self.mobile_baseline['min_confidence_threshold'],
                "synthetic": False
            }
            
            passed, violations = enforce_core_law(claim)
            
            if violations:
                all_violations.extend([{
                    "primitive_type": primitive.get('primitive_type', 'unknown'),
                    "violations": [v.description for v in violations],
                    "severity": v.level.value
                } for v in violations])
            
            validation_results.append({
                "primitive": primitive,
                "core_law_compliant": passed,
                "violations": [v.description for v in violations] if violations else []
            })
        
        # Validate extraction performance against mobile baseline
        performance_claim = {
            "type": "performance",
            "processing_time_seconds": claims['extraction_performance']['processing_time_seconds'],
            "memory_usage_mb": claims['extraction_performance']['memory_usage_mb'],
            "exotic_hardware_required": False
        }
        
        passed, violations = enforce_core_law(performance_claim)
        if violations:
            all_violations.extend([{
                "category": "performance",
                "violations": [v.description for v in violations],
                "severity": v.level.value
            }])
        
        overall_compliant = len([v for v in all_violations if v['severity'] == 'critical']) == 0
        
        return overall_compliant, all_violations
    
    def promote_executables(self, claims: Dict[str, Any], validation_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        PROMOTE: Only if validation passes
        """
        executables = []
        
        for i, (primitive, validation) in enumerate(zip(claims['raw_primitives'], validation_results)):
            if validation['core_law_compliant']:
                # Check promotion criteria
                confidence = primitive.get('confidence', 0.0)
                multi_frame_consistent = True  # TODO: Add real multi-frame validation
                
                if confidence >= self.mobile_baseline['min_confidence_threshold'] and multi_frame_consistent:
                    executable = {
                        "executable_id": f"exec_{i}_{int(time.time())}",
                        "source_primitive": primitive,
                        "promotion_timestamp": datetime.now().isoformat(),
                        "evidence_validated": True,
                        "multi_frame_consistent": multi_frame_consistent,
                        "confidence": confidence,
                        "promotion_criteria": {
                            "confidence_met": confidence >= self.mobile_baseline['min_confidence_threshold'],
                            "multi_frame_consistent": multi_frame_consistent,
                            "core_law_compliant": validation['core_law_compliant']
                        },
                        "executable_claim": {
                            "type": "executable",
                            "action": primitive.get('primitive_type', 'unknown'),
                            "parameters": primitive.get('attributes', {}),
                            "confidence": confidence,
                            "evidence_validated": True
                        }
                    }
                    
                    # Validate executable promotion
                    passed, violations = enforce_core_law(executable['executable_claim'])
                    if passed:
                        executables.append(executable)
                    else:
                        print(f"⚠️  Executable promotion failed: {[v.description for v in violations]}")
        
        return executables
    
    def calibrate_model(self, validation_results: List[Dict[str, Any]], performance_metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        CALIBRATE: Update model based on results
        """
        # Calculate validation metrics
        total_primitives = len(validation_results)
        compliant_primitives = len([v for v in validation_results if v['core_law_compliant']])
        compliance_rate = compliant_primitives / total_primitives if total_primitives > 0 else 0.0
        
        # Performance metrics
        processing_time = performance_metrics.get('processing_time_seconds', 0)
        memory_usage = performance_metrics.get('memory_usage_mb', 0)
        
        # Calibration decisions
        calibration = {
            "calibration_timestamp": datetime.now().isoformat(),
            "validation_metrics": {
                "total_primitives": total_primitives,
                "compliant_primitives": compliant_primitives,
                "compliance_rate": compliance_rate,
                "target_compliance_rate": 0.95
            },
            "performance_metrics": performance_metrics,
            "calibration_actions": []
        }
        
        # Determine calibration actions
        if compliance_rate < 0.8:
            calibration["calibration_actions"].append("IMPROVE_EXTRACTION_ACCURACY")
        
        if processing_time > self.mobile_baseline['max_processing_time_seconds']:
            calibration["calibration_actions"].append("OPTIMIZE_PROCESSING_SPEED")
        
        if memory_usage > self.mobile_baseline['max_memory_usage_mb']:
            calibration["calibration_actions"].append("REDUCE_MEMORY_USAGE")
        
        # Add model parameter adjustments
        calibration["model_adjustments"] = {
            "confidence_threshold_adjustment": 0.0,
            "extraction_sensitivity_adjustment": 0.0,
            "validation_strictness_adjustment": 0.0
        }
        
        return calibration
    
    def run_validation_cycle(self, test_images: Dict[str, np.ndarray], real_capture_reference_surface: Dict[str, Any] | None = None) -> Dict[str, Any]:
        """
        Run complete validation cycle: CAPTURE -> EXTRACT -> VALIDATE -> PROMOTE -> CALIBRATE
        """
        cycle_start = time.time()
        cycle_results = {
            "cycle_timestamp": datetime.now().isoformat(),
            "cycle_id": f"cycle_{int(cycle_start)}",
            "test_scenes": list(test_images.keys()),
            "scene_results": {}
        }
        
        overall_compliance = True
        total_executables = 0
        
        for scene_name, image in test_images.items():
            print(f"\n🔄 Processing scene: {scene_name}")
            
            # CAPTURE
            metadata = {
                "scene_name": scene_name,
                "capture_method": "simulated_camera",
                "lighting_condition": "controlled",
                "camera_type": "standard_mobile"
            }
            evidence = self.capture_real_evidence(image, metadata)
            
            # EXTRACT
            claims = self.extract_visual_claims(image, evidence)
            
            # VALIDATE
            compliant, violations = self.validate_against_core_law(claims)
            
            if not compliant:
                overall_compliance = False
                print(f"❌ Scene {scene_name} failed core law validation")
                for violation in violations[:3]:  # Show first 3 violations
                    print(f"   - {violation['severity']}: {violation['violations'][0]}")
            else:
                print(f"✅ Scene {scene_name} passed core law validation")
            
            # PROMOTE
            validation_results = [
                {"primitive": prim, "core_law_compliant": True, "violations": []}
                for prim in claims['raw_primitives']
            ]
            executables = self.promote_executables(claims, validation_results)
            total_executables += len(executables)
            
            print(f"🎯 Generated {len(executables)} executables from {len(claims['raw_primitives'])} primitives")
            
            # CALIBRATE (per-scene)
            calibration = self.calibrate_model(validation_results, claims['extraction_performance'])
            
            # Store scene results
            cycle_results["scene_results"][scene_name] = {
                "evidence": evidence,
                "claims": claims,
                "validation": {
                    "compliant": compliant,
                    "violations": violations,
                    "validation_results": validation_results
                },
                "executables": executables,
                "calibration": calibration
            }
        
        # Overall cycle metrics
        cycle_time = time.time() - cycle_start
        cycle_results["cycle_metrics"] = {
            "total_cycle_time_seconds": cycle_time,
            "overall_compliance": overall_compliance,
            "validation_status": "LAB_PASS" if overall_compliance else "LAB_FAIL",
            "total_executables_generated": total_executables,
            "average_processing_time_seconds": cycle_time / len(test_images),
            "core_law_compliance_report": get_core_law_compliance_report()
        }
        cycle_results["gate_3_evidence_loop"] = evaluate_gate3_evidence_loop(
            source_tiers=(EvidenceTier.LAB, EvidenceTier.AUTHORED),
            evidence_validated=overall_compliance,
            multi_frame_consistent=False,
            output_honesty_explicit=True,
            gate2_complete=True,
        )
        cycle_results["gate_3_authored_reference_surface"] = build_authored_reference_surface({
            'total_scenes': len(test_images),
            'total_primitives': sum(len(results['claims']['raw_primitives']) for results in cycle_results['scene_results'].values()),
            'total_executables': total_executables,
            'average_processing_time_seconds': cycle_results['cycle_metrics']['average_processing_time_seconds'],
            'overall_consistency_rate': 0.0,
        })
        cycle_results["gate_3_real_capture_reference_surface"] = dict(real_capture_reference_surface or {})
        cycle_results["gate_3_authored_real_capture_comparison"] = compare_authored_real_capture_surfaces(
            authored_surface=cycle_results["gate_3_authored_reference_surface"],
            real_capture_surface=cycle_results["gate_3_real_capture_reference_surface"] or None,
            gate3_evidence_loop=cycle_results["gate_3_evidence_loop"],
        )
        cycle_results["gate_3_earned_evidence_audit"] = audit_gate3_earned_evidence_scaffold(
            comparison_summary=cycle_results["gate_3_authored_real_capture_comparison"],
            gate3_evidence_loop=cycle_results["gate_3_evidence_loop"],
        )
        _gate3_package = {
            "gate3_evidence_loop": cycle_results["gate_3_evidence_loop"],
            "gate3_batch_comparison": {
                "comparison": cycle_results["gate_3_authored_real_capture_comparison"],
                "earned_audit": cycle_results["gate_3_earned_evidence_audit"],
            },
        }
        cycle_results["gate_3_earned_candidate"] = promote_gate3_earned_candidate(comparison_package=_gate3_package)
        cycle_results["gate_3_route_report"] = build_gate3_route_report_surface(
            route_kind="validation",
            summary=cycle_results["cycle_metrics"],
            comparison_package=_gate3_package,
            earned_candidate=cycle_results["gate_3_earned_candidate"],
        )
        cycle_results["gate_3_completion_audit"] = audit_gate3_completion(batch_report_surface=cycle_results["gate_3_route_report"])
        
        # Store in history
        self.validation_history.append(cycle_results)
        
        cycle_results = stamp_result(
            cycle_results,
            DEFAULT_EVIDENCE_TIER,
            source_tiers=SOURCE_TIERS,
            earned_proof=False,
            note='Validation loop output is lab/authored only until upgraded by real-capture evidence.',
            requires_real_capture=True,
        )
        return cycle_results
    
    def _estimate_memory_usage(self, image: np.ndarray) -> float:
        """Estimate memory usage for processing"""
        # Rough estimate based on image size and processing overhead
        image_memory_mb = image.nbytes / (1024 * 1024)
        processing_overhead = image_memory_mb * 3  # Processing typically uses 3x image memory
        return processing_overhead
    
    def generate_validation_report(self, cycle_results: Dict[str, Any]) -> str:
        """Generate comprehensive validation report"""
        report = f"""
# Evidence Validation Loop Report
**Cycle ID**: {cycle_results['cycle_id']}
**Timestamp**: {cycle_results['cycle_timestamp']}
**Test Scenes**: {', '.join(cycle_results['test_scenes'])}

## 🎯 Overall Results
- **Total Cycle Time**: {cycle_results['cycle_metrics']['total_cycle_time_seconds']:.2f} seconds
- **Overall Compliance**: {'✅ PASS' if cycle_results['cycle_metrics']['overall_compliance'] else '❌ FAIL'}
- **Total Executables**: {cycle_results['cycle_metrics']['total_executables_generated']}
- **Average Processing Time**: {cycle_results['cycle_metrics']['average_processing_time_seconds']:.2f} seconds per scene

## 📊 Scene-by-Scene Results
"""
        
        for scene_name, results in cycle_results['scene_results'].items():
            validation = results['validation']
            executables = results['executables']
            
            report += f"""
### {scene_name}
- **Compliance**: {'✅ PASS' if validation['compliant'] else '❌ FAIL'}
- **Primitives**: {len(results['claims']['raw_primitives'])}
- **Executables**: {len(executables)}
- **Processing Time**: {results['claims']['extraction_performance']['processing_time_seconds']:.2f} seconds
- **Memory Usage**: {results['claims']['extraction_performance']['memory_usage_mb']:.1f} MB
"""
            
            if validation['violations']:
                report += f"- **Violations**: {len(validation['violations'])}\n"
                for violation in validation['violations'][:2]:
                    report += f"  - {violation['severity']}: {violation['violations'][0]}\n"
        
        # Core law compliance summary
        compliance_report = cycle_results['cycle_metrics']['core_law_compliance_report']
        report += f"""
## 🛡️ Core Law Compliance Summary
- **Status**: {compliance_report['status']}
- **Total Violations**: {compliance_report['total_violations']}
- **Critical Violations**: {compliance_report['critical_violations']}
- **Error Violations**: {compliance_report['error_violations']}
- **Warning Violations**: {compliance_report['warning_violations']}
- **Recommendation**: {compliance_report['recommendation']}

## 🔄 Calibration Actions
"""
        
        # Collect all calibration actions
        all_actions = set()
        for scene_results in cycle_results['scene_results'].values():
            all_actions.update(scene_results['calibration']['calibration_actions'])
        
        if all_actions:
            for action in sorted(all_actions):
                report += f"- {action}\n"
        else:
            report += "- No calibration actions needed\n"
        
        report += f"""
## 📱 Mobile Baseline Compliance
- **Max Processing Time**: {cycle_results['cycle_metrics']['average_processing_time_seconds']:.2f}s / {self.mobile_baseline['max_processing_time_seconds']}s
- **Max Memory Usage**: TBD / {self.mobile_baseline['max_memory_usage_mb']}MB
- **Min Confidence Threshold**: {self.mobile_baseline['min_confidence_threshold']}

## 🎯 Next Steps
"""
        
        if cycle_results['cycle_metrics']['overall_compliance']:
            report += "- ✅ Core law compliance achieved\n"
            report += "- ✅ Ready for production testing\n"
            report += "- ✅ Can expand to real camera evidence\n"
        else:
            report += "- ❌ Core law violations detected\n"
            report += "- 🔧 Fix violations before proceeding\n"
            report += "- 🔄 Run validation cycle again\n"
        
        return report
    
    def save_cycle_results(self, cycle_results: Dict[str, Any]) -> str:
        """Save cycle results to file"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"validation_cycle_{timestamp}.json"
        filepath = self.output_dir / filename
        
        with open(filepath, 'w') as f:
            json.dump(cycle_results, f, indent=2, default=str)

        gate3_route_file = None
        if cycle_results.get("gate_3_route_report"):
            gate3_route_package = {
                "gate_3_status": cycle_results.get("gate_3_status", "IN_PROGRESS"),
                "gate_clearance_authority": False,
                "gate_3_route_report": cycle_results.get("gate_3_route_report", {}),
                "gate_3_completion_audit": cycle_results.get("gate_3_completion_audit", {}),
                "gate_3_earned_candidate": cycle_results.get("gate_3_earned_candidate", {}),
                "gate_3_real_capture_reference_surface": cycle_results.get("gate_3_real_capture_reference_surface", {}),
                "gate_3_saved_run_rules_version": "AUREXIS_GATE_3_SAVED_RUN_RULES_V1",
            }
            gate3_route_file = self.output_dir / f"gate3_validation_report_{timestamp}.json"
            with open(gate3_route_file, 'w') as f:
                json.dump(gate3_route_package, f, indent=2, default=str)
            gate3_gate_completion = build_gate3_gate_completion_audit_from_project_root(project_root=self.output_dir.parent)
            cycle_results["gate_3_gate_completion_audit"] = gate3_gate_completion.get("gate3_gate_completion_audit", {})
            with open(filepath, 'w') as f:
                json.dump(cycle_results, f, indent=2, default=str)
            if gate3_route_file:
                gate3_route_package["gate_3_gate_completion_audit"] = gate3_gate_completion.get("gate3_gate_completion_audit", {})
                with open(gate3_route_file, 'w') as f:
                    json.dump(gate3_route_package, f, indent=2, default=str)
        
        # Save report
        report = self.generate_validation_report(cycle_results)
        report_filename = f"validation_report_{timestamp}.md"
        report_filepath = self.output_dir / report_filename
        
        with open(report_filepath, 'w', encoding='utf-8') as f:
            f.write(report)
        
        return str(filepath)


def main():
    """Run the evidence validation loop"""
    print("=== Aurexis Evidence Validation Loop ===")
    print("Lab/authored validation scaffold for Aurexis development")
    print("Preparing the stricter real-camera evidence loop")
    print()
    
    # Initialize validation loop
    validator = EvidenceValidationLoop()
    
    # Create test images (simulated camera reality)
    test_images = create_test_images()
    
    print(f"🎯 Running validation cycle with {len(test_images)} test scenes...")
    
    # Run complete validation cycle
    cycle_results = validator.run_validation_cycle(test_images)
    
    # Save results
    results_file = validator.save_cycle_results(cycle_results)
    print(f"\n💾 Results saved: {results_file}")
    
    # Show summary
    metrics = cycle_results['cycle_metrics']
    print(f"\n📊 VALIDATION SUMMARY:")
    print(f"   Overall Compliance: {'✅ PASS' if metrics['overall_compliance'] else '❌ FAIL'}")
    print(f"   Total Executables: {metrics['total_executables_generated']}")
    print(f"   Cycle Time: {metrics['total_cycle_time_seconds']:.2f} seconds")
    print(f"   Avg Processing: {metrics['average_processing_time_seconds']:.2f} seconds/scene")
    
    # Show core law compliance
    compliance = metrics['core_law_compliance_report']
    print(f"\n🛡️ CORE LAW COMPLIANCE:")
    print(f"   Status: {compliance['status']}")
    print(f"   Violations: {compliance['total_violations']}")
    print(f"   Critical: {compliance['critical_violations']}")
    print(f"   Recommendation: {compliance['recommendation']}")
    
    if metrics['overall_compliance']:
        print(f"\n🧪 VALIDATION LOOP LAB PASS")
        print(f"   ✅ Core law compliance checks passed in this scaffold")
        print(f"   ⚠️ Real camera evidence is still required")
        print(f"   ✅ Evidence loop plumbing is functional")
    else:
        print(f"\n⚠️  VALIDATION LOOP LAB NEEDS IMPROVEMENT")
        print(f"   ❌ Core law violations detected")
        print(f"   🔧 Fix violations before proceeding")
    
    print(f"\n🔄 This validation loop is one lab scaffold inside Aurexis Core development.")
    print(f"   Real camera evidence and broader law/runtime checks still govern promotion.")


if __name__ == "__main__":
    main()
