# Core Audit Scope v85

This package is a Core-only audit drop.
It is intentionally narrower than the mixed working repo packages.

## Included on purpose
- `aurexis_lang/` package source and examples
- active Core law / roadmap / authority surfaces
- Gate 1 and Gate 2 law docs and progress docs
- active phase-1 parser / interpreter / language surfaces
- Gate 2 enforcement surface
- selected project ledgers relevant to the active Core line
- a curated Core-only test subset that passed inside this audit scope

## Excluded on purpose
- historical vision-track trees
- evidence batch outputs and generated result folders
- broader benchmark/demo/mobile/release packaging surfaces not needed for auditing active Core code
- archived non-authoritative backlog material

## Audit intent
This drop is for independent review of the current Core state, especially the active law/runtime chain.
It is not meant to represent every historical or experimental side path.
