# AUREXIS Runtime Obedience Reporting Rules V1

Runtime-obedience reports must:
- state whether they are authored/runtime evidence, not earned physical proof
- keep blocked and unresolved reasons explicit
- keep world-authority / image-access wording aligned to frozen Gate 1 law
- avoid claiming Gate 2 complete unless the audited runtime suite clears as a whole
- avoid presenting scaffold/runtime reports as production-ready proof

Required report fields:
- report_scope
- gate_clearance_authority
- evidence
- final_environment
- blocked reasons / preserved reasons
- explicit outcome status
