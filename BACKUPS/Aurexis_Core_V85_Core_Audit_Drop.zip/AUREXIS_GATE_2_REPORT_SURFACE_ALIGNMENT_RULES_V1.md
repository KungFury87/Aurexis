# Aurexis Gate 2 Report Surface Alignment Rules V1

All active runtime-stage outputs participating in Gate 2 obedience must carry aligned reporting metadata.

Required fields:
- `gate_2_status`: `IN_PROGRESS`
- `reporting_rules_version`: `AUREXIS_RUNTIME_OBEDIENCE_REPORTING_RULES_V1`
- `evidence_scope`: `authored/runtime`
- `gate_clearance_authority`: `false`
- `world_authority_primary`: `true`
- `image_access_primary`: `true`
- `report_scope`: runtime-stage-specific value beginning with `runtime_`

These fields apply to runtime resolution, interpretation, state propagation, and branch-state outputs.
