# AUREXIS Gate 2 Runtime Mutation Edge Case Rules V1

These rules freeze the Gate 2 expectation that mutation edge cases remain explicit and honest.

Required rules:
- successful earlier assignments must survive later failed loop/control steps
- mixed success/failure execution paths must keep explicit unresolved reasons
- runtime-obedience must preserve surviving state and explicit blocked reasons together
- missing-target, unsupported-operator, unsupported-step, and blocked-control reasons must not disappear as reporting becomes higher level
- control-facing runtime surfaces must expose the same Gate 2 stage metadata used by the other active runtime stages
