# AUREXIS Gate 2 Runtime Obedience Checklist V1

Gate 2 means the runtime obeys frozen Gate 1 law instead of convenience logic.

Required runtime-obedience checks:
- resolution / interpretation / propagation / branch state must stay mutually consistent
- blocked and unresolved reasons must survive all reporting layers
- descriptive / partial / blocked / complete statuses must stay explicit
- state mutation must be consistent across the runtime chain
- report surfaces must reference evidence-tier language and must not claim Gate 2 complete by convenience
- world remains primary in authority
- image remains primary in access

Gate 2 is not complete merely because a runtime path works.
Gate 2 completes only when the active runtime surfaces obey the frozen law consistently.
