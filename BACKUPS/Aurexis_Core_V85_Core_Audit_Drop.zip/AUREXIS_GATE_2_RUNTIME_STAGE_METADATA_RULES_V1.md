# Aurexis Gate 2 Runtime Stage Metadata Rules V1

All active runtime-stage report surfaces must carry the same aligned Gate 2 metadata.

Required keys:
- `gate_2_status`: `IN_PROGRESS`
- `reporting_rules_version`: `AUREXIS_RUNTIME_OBEDIENCE_REPORTING_RULES_V1`
- `stage_metadata_version`: `AUREXIS_GATE_2_RUNTIME_STAGE_METADATA_RULES_V1`
- `report_surface_alignment_target`: `AUREXIS_GATE_2_REPORT_SURFACE_ALIGNMENT_RULES_V1`
- `evidence_scope`: `authored/runtime`
- `gate_clearance_authority`: `false`
- `world_authority_primary`: `true`
- `image_access_primary`: `true`
- `partial_reporting_explicit`: `true`
- `stage_metadata_complete`: `true`

The report scope must remain runtime-stage-specific and begin with `runtime_`.
