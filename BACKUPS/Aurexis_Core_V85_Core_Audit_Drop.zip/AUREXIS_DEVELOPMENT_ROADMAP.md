# Aurexis Core Development Roadmap - Cleanup Reset

**Compressed target for the full vision:** 12-24 months  
**Aggressive target:** 14-18 months  
**Authority scope:** Core only  

---

## Current gate picture

### Gate 1 — Law Frozen
**Status:** in progress  
The broad direction is mostly known, but the law sheet still needed cleanup and tighter freezing around phoxel record, evidence tiers, and mobile baseline truth.

### Gate 2 — Runtime Obeys Law
**Status:** partially real  
There is real implementation substrate, but it is still being pulled under the corrected law instead of being treated as already complete.

### Gate 3 — Evidence Loop Earned
**Status:** scaffold exists, not yet earned  
Simulated and authored-asset work exists, but strong physical-world claims are not yet earned by repeated real-camera proof.

### Gate 4 — Mobile-Realistic Demonstration
**Status:** not yet earned  
Current-tech/mobile compatibility is a governing constraint, but the narrow phone/PC proof slice is not yet proven enough to mark complete.

### Gate 5 — Expansion Without Rewrite
**Status:** not yet earned  
Future-tech scalability is a design law, not yet a fully demonstrated result.

---

## Compressed roadmap

### Phase A (months 0-2) — Freeze the law
- finalize the active law sheet
- normalize phoxel terminology
- define evidence tiers clearly
- define the real mobile baseline
- remove contradictory completion claims

### Phase B (months 1-6) — Runtime obedience
- force parser/runtime/output layers under the cleaned law
- make descriptive / estimated / validated / executable statuses explicit everywhere
- keep reports honest about what is and is not promoted

### Phase C (months 3-9) — Earn the evidence loop
- build brutal benchmark harnesses
- keep simulated lab evidence separate from real-camera proof
- require repeated validation before strong claims

### Phase D (months 8-14) — Narrow current-tech demo
- prove a narrow but real current-phone/current-PC slice
- keep capability reporting honest
- avoid app/product theater

### Phase E (months 12-24) — Expansion without rewrite
- prove better hardware improves precision/robustness/speed without changing the law

---

## Priority order
1. Core law
2. runtime obedience
3. evidence loop
4. mobile-realistic demo
5. expansion without rewrite

Anything outside those five is backlog or later-program material.

---

## Explicit non-goals for the current package
- app-store deployment
- global infrastructure deployment
- finished business rollout
- finished ecosystem rollout
- production-ready claims
- project-complete claims

---

## Best next step
Use `AUREXIS_AUDIT_CLEANUP_MAP.md` and begin by keeping the implementation substrate while demoting misleading authority/status surfaces.
