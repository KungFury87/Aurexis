# Aurexis Gate 2 — Mixed-Path State Mutation Rules V1

Gate 2 runtime obedience requires that mixed-path execution stays honest.

Required rules:
- successful assignments must survive even when later steps fail
- failed steps must not silently roll back unrelated resolved state
- propagated state must match resolution state for all resolved assignments
- mixed success/failure chains must report `partial` or `blocked`, never fake `complete`
- mutation traces must remain reconstructable through resolution and propagation surfaces
