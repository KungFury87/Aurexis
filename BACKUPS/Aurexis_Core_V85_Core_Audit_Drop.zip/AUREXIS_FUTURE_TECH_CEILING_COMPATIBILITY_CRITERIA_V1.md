# AUREXIS FUTURE-TECH CEILING COMPATIBILITY CRITERIA V1

**STATUS**: ACTIVE GATE 1 FREEZE LAW

---

## Purpose

Freeze the short rule set that allows better future hardware to improve Aurexis Core **without rewriting the law**.

---

## Compatibility criteria

A future-tech improvement is legal only if all of these remain true:

1. **No ontology rewrite**
   - better hardware may not redefine what a phoxel is
   - better hardware may not redefine relation legality
   - better hardware may not redefine executable promotion law

2. **No hardware-required legality**
   - a claim may not become legally valid only because an exotic device exists
   - better hardware may improve confidence, precision, robustness, or speed
   - better hardware may not change the law from illegal to legal by changing the ontology

3. **No behavior drift by device class**
   - behavior may scale in quality, not in kind
   - a phone baseline and a stronger device must still speak the same law

4. **Optional enhancement only**
   - advanced sensors or better optics must be optional enhancement layers
   - they may not become hidden mandatory prerequisites for Core legality

5. **Current-tech floor remains valid**
   - future scaling may not invalidate the current-tech floor
   - the ordinary phone + PC baseline must remain a lawful baseline

---

## Blocked future-tech drift

The following are not allowed:
- `ontology_rewrite_required`
- `hardware_required_for_legality`
- `behavior_changes_with_hardware`
- `sensor_specific_semantics`
- `current_floor_invalidated`

---

## Allowed future-tech gains

These are allowed:
- higher confidence
- better precision
- better robustness
- faster processing
- better tolerance to blur / angle / lighting / compression

Those are capability improvements, not law rewrites.
