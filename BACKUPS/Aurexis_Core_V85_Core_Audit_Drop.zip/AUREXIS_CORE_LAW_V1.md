# AUREXIS CORE LAW SHEET V1 - CLEANUP RESET

**VERSION**: 1.1-cleanup  
**STATUS**: AUTHORITATIVE DRAFT FOR CORE-ONLY WORK  
**EFFECTIVE**: 2026-04-06  
**ROLE**: SINGLE TRUTH SOURCE FOR CURRENT AUREXIS CORE DIRECTION  

---

## PURPOSE

This file replaces contradictory "already complete" framing with the current authoritative Core direction.

This law sheet is for **Aurexis Core only**.
It does **not** authorize app-store deployment, global infrastructure, ecosystem completion, revenue claims, or production-readiness claims.
Those belong to later downstream programs, not current Core authority.

---

## 0. PROGRAM STATUS

**Current interpretation:**
- Gate 1 (Law Frozen): **in progress**
- Gate 2 (Runtime Obeys Law): **partially real / still being aligned**
- Gate 3 (Evidence Loop Earned): **scaffold exists / not yet earned**
- Gate 4 (Mobile-Realistic Demonstration): **not yet earned**
- Gate 5 (Expansion Without Rewrite): **not yet earned**

**Forbidden status claims in the current package:**
- "All 5 gates completed"
- "Production-ready"
- "Mobile app store deployment complete"
- "Global infrastructure deployed"
- "Project complete"

---

## 1. CORE DEFINITION

Aurexis Core is:
- a programming language
- a new interface layer with the physical world
- grounded in the laws of physics and light
- world-first in authority, image-first in access, both alive at once in processing
- possible with current technology
- scalable into future technology without rewriting Core law

Aurexis Core is **not**:
- an app
- the deferred E/D product
- an app-store deployment program
- a business/developer ecosystem program
- a claim of already-achieved human-equivalent machine vision

---

## 2. PHOXEL RECORD

A phoxel is the atomic observation object of Aurexis Core.
It is a photon/pixel bridge object binding:
- image-side observation location
- world-side anchor state or world-side hypothesis state
- measurable photonic signature
- time slice
- relation set
- integrity / confidence state

### Required behavior
- Every important visual claim must remain traceable to observed evidence.
- World-side state may be **resolved**, **estimated**, or **unknown**.
- The system must never collapse unknown into fake certainty.

### Current cleanup interpretation
- Image-space evidence is mandatory.
- World-side claims are allowed only with honest status tagging.
- The project term is **phoxel**; mixed `phixel` spelling should be normalized out over time.

---

## 3. WORLD / IMAGE AUTHORITY

**Authoritative law:**
- The **world is primary in authority**.
- The **image is primary in access**.
- Both registers stay alive at once during processing.

This means:
- the image is not ignored
- the image is not treated as the whole truth
- the model may not override observed evidence with fantasy
- the model may not treat one image as complete world truth

### Hard rule
**World first in authority. Image first in access. Both alive at once in processing.**

---

## 4. NATIVE RELATIONS

Core-native relations should be built around:
- position
- adjacency
- direction
- distance / proximity
- containment
- boundary
- region membership
- sequence / ordering

Higher-order but still important:
- scale
- hierarchy
- overlap
- continuity
- transition

Later / not primitive on day one:
- occlusion
- projection correspondence
- temporal continuity
- viewpoint law

---

## 5. EXECUTABLE PROMOTION

Observed structure is **not** automatically executable structure.

### Promotion ladder
1. **Observed**
2. **Estimated / interpreted**
3. **Validated**
4. **Executable**

### Promotion gates
A structure may promote only if it passes:
- geometric coherence
- cross-register consistency
- signal integrity
- temporal or contextual support
- language legality
- bounded inference

---

## 6. ILLEGAL INFERENCE

Core must distinguish at all times:
- observed
- estimated
- validated
- unknown

### Forbidden moves
- one image -> full world truth
- maybe/likely/partial -> certain/exact/complete
- inventing hidden structure as fact
- confusing image appearance with world truth
- confusing pattern with executable language
- confusing similarity with identity
- claiming causality from appearance alone
- overclaiming across time from one slice

---

## 7. CURRENT-TECH FLOOR / FUTURE-TECH CEILING

### Current-tech floor
Core must be possible with current technology and easily adoptable on current mobile technology.

### Future-tech ceiling
Better hardware may improve:
- confidence
- precision
- robustness
- speed

But better hardware must **not** rewrite Core law.

### Mobile baseline law
A narrow but real current-phone/current-PC proof slice must stay in the loop during development.

---

## 8. EVIDENCE TIERS

To remove the simulation-vs-proof confusion, package evidence must be classified into these tiers:

### Tier A — simulated lab evidence
- synthetic perturbations
- generated camera motion
- synthetic noise/blur/compression
- randomized performance/user metrics

Useful for lab exploration.
**Not sufficient as final proof.**

### Tier B — authored asset evidence
- controlled images/assets prepared for benchmark work

Useful for runtime/debugging and repeatable comparison.
**Still not final real-world proof.**

### Tier C — real camera evidence
- actual capture from current-tech devices under real conditions

Required for earned physical-world claims.

### Tier D — promoted / earned evidence
- repeated real-camera validation surviving the gates above

Only this tier can justify strong capability claims.

---

## 9. FORBIDDEN DIRECTIONAL DRIFT

Current Core authority forbids treating the following as current completion targets:
- app-store deployment
- global scaling infrastructure
- finished ecosystem/business rollout
- production-readiness claims
- user-growth/revenue claims
- claiming all gates are complete when evidence is not earned

These can remain as backlog or later-program material, but not as current Core authority.

---

## 10. MONTHLY FREEZE CADENCE

Every 4 weeks:
1. freeze law delta
2. freeze benchmark delta
3. freeze proof delta
4. package one coherent state
5. assess gate progress honestly

No code branch may outrun this law sheet.
