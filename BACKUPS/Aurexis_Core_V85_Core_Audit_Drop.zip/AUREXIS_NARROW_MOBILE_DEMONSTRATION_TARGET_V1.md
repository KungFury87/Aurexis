# AUREXIS NARROW MOBILE DEMONSTRATION TARGET V1

**STATUS**: ACTIVE GATE 1 FREEZE LAW

---

## Purpose

Freeze the narrow current-tech mobile target that later Gate 4 work must satisfy.

This is **not** a broad product target.
It is the smallest honest real-world slice that proves Core can survive current mobile reality.

---

## Required demonstration conditions

A legal narrow mobile demonstration must satisfy all of these:

1. `pc_preparation_supported`
   - a current PC may author / prepare / analyze the input

2. `phone_capture_supported`
   - a current ordinary phone must capture or interpret the narrow slice

3. `scope_is_narrow`
   - the target must stay narrow and specific
   - no general-vision overclaim

4. `output_honesty_explicit`
   - output must preserve observed / estimated / validated / executable distinctions

5. `no_hidden_exotic_hardware`
   - no hidden dependency on special sensors, rigs, or multi-device trickery

6. `real_capture_or_earned_evidence`
   - the demonstration may not clear on lab-only evidence
   - it must be at least `real-capture` tier for a narrow mobile claim

---

## Blocked mobile-demo overclaim

The following are not allowed:
- app-store readiness claims
- general human-equivalent vision claims
- production-readiness claims
- lab-only proof presented as current mobile demonstration
- narrow demo presented as broad ecosystem completion
