# Aurexis Control Resolution v80

This iteration adds a small control-resolution scaffold on top of branch/state handling.

## Honest limitation
This remains far from a full control-flow runtime.
