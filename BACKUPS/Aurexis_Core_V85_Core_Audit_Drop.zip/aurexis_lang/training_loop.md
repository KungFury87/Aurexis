# Aurexis Training Loop v1

## Goal
Create a repeatable loop around dataset manifest rows for future learned perception work.

## Current loop
dataset manifest -> row selection -> candidate scoring -> split summaries -> loop metadata

## Important rule
Keep synthetic and observed provenance visible throughout the loop.
