# Aurexis Perception Dataset v72

This iteration adds a training-ready perception dataset export scaffold.

## Honest limitation
This is not a trained model. It is the export layer needed before one.
