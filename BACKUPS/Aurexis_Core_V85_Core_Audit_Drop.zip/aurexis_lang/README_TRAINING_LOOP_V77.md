# Aurexis Training Loop v77

This iteration adds a learned-perception training-loop scaffold around dataset manifests.

## Honest limitation
This is still scaffolding, not an actual training/validation system.
