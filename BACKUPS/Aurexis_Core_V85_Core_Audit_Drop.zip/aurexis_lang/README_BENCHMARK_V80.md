# Aurexis Benchmarking v80

This iteration adds benchmark-style profile selection for current candidate-scoring behavior.

## Honest limitation
This is still scaffold benchmarking, not trained-model evaluation.
