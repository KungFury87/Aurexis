# Robust CV Perception v71

This iteration adds a stronger perception scaffold built from:
- CV feature extraction
- connected-components segmentation
- multi-threshold segmentation quality
- fused candidate summaries

## Honest limitation
This is still not a learned/production CV model.
It is a stronger robustness layer built from the current classical pieces.
