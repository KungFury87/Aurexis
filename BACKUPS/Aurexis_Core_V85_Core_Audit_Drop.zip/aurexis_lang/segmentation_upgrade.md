# Aurexis Segmentation Upgrade v1

## Goal
Discover candidate regions from image content instead of only from hard-coded geometric envelopes.

## Pipeline
1. ingest grayscale image
2. generate binary mask
3. run connected-component labeling
4. compute component bounding boxes / areas
5. filter components by minimum support
6. project surviving components into primitive observations
7. emit parser-ready bundle

## First projected primitive types
- region candidate
- containment candidate
- alignment candidate
- control/delimiter/literal role hints

## Honest limitation
Role assignment is still heuristic and confidence-bearing, not final truth.
