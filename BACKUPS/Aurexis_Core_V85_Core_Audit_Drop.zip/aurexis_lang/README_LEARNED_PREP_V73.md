# Aurexis Learned Perception Prep v73

This iteration adds a dataset-manifest and split-planning scaffold for future learned perception work.

## New path
exported perception rows -> manifest rows -> split assignment -> usefulness ranking

## Honest limitation
This is still prep work before any actual training/validation loop.
