# Aurexis Evaluation Loop v79

This iteration adds a learned-perception evaluation loop scaffold on top of ranking/inference.

## Honest limitation
This is still evaluation around a rule-based candidate model, not a trained benchmark suite.
