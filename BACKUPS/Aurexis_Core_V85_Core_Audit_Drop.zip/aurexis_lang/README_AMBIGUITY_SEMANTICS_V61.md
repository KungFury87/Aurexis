# Aurexis Ambiguity / Runtime Semantics v61

This iteration adds the first ambiguity-handling and runtime-semantics scaffolds.

## New path
primitive/token uncertainty -> competing parse candidates -> semantic summary -> runtime-facing ambiguity exposure

## Honest limitation
This is still not a full probabilistic parse/runtime engine.
