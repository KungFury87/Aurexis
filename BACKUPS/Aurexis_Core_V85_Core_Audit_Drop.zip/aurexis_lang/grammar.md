# Aurexis Grammar Draft v1

## Goal
Define how visual primitives compose into language structures.

## Composition ladder
primitives -> tokens -> expressions -> statements -> blocks -> program graph

## First token classes
- identifier token
- literal token
- operator token
- delimiter token
- control token
- block token

## First structural relations
- adjacency => possible concatenation / local binding
- containment => possible block or scoped meaning
- ordered path => possible evaluation order
- region class => possible semantic family
- color family => possible token/operator/literal mode
- anchor pattern => possible grammar start / stop / mode switch

## First grammar concepts
### Expression
A locally bound cluster of tokens that produces value meaning.

### Statement
A higher-level visual structure that represents one unit of action or declaration.

### Block
A visually scoped region containing statements.

### Program graph
A parsed relation graph of statements, dependencies, and control flow.

## Honest limitation
This is not a full language syntax yet. It is the first grammar spine.
