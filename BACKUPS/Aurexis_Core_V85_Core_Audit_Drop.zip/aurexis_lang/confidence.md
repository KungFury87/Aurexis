# Aurexis Confidence Propagation v1

## Goal
Carry uncertainty from:
image -> segments -> primitives -> tokens -> AST -> IR -> runtime trace

## First rules
1. Every primitive may carry confidence.
2. Token confidence is inherited from primitive confidence.
3. Statement confidence is derived from participating token confidence.
4. Program confidence is summarized from statement confidence.
5. Runtime trace should expose confidence, not hide it.

## Why this matters
This keeps Aurexis aligned with the physical reality of imperfect camera capture.
