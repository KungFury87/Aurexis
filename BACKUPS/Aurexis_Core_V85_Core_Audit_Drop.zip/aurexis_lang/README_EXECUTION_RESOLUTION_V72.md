# Aurexis Execution Resolution v72

This iteration adds a small value-resolution layer on top of the execution plan.
