# Aurexis Learned Perception Prep v1

## Goal
Organize exported perception rows into a form that could support later learned CV work.

## Core pieces
- dataset manifest
- provenance tagging
- split assignment
- row usefulness ranking
- explicit synthetic vs evidence-informed distinction

## Important rule
Never hide provenance. Synthetic-only rows and evidence-informed rows must remain distinguishable.
