# Aurexis Visual Language Track v1

This branch defines the missing language-layer spine for Aurexis.

The existing B-Sigil / Synthetic Capture Lab / Capacity work remains the:
- visual artifact robustness engine
- survivability engine
- synthetic camera realism engine

This `aurexis_lang` branch defines the beginning of the:
- visual syntax
- grammar
- parse target
- AST / IR
- execution/runtime model
- camera-input bridge

## Current goal
Make Aurexis directionally complete as:
- a survivable visual artifact system
- and
- a future camera-readable visual language/runtime

## Included in v1
- primitives spec
- grammar draft
- AST/IR draft
- parser stub
- runtime stub
- camera bridge contract
- example language object
