# Aurexis Execution Semantics v69

This iteration adds the first runtime-facing execution plan scaffold.

## New path
AST -> execution plan -> environment summary -> unresolved-step summary

## Honest limitation
This is still not a true evaluator/compiler/executor.
