# Camera Input Bridge Contract v1

## Purpose
Define the transition from camera-derived artifact input into the language parser.

## Bridge stages
1. capture input
2. normalize / segment
3. identify visual primitives
4. assign primitive confidence
5. emit token candidates
6. parse into AST
7. normalize into IR

## Important dependency
The existing Synthetic Capture Lab and artifact survivability work feeds this bridge by improving confidence in what primitives survive capture.

## Honest rule
The bridge is where the current robustness track and the new language track meet.
