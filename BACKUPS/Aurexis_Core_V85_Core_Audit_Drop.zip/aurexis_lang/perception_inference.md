# Aurexis Perception Inference v1

## Goal
Turn candidate-row rankings into a small inference summary suitable for later parser/runtime use.

## Outputs
- top candidate
- alternative candidates
- confidence/tier summary
- provenance summary
- notes on ambiguity

## Important rule
Do not erase alternatives. Aurexis should remain uncertainty-aware.
