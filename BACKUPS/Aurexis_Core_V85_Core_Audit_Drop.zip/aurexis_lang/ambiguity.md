# Aurexis Ambiguity Handling v1

## Goal
Preserve competing candidate meanings when the visual input is not fully certain.

## First ambiguity classes
- token ambiguity
- statement ambiguity
- block/scope ambiguity
- role ambiguity
- region/containment ambiguity

## First handling rules
1. preserve candidate alternatives
2. attach confidence to each alternative
3. summarize the best candidate, but do not erase lower-confidence candidates
4. expose ambiguity in runtime traces

## Intended benefit
This keeps Aurexis aligned with the physical reality of camera-derived uncertainty.
