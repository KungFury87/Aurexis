# Aurexis Confidence / Trace v60

This iteration adds the first confidence-aware parse/runtime layer.

## New path
primitive/token confidence -> parse confidence summary -> execution trace summary

## Honest limitation
This is still a scaffold and not full ambiguity-aware parsing or probabilistic execution.
