# Aurexis Visual Syntax Expansion v1

## Goal
Extend the language branch beyond one assignment-like path.

## New syntax-facing classes
- identifier
- literal
- operator
- delimiter
- control
- block_start
- block_end
- sequence_marker

## New structural forms
### Assignment
`identifier = literal`

### Binary expression
`identifier + literal`

### Statement list
ordered statements in one visual program region

### Block
region-scoped collection of statements

### Control stub
basic control form such as:
`if condition { block }`

## Honest limitation
This is still a very early syntax layer and not a mature visual language grammar.
