# Aurexis Control-Flow v1

## Goal
Represent simple execution-state transitions in a structured way.

## Current model
- current_state
- event / condition
- next_state
- resolved or blocked transition

## Intended future role
This provides a seam from current control-resolution scaffolds toward richer execution semantics later.
