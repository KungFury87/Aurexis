# Aurexis Control-Flow v81

This iteration adds a tiny control-flow/state-machine scaffold above control-resolution summaries.

## Honest limitation
This is still far from a full control-flow runtime.
