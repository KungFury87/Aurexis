# Aurexis Runtime Semantics v1

## Goal
Define the first runtime-facing meaning classes for parsed Aurexis language objects.

## First semantic classes
- assignment semantic
- binary-expression semantic
- control semantic
- block semantic
- unresolved semantic
- ambiguous semantic

## Runtime summary rule
Every evaluation pass should be able to say:
- what semantic classes were observed
- which were high-confidence
- which remained ambiguous
- whether execution was meaningfully resolvable
