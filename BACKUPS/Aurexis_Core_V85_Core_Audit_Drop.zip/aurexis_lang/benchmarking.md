# Aurexis Benchmarking v1

## Goal
Compare multiple candidate-scoring configurations against the same row set and select the best current profile.

## Outputs
- profile scores
- best profile
- hit-rate summaries
- notes on confidence/provenance limits

## Important rule
The selected profile is only the best current scaffold, not ground truth.
