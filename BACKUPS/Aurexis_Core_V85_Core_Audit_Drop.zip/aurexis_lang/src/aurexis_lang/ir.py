from dataclasses import dataclass, field
from typing import Any, Dict, List

@dataclass
class IRNode:
    op: str
    args: Dict[str, Any] = field(default_factory=dict)
    children: List["IRNode"] = field(default_factory=list)

def ast_to_ir(ast) -> IRNode:
    root = IRNode(op="program")
    for child in getattr(ast, "children", []):
        root.children.append(
            IRNode(op="token", args=getattr(child, "value", {}))
        )
    return root
