from dataclasses import dataclass, field
from typing import List, Dict, Any

from .parser_stub import Token, ASTNode

def parse_assignment(tokens: List[Token]) -> ASTNode:
    if len(tokens) >= 3 and tokens[1].value == "=":
        return ASTNode(
            node_type="Assignment",
            children=[
                ASTNode(node_type="Identifier", value={"name": tokens[0].value, "confidence": tokens[0].confidence}),
                ASTNode(node_type="Literal", value={"value": tokens[2].value, "confidence": tokens[2].confidence}),
            ],
        )
    return ASTNode(node_type="TokenStream", value={"count": len(tokens)})

def parse_tokens_expanded(tokens: List[Token]) -> ASTNode:
    program = ASTNode(node_type="Program")
    stmt = parse_assignment(tokens)
    program.children.append(stmt)
    return program
