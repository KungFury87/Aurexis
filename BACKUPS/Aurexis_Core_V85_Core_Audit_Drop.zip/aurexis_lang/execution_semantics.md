# Aurexis Execution Semantics v1

## Goal
Interpret parsed Aurexis structures into runtime-facing execution meaning.

## First execution classes
- assignment step
- binary-expression step
- control step
- block step
- unresolved step

## First environment model
A minimal environment dictionary can be updated by:
- resolved assignment steps

## Important rule
Unresolved or ambiguous meaning should remain visible.
Aurexis should not hide uncertainty just to look more complete.
