# Aurexis CV-Style Extraction v1

## Goal
Produce richer primitive candidates from image content using lightweight CV-style features.

## First feature families
1. edge density
2. intensity transition strength
3. coarse contour candidacy
4. band / ring contrast candidacy
5. grid / outer field structure candidacy

## Output
A parser bundle with:
- primitive candidates
- confidence scores
- feature summaries
- extraction notes

## Honest limitation
This is still not deep CV or learned detection.
It is the next structured heuristic layer.
