# Aurexis Learned Candidate Model v75

This iteration adds a small candidate-scoring/ranking layer above perception dataset rows.

## Honest limitation
This is still a placeholder model, not an actually trained learned-perception system.
