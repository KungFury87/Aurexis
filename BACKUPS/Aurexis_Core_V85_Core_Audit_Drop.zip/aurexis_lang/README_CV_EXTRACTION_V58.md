# Aurexis CV Extraction v58

This iteration adds the next image-to-language bridge layer:
a CV-style heuristic extractor.

## New path
raster image -> feature summaries -> primitive candidates -> parser bundle

## New feature families
- edge density
- dark-density contrast
- coarse ring/outer structure contrast
- grid/alignment candidate confidence

## Honest limitation
This is still not robust family recognition, learned CV, or phoxel-level extraction.
