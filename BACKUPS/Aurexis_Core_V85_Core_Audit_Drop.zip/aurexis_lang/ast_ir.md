# Aurexis AST / IR Draft v1

## Purpose
Define what camera-derived Aurexis language input becomes internally.

## Recommended internal path
camera/image/frame -> visual primitives -> tokens -> AST -> normalized IR -> runtime/execution

## AST node examples
- Program
- Block
- Statement
- Expression
- Identifier
- Literal
- Operator
- Control
- RegionBinding
- SequenceEdge

## IR goals
The IR should:
- remove purely visual ambiguity once parsed
- preserve structural meaning
- be executable/interpretable
- support future compile / transform paths

## Why both AST and IR
AST preserves syntax-facing structure.
IR preserves execution-facing structure.
