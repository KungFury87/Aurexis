# Aurexis Segmentation Upgrade v63

This iteration adds a connected-components style segmentation scaffold.

## New path
grayscale image -> binary mask -> connected components -> retained regions -> primitive observations -> parser bundle

## Honest limitation
This is still lightweight classical CV scaffolding.
It is not robust family recognition or phoxel-level structural decoding.
