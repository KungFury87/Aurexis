# Aurexis Segmentation v1

## Goal
Define the first staged segmentation path for turning image content into primitive candidates.

## Stages
### 1. Structural partitioning
Coarse center / ring / outer separation.

### 2. Region candidacy
Candidate regions with:
- bounding box
- coarse role hint
- confidence

### 3. Primitive projection
Candidate regions projected into parser-facing primitive observations.

## Confidence rule
Every projected primitive should carry:
- source stage
- segmentation confidence
- projection confidence
- final confidence
