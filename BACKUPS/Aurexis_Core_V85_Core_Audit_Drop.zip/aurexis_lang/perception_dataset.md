# Aurexis Perception Dataset v1

## Goal
Convert current perception outputs into repeatable dataset rows.

## Row contents
- source image/path
- feature vector summary
- primitive labels
- confidence signals
- provenance tag
