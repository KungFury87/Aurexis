# Aurexis Segmentation v59

This iteration adds the first segmentation-and-confidence scaffold.

## New path
raster image -> coarse partition -> segment candidates -> primitive observations -> parser bundle

## Honest limitation
This is still shallow staged segmentation, not a robust production-grade segmentation engine.
