# Aurexis Camera Extraction v56

This iteration adds the first camera-derived primitive extraction scaffold.

## New bridge
zone/image-derived artifact observations can now be turned into primitive observation bundles
that are parser-ready.

## Current path
zone manifest -> primitive observations -> visual tokenizer -> parser

## Honest limitation
This is not yet true computer vision extraction.
It is the first code-side handoff seam between the Lab/artifact side and the language side.
