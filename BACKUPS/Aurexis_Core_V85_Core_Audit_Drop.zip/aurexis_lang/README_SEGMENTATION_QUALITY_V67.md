# Segmentation Quality v67

This iteration upgrades the CV bridge with:
- multi-threshold probing
- stability summaries
- best-run selection

## Honest limitation
This is still a classical CV quality scaffold, not learned segmentation.
