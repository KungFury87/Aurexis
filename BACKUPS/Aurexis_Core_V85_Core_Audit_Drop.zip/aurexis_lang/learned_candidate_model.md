# Aurexis Learned Candidate Model v1

## Goal
Provide a scoring layer that ranks perception rows and primitive candidates using simple weighted heuristics.

## Inputs
- dataset rows
- confidence signals
- stability flags
- provenance tags

## Outputs
- ranked candidate score
- candidate tier
- notes for future learned-model replacement

## Important rule
Keep it explicit that this is a placeholder model, not ground truth.
