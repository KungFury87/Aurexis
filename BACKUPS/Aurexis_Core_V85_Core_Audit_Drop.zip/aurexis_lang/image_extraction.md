# Aurexis Image Extraction v1

## Goal
Read a raster artifact image and emit coarse primitive candidates.

## First-stage heuristic path
1. load image
2. convert to grayscale
3. compute center/ring/outer region summaries
4. infer coarse structure presence
5. emit primitive observations with confidence
6. hand bundle to tokenizer/parser

## Why this matters
This is the first executable step where the Lab/artifact side produces parser-relevant information from image content rather than only from manifests.
