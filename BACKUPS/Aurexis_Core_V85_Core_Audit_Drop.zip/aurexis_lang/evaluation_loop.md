# Aurexis Evaluation Loop v1

## Goal
Create a repeatable loop that scores current candidate-ranking behavior against expected labels.

## Current loop
dataset rows -> candidate scoring/ranking -> expected-label comparison -> split summary

## Important rule
Synthetic and observed provenance must remain visible in evaluation summaries.
