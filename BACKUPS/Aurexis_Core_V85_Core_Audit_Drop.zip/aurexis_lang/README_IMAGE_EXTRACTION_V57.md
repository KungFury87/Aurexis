# Aurexis Image Extraction v57

This iteration adds the first real image-derived primitive extraction scaffold.

## New path
raster image -> coarse region stats -> primitive observations -> parser bundle

## Honest limitation
This is still heuristic and shallow.
It is not yet robust family recognition or true visual parsing.
