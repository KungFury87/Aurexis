# Aurexis Block / Scope / Control Expansion v1

## Goal
Push the visual language branch beyond flat statement lists into:
- block structure
- simple scope
- simple control flow

## New concepts
### Block start / block end
Visual delimiters that define a bounded region of statements.

### Scope
A region in which identifiers and statements belong together.

### Control token
A token class such as:
- if
- else
- loop
- branch

### Program graph edge
A structural relation that represents control or dependency beyond local token order.

## Honest limitation
This is still a first expansion layer, not a full visual programming language yet.
