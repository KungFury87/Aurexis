# Camera-Derived Primitive Extraction v1

## Goal
Take a camera- or image-derived artifact observation and produce parser-ready primitive observations.

## First extraction stages
1. ingest image-domain artifact metadata
2. read zone references if available
3. infer coarse region candidates
4. emit primitive observations with confidence
5. hand to visual tokenizer / parser

## First primitive candidates
- region
- cluster
- point
- sequence marker
- containment relation
- alignment relation

## Why this matters
This is where Aurexis begins to become a real camera-to-code path instead of two adjacent branches.
