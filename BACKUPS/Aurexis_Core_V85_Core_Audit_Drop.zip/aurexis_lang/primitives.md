# Aurexis Visual Primitives v1

## Purpose
Define the first language-facing visual units that can eventually map camera input into structured meaning.

## Primitive families
### 1. Point
Smallest distinct recognized visual anchor or event.

### 2. Line / Stroke
Directed or undirected connective visual element.

### 3. Cluster
Local grouping of points/strokes/phoxel structures acting as one unit.

### 4. Region
Bounded area with semantic role.

### 5. Color Family
Warm / cool / neutral / accent classes used as language distinctions.

### 6. Adjacency
Two primitives that matter because of local relation.

### 7. Containment
A primitive or region enclosed by another region.

### 8. Sequence
Ordered relation across space or path.

### 9. Alignment
Shared axis, ring, field, or structural rhythm.

### 10. Role
Language-facing role assignment:
- token
- delimiter
- operator
- literal
- control
- block boundary

## Important rule
These are language primitives, not merely visual decoration primitives.
