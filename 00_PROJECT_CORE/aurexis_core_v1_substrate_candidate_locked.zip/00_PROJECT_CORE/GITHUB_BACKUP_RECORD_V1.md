# GitHub Backup Record — Aurexis Core V1 Substrate Candidate

**Date:** April 11, 2026
**Purpose:** Removable backup snapshot, NOT a claim of full Aurexis Core completion.

---

## Backup #6 — Recovered Sequence Collection Signature Bridge V1

| Field | Value |
|-------|-------|
| Repository URL | https://github.com/KungFury87/Aurexis |
| Remote branch name | `backup/v1-substrate-candidate-20260412-collsig` |
| Remote tag name | `backup-v1-substrate-candidate-20260412-collsig` |
| Pushed commit hash | *(to be filled after push)* |
| Push method | Git Credential Manager (device auth) via batch script |
| Push date | April 12, 2026 |

### What This Backup Contains

Snapshot at the Recovered Sequence Collection Signature Bridge V1 milestone (16th bridge). Includes:

- 16 bridge milestones (Raster Law through Recovered Sequence Collection Signature)
- 2217 standalone assertions across 26 runners
- 28 V1 modules
- All project core documents, gate verifications, lock manifest
- The locked zip package (~349 KB)
- All legacy releases and working session files

This is a removable backup snapshot, not a claim of full Aurexis Core completion.

### Remote Verification

*(to be filled after push)*

### Deletion Commands

```bash
# Delete remote branch:
git push origin --delete backup/v1-substrate-candidate-20260412-collsig
# Delete remote tag:
git push origin --delete backup-v1-substrate-candidate-20260412-collsig
# Delete local branch (optional):
git branch -D backup/v1-substrate-candidate-20260412-collsig
# Delete local tag (optional):
git tag -d backup-v1-substrate-candidate-20260412-collsig
```

---

## Backup #5 — Recovered Sequence Collection Contract Bridge V1

| Field | Value |
|-------|-------|
| Repository URL | https://github.com/KungFury87/Aurexis |
| Remote branch name | `backup/v1-substrate-candidate-20260412-collcontract` |
| Remote tag name | `backup-v1-substrate-candidate-20260412-collcontract` |
| Pushed commit hash | *(to be filled after push)* |
| Push method | Git Credential Manager (device auth) via batch script |
| Push date | April 12, 2026 |

### What This Backup Contains

Snapshot at the Recovered Sequence Collection Contract Bridge V1 milestone (15th bridge). Includes:

- 15 bridge milestones (Raster Law through Recovered Sequence Collection Contract)
- 2044 standalone assertions across 25 runners
- 27 V1 modules
- All project core documents, gate verifications, lock manifest
- The locked zip package (~334 KB)
- All legacy releases and working session files

This is a removable backup snapshot, not a claim of full Aurexis Core completion.

### Remote Verification

*(to be filled after push)*

### Deletion Commands

```bash
# Delete remote branch:
git push origin --delete backup/v1-substrate-candidate-20260412-collcontract
# Delete remote tag:
git push origin --delete backup-v1-substrate-candidate-20260412-collcontract
# Delete local branch (optional):
git branch -D backup/v1-substrate-candidate-20260412-collcontract
# Delete local tag (optional):
git tag -d backup-v1-substrate-candidate-20260412-collcontract
```

---

## Backup #4 — Recovered Page Sequence Signature Match Bridge V1

| Field | Value |
|-------|-------|
| Repository URL | https://github.com/KungFury87/Aurexis |
| Remote branch name | `backup/v1-substrate-candidate-20260412-seqsigmatch` |
| Remote tag name | `backup-v1-substrate-candidate-20260412-seqsigmatch` |
| Pushed commit hash | *(to be filled after push)* |
| Push method | Git Credential Manager (device auth) via batch script |
| Push date | April 12, 2026 |

### What This Backup Contains

Snapshot at the Recovered Page Sequence Signature Match Bridge V1 milestone (14th bridge). Includes:

- 14 bridge milestones (Raster Law through Recovered Page Sequence Signature Match)
- 1881 standalone assertions across 24 runners
- 26 V1 modules
- All project core documents, gate verifications, lock manifest
- The locked zip package (~321 KB)
- All legacy releases and working session files

### Remote Verification

*(to be filled after push)*

### Deletion Commands

```bash
# Delete remote branch:
git push origin --delete backup/v1-substrate-candidate-20260412-seqsigmatch
# Delete remote tag:
git push origin --delete backup-v1-substrate-candidate-20260412-seqsigmatch
# Delete local branch (optional):
git branch -D backup/v1-substrate-candidate-20260412-seqsigmatch
# Delete local tag (optional):
git tag -d backup-v1-substrate-candidate-20260412-seqsigmatch
```

---

## Backup #3 — Recovered Page Sequence Signature Bridge V1

| Field | Value |
|-------|-------|
| Repository URL | https://github.com/KungFury87/Aurexis |
| Remote branch name | `backup/v1-substrate-candidate-20260411-seqsig` |
| Remote tag name | `backup-v1-substrate-candidate-20260411-seqsig` |
| Pushed commit hash | `b909680e7ad9e752118a77c71861fc0eb2e8f52b` |
| Push method | Git Credential Manager (device auth) via batch script |
| Push date | April 11, 2026 |

### What This Backup Contains

Snapshot at the Recovered Page Sequence Signature Bridge V1 milestone (13th bridge). Includes:

- 13 bridge milestones (Raster Law through Recovered Page Sequence Signature)
- 1740 standalone assertions across 23 runners
- 25 V1 modules
- All project core documents, gate verifications, lock manifest
- The locked zip package (~317 KB)
- All legacy releases and working session files

### Remote Verification

Branch verified on remote:
```
b909680e7ad9e752118a77c71861fc0eb2e8f52b  refs/heads/backup/v1-substrate-candidate-20260411-seqsig
```

Tag verified on remote:
```
9c444a0e26ab73e958ab17604f3256502652e30d  refs/tags/backup-v1-substrate-candidate-20260411-seqsig
```

### Deletion Commands

```bash
# Delete remote branch:
git push origin --delete backup/v1-substrate-candidate-20260411-seqsig
# Delete remote tag:
git push origin --delete backup-v1-substrate-candidate-20260411-seqsig
# Delete local branch (optional):
git branch -D backup/v1-substrate-candidate-20260411-seqsig
# Delete local tag (optional):
git tag -d backup-v1-substrate-candidate-20260411-seqsig
```

---

## Backup #2 — Recovered Page Sequence Contract Bridge V1

| Field | Value |
|-------|-------|
| Repository URL | https://github.com/KungFury87/Aurexis |
| Remote branch name | `backup/v1-substrate-candidate-20260411-seq` |
| Remote tag name | `backup-v1-substrate-candidate-20260411-seq` |
| Pushed commit hash | `7d866de4c686fd7fc0577ed47c892a2daf806433` |
| Push method | Git Credential Manager (device auth) via batch script |
| Push date | April 11, 2026 |

### What This Backup Contains

Snapshot at the Recovered Page Sequence Contract Bridge V1 milestone (12th bridge). Includes:

- 12 bridge milestones (Raster Law through Recovered Page Sequence Contract)
- 1586 standalone assertions across 22 runners
- 24 V1 modules
- All project core documents, gate verifications, lock manifest
- The locked zip package (~300 KB)
- All legacy releases and working session files

### Remote Verification

Branch verified on remote:
```
7d866de4c686fd7fc0577ed47c892a2daf806433  refs/heads/backup/v1-substrate-candidate-20260411-seq
```

Tag verified on remote:
```
3f98bc85b47a78efa93c6a9b41f788c74e98be3d  refs/tags/backup-v1-substrate-candidate-20260411-seq
```

### Deletion Commands

```bash
# Delete remote branch:
git push origin --delete backup/v1-substrate-candidate-20260411-seq
# Delete remote tag:
git push origin --delete backup-v1-substrate-candidate-20260411-seq
# Delete local branch (optional):
git branch -D backup/v1-substrate-candidate-20260411-seq
# Delete local tag (optional):
git tag -d backup-v1-substrate-candidate-20260411-seq
```

---

## Backup #1 — Recovered Set Signature Match Bridge V1

| Field | Value |
|-------|-------|
| Repository URL | https://github.com/KungFury87/Aurexis |
| Remote branch name | `backup/v1-substrate-candidate-20260411` |
| Remote tag name | `backup-v1-substrate-candidate-20260411` |
| Pushed commit hash | `457cb8cc140cca771907b46afe101cb09428ae52` |
| Push method | Git Credential Manager (browser OAuth flow) via batch script |
| Push date | April 11, 2026 |

### What This Backup Contains

Snapshot at the Recovered Set Signature Match Bridge V1 milestone (11th bridge). Includes:

- 11 bridge milestones (Raster Law through Recovered Set Signature Match)
- 1437 standalone assertions across 21 runners
- 23 V1 modules
- All project core documents, gate verifications, lock manifest
- The locked zip package (70 files, 202 KB)
- All legacy releases and working session files

### Remote Verification

Branch verified on remote:
```
457cb8cc140cca771907b46afe101cb09428ae52  refs/heads/backup/v1-substrate-candidate-20260411
```

Tag verified on remote:
```
21c4b17f2f20fe36f094789d659a9cd3f93e4ab9  refs/tags/backup-v1-substrate-candidate-20260411
```

### Deletion Commands

```bash
# Delete remote branch:
git push origin --delete backup/v1-substrate-candidate-20260411
# Delete remote tag:
git push origin --delete backup-v1-substrate-candidate-20260411
# Delete local branch (optional):
git branch -D backup/v1-substrate-candidate-20260411
# Delete local tag (optional):
git tag -d backup-v1-substrate-candidate-20260411
```

---

## Honest Framing

These backups are removable snapshots of the Aurexis Core V1 Substrate Candidate at specific points in time. They are:

- Narrow law-bearing substrate candidate backups
- NOT full Aurexis Core completion
- NOT production releases
- NOT claims of broad provenance or security guarantees
- Safely removable via the deletion commands above without affecting any other branch

---

© 2026 Vincent Anderson — Aurexis Core. All rights reserved.
