"""
Aurexis Core V1 Substrate Candidate — package init.

This reduced package contains only the V1 law-bearing substrate modules.
Legacy pre-substrate modules are not included and not imported.

Scope: Narrow V1 substrate candidate, not full Aurexis Core.
(c) 2026 Vincent Anderson — Aurexis Core. All rights reserved.
"""

# ── V1 Substrate Modules (shipped in locked package) ──
# All test files import directly from submodules, e.g.:
#   from aurexis_lang.visual_grammar_v1 import ...
# This __init__.py exists only to make aurexis_lang a valid package.
# It does NOT re-export submodule contents to avoid coupling.

__version__ = "V1.0-substrate-candidate"

V1_MODULES = [
    "visual_grammar_v1",
    "visual_parser_v1",
    "visual_parse_rules_v1",
    "visual_executor_v1",
    "visual_program_executor_v1",
    "type_system_v1",
    "composition_v1",
    "print_scan_stability_v1",
    "temporal_law_v1",
    "hardware_calibration_v1",
    "self_hosting_v1",
    "substrate_v1",
    "raster_law_bridge_v1",
    "capture_tolerance_bridge_v1",
    "artifact_localization_bridge_v1",
    "orientation_normalization_bridge_v1",
    "perspective_normalization_bridge_v1",
    "composed_recovery_bridge_v1",
    "artifact_dispatch_bridge_v1",
    "multi_artifact_layout_bridge_v1",
    "artifact_set_contract_bridge_v1",
    "recovered_set_signature_bridge_v1",
    "recovered_set_signature_match_bridge_v1",
    "recovered_page_sequence_contract_bridge_v1",
    "recovered_page_sequence_signature_bridge_v1",
    "recovered_page_sequence_signature_match_bridge_v1",
    "recovered_sequence_collection_contract_bridge_v1",
    "recovered_sequence_collection_signature_bridge_v1",
    "recovered_sequence_collection_signature_match_bridge_v1",
    "recovered_collection_global_consistency_bridge_v1",
    "rolling_shutter_temporal_transport_bridge_v1",
    "complementary_color_temporal_transport_bridge_v1",
    "temporal_transport_dispatch_bridge_v1",
    "temporal_consistency_bridge_v1",
    "frame_accurate_transport_bridge_v1",
    "combined_temporal_fusion_bridge_v1",
    "temporal_payload_contract_bridge_v1",
    "temporal_payload_signature_bridge_v1",
    "temporal_payload_signature_match_bridge_v1",
    "temporal_global_consistency_bridge_v1",
    "overlap_detection_bridge_v1",
    "local_section_consistency_bridge_v1",
    "sheaf_style_composition_bridge_v1",
    "cohomological_obstruction_bridge_v1",
    "view_dependent_marker_profile_bridge_v1",
    "moment_invariant_identity_bridge_v1",
    "view_facet_recovery_bridge_v1",
    "view_dependent_contract_bridge_v1",
    "vsa_cleanup_profile_bridge_v1",
    "hypervector_binding_bundling_bridge_v1",
    "cleanup_retrieval_bridge_v1",
    "vsa_consistency_contract_bridge_v1",
    "unified_capability_manifest_bridge_v1",
    "unified_substrate_entrypoint_bridge_v1",
    "cross_branch_compatibility_contract_bridge_v1",
    "v1_substrate_release_audit_bridge_v1",
    "real_capture_ingest_profile_bridge_v1",
    "capture_session_manifest_bridge_v1",
    "evidence_delta_analysis_bridge_v1",
    "calibration_recommendation_bridge_v1",
    "real_capture_intake_preflight_bridge_v1",
]
